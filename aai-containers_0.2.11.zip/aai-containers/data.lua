require("prototypes/combined/containers")
