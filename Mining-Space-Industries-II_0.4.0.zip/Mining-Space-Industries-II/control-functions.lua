
function get_se_zone_icon(zone_name)
local r
if global.se_universe and global.se_universe.by_name[zone_name] then
	r=global.se_universe.by_name[zone_name].icon
	end
if not r then r='' end	
return r
end


function Get_XP_ratio(base)
local progress = math.ceil(game.forces.enemy.evolution_factor*100)
return math.ceil(base * progress)
end

-- get all avaliable techs for force
function get_techs_available_for_force(force,excludes,allow_locked)
local available = {}
local locked = {}
if allow_locked then 
	locked = table.deepcopy( global.mission_techs.transportation)
	concat_lists(locked,global.mission_techs.power)
	concat_lists(locked,global.mission_techs.production)
	concat_lists(locked,global.mission_techs.upgrades)
	concat_lists(locked,global.mission_techs.military)
	concat_lists(locked,global.mission_techs.ultimate_techs)
	end

for name,tech in pairs (force.technologies) do
	if (tech.enabled or (allow_locked and tech.visible_when_disabled and in_list(locked,name))) and tech_has_prereq(force,name) then
		if (not excludes) or (not in_list(excludes,name)) then
			table.insert(available,name) 
			end
		end
	end
	
-- remove expensive space techs
local basic = {"basic-tech-card","automation-science-pack","logistic-science-pack","chemical-science-pack","military-science-pack","utility-science-pack","production-science-pack"}
for t=#available,1,-1 do
	local tech = available[t]
	local ing = game.technology_prototypes[tech].research_unit_ingredients 
	for i=1, #ing do if not in_list(basic,ing[i].name) then 
		table.remove (available,t)
		break
		end end
	end
	
return available
end


function GetTechCost(tech)
local ing = tech.prototype.research_unit_ingredients
local m = tech.prototype.research_unit_count
local p = 0
for k,i in pairs (ing) do
	local qt = i.amount*k
	p=p + qt
	end
return p*m
end


-- get the cheapest tech availabe
function get_mission_tech_available(force,the_techs,skip_this)
local techs=table.deepcopy(the_techs)
del_list2(techs, skip_this)

local r,sr
local available = {}
for k=1,#techs do
	local tech = techs[k]
	if tech_has_prereq(force,tech) then
		if not force.technologies[tech].enabled then 
			local cost = GetTechCost(force.technologies[tech])
			available[tech]=cost
			end
		end
	end

local selected={}
local p=0
for k,v in Sort_a_Table(available, function(t,a,b) return t[b] > t[a] end) do
	if p==0 then p=v end
	if v<=p then 
	   p=v
	   table.insert(selected,k) --force.technologies[k]
	   end
	end

if #selected>0 then r = selected[math.random(#selected)] end

return r
end






function GetRandonRepairItems(force,nitems,add_this,always_add_this,mp)
	local function add_recipe(force,item,items) 
	if force.recipes[item] and force.recipes[item].enabled then table.insert(items,item) end
	end

	local function getReqItemsText(items)
	local txt = ''
	for a=1,#items do 
		txt=txt.. items[a].count .. '[item='..items[a].name ..']' 
	    if a<#items then txt=txt..',' end 
		end
	return txt
	end
	
	local function getReqItemTextNames(items)
	local List = {}
	for a=1,#items do 
		table.insert (List, {"",items[a].count .. '[item='..items[a].name ..']',get_localized_name(items[a].name)})
		end
	return List
	end



if not mp then mp=1 end
if not nitems then nitems=4 end
mp = mp + (global.settings.difficulty_level-1)/2
nitems = nitems + global.settings.difficulty_level-1
local items = {} 
local list = {"repair-pack","copper-cable","iron-gear-wheel","electronic-circuit","stone-brick","pipe","steel-plate",
			"engine-unit",'plastic-bar','concrete','advanced-circuit','processing-unit','red-wire','green-wire','battery',
			-- modded items
			'stone-tablet','iron-beam','motor','glass','electric-motor','silicon',
			--IR2
			'copper-pipe','copper-repair-tool','bronze-repair-tool','stainless-repair-tool','copper-beam','copper-gear-wheel','tin-gear-wheel','copper-piston','iron-piston','bronze-plate-special',
			'iron-plate-heavy','stainless-plate-heavy','gold-cable','gold-foil','invar-plate-special','lead-plate-special','tellurium-foil','stainless-rod'
			}
for k=1,#list do add_recipe(force,list[k],items) end
if add_this then for a=1,#add_this do table.insert(items,add_this[a]) end end
local repairs = {}
for a=1,nitems do	
	local quant= math.ceil(math.random(100, 300) * mp)
	local it = math.random(#items)
	table.insert(repairs, {name=items[it], count=quant})
	table.remove(items, it)
	if #items<1 then break end
	end
if always_add_this then  for a=1,#always_add_this do table.insert(repairs, always_add_this[a]) end end

return repairs, getReqItemsText(repairs), getReqItemTextNames(repairs)
end



--global.se_universe
--surface.map_gen_settings.autoplace_controls["planet-size"].size
--remote.call("space-exploration", "get_zone_from_name", {zone_name = "Magmin"}) )
--Zone.radius = 



-- Function to find random coordinates to a given direction
function FindRandomDistantChunk(surface, initial_position, chunk_distance)
local directionVec = GetRandomVector()
if not initial_position then  initial_position = {x=0,y=0} end
local ungenerated, last_generated 
local ini_chunk = Chunk.from_position(initial_position)
local chunkPos = Chunk.from_position(initial_position)
    -- Keep going in the direction of the vector
while distance(ini_chunk,chunkPos)<chunk_distance do
	chunkPos.x = chunkPos.x + directionVec.x
	chunkPos.y = chunkPos.y + directionVec.y
	end
return chunkPos
end





function FindTeamAttackCorner(surface, force, initial_position, chunk_distance)
local directionVec=GetRandomVector()
if not chunk_distance then chunk_distance=4 end
local enemy_spawn
local nothing = 0
local chunkPos = Chunk.from_position(initial_position)  --{x=0,y=0}  initial_position
local player_chunks = {chunkPos}
local last_building = chunkPos
    -- Keep checking chunks in the direction of the vector
    while(not enemy_spawn) do
		chunkPos.x = chunkPos.x + directionVec.x
        chunkPos.y = chunkPos.y + directionVec.y
        -- Set some absolute limits.
        if ((math.abs(chunkPos.x) > 2000) or (math.abs(chunkPos.y) > 2000)) then break
        
        elseif (surface.is_chunk_generated(chunkPos)) then
			local area = Chunk.to_area(chunkPos) 
			local builds = surface.find_entities_filtered{force=force,area=area,limit=1}
			if #builds>0 then 
				last_building = table.deepcopy(chunkPos)
				table.insert (player_chunks,table.deepcopy(chunkPos))
				else
				nothing = nothing + 1 
				if nothing >= chunk_distance then enemy_spawn = chunkPos end 
				end
			
        -- Found an ungenerated area
        else break end
		end

last_building = {x= last_building.x*32+math.random(31), y= last_building.y*32+math.random(31)}
if enemy_spawn then 
	enemy_spawn = {x= enemy_spawn.x*32+math.random(31), y= enemy_spawn.y*32+math.random(31)}
	enemy_spawn = surface.find_non_colliding_position('rocket-silo', enemy_spawn, 100, 1)
	end

return last_building, player_chunks, enemy_spawn
end




function group_set_command(group,position_1,position_2, position_3)
  local def = defines
  local compound = def.command.compound
  local structure = def.compound_command.return_last
  local go_to = def.command.attack_area   
  if not position_2 then position_2=position_1 end
  if not position_3 then position_3=position_2 end
  
  group.set_command(
		{ 
		  type = compound,
		  structure_type = structure,
		  commands =
		  {
		  {type = go_to, destination = position_1, distraction = defines.distraction.by_anything, radius=50},
		  {type = go_to, destination = position_2, distraction = defines.distraction.by_enemy, radius=30},
		  {type = go_to, destination = position_3, distraction = defines.distraction.by_enemy, radius=30},
		  {type = defines.command.wander, distraction = defines.distraction.by_enemy, radius=30},
		  }
		})

--group.start_moving()
end



--------------------------------------------------------------------------------------
function create_soldiers_group(surface,spawn,pcount, attack1, attack2,attack3)
local qt = math.min(10, math.max(2,math.ceil(game.forces.enemy.evolution_factor * 10 + math.random(math.ceil(pcount/2)))))
local group 
local one_humie 
for x=1, qt do
	local humie = get_random_human_soldier()
	local position = surface.find_non_colliding_position(humie, spawn, 100, 1)
	if position then
		if not group then group = surface.create_unit_group{position = position, force = game.forces.enemy} end
		one_humie = surface.create_entity{name=humie, position= position, force= game.forces.enemy}
		group.add_member(one_humie)
		table.insert (global.other_enemies,one_humie )
		end
	end
group_set_command(group,attack1,attack2,attack3)
return group, one_humie
end



function get_random_human_soldier(evolution)
if not evolution then evolution = game.forces.enemy.evolution_factor end
local list = { 'tc_fake_human_machine_gunner',
'tc_fake_human_laser',
'tc_fake_human_electric'}
if evolution>0.17 then 
	table.insert(list,'tc_fake_human_sniper')  
	else
	table.insert(list,'tc_fake_human_melee')
	table.insert(list,'tc_fake_human_pistol_gunner')
	end
if evolution>0.3 then table.insert(list,'tc_fake_human_grenade') end
if evolution>0.60 then table.insert(list,'tc_fake_human_rocket') end
if evolution>0.75 then table.insert(list,'tc_fake_human_erocket') table.insert(list,'tc_fake_human_cluster_grenade') end

local n=math.min(10, math.max(math.ceil(evolution*10),1))
return list[math.random(#list)] ..'_'..n
end






function get_brutals_for_evolution(evolution,extra_evo)
local brutals = {}
local biters = get_units_for_evolution(evolution,extra_evo)
for b=1,#biters do
	local brut = 'brutal-'..biters[b]
	if game.entity_prototypes[brut] then 
		table.insert(brutals,brut)
		end
	end
return brutals
end


function create_brutals_group(surface,spawn,pcount, attack1, attack2,attack3)
local qt = math.min(10, math.max(2,math.ceil(game.forces.enemy.evolution_factor * 10 + math.random(math.ceil(pcount/2)))))
local group 
local one_brutal 
local brutals = get_brutals_for_evolution(nil,0.1)
for x=1, qt do
	local brutal = brutals[math.random(#brutals)]
	local position = surface.find_non_colliding_position(brutal, spawn, 200, 1)
	if position then
		if not group then 
			group = surface.create_unit_group{position = position, force = game.forces.enemy} 
			surface.create_entity{name="bm-large-tunnel", position=position, force = game.forces.neutral}
			create_remnants_particles (surface, math.random(30,50) , position) 
			end
		one_brutal = surface.create_entity{name=brutal, position= position, force= game.forces.enemy}
		create_tatoo_for_unit(one_brutal) 
		group.add_member(one_brutal)
		table.insert (global.other_enemies,one_brutal )
		end
	end
group_set_command(group,attack1,attack2,attack3)
return group, one_brutal
end


function get_random_lesser_boss(evolution)
if not evolution then evolution = game.forces.enemy.evolution_factor end
local list = {'maf-boss-biter-','maf-boss-acid-spitter-'}
if game.active_mods['ArmouredBiters'] then table.insert(list,'maf-boss-armoured-biter-') end
local n=math.min(10, math.max(math.ceil(evolution*10),1))
return list[math.random(#list)] ..n
end




function CallFrenzyAttack(surface,target,limit,multiplier)
if surface.map_gen_settings.autoplace_controls and surface.map_gen_settings.autoplace_controls["enemy-base"] 
   and surface.map_gen_settings.autoplace_controls["enemy-base"].size>0 then

local position
if target.type and target.valid 
	then 
	position=target.position
	else
	position = target
	end

local Min = 10
local Max = 300
local Dist = 1500

local spawn = surface.find_entities_filtered({type = "unit-spawner",limit=1,position=position,radius=Dist})
if #spawn>0 then
local force = spawn[1].force

local aliens = Max * force.evolution_factor 
aliens = math.floor(aliens + (aliens * (global.settings.difficulty_level-1))/2)

if aliens < Min then aliens=Min end
if limit and aliens>limit then aliens=limit end
if multiplier then aliens=math.floor(aliens * multiplier) end 

	if target.type and target.valid then 
		local sent = surface.set_multi_command({
			command = {type=defines.command.attack, target=target, distraction = defines.distraction.by_anything },
			unit_count = aliens,
			force = force,
			unit_search_distance = Dist,
		})
		else
		local sent = surface.set_multi_command({
			command = {type=defines.command.attack_area, destination=position, radius=50, distraction = defines.distraction.by_anything },
			unit_count = aliens,
			force = force,
			unit_search_distance = Dist,
		})
		end
	end
end
end



function CallWormAttack(surface,position,how_many,min_distance,max_distance,force)
if not max_distance then max_distance = min_distance + 5 end
local worms = get_worms_for_evolution(nil,nil, surface, position)
how_many = how_many + global.settings.difficulty_level - 1
for w=1,how_many do
	local worm = worms[math.random(#worms)]
		for t=1,10 do
			local x = position.x + math.random(min_distance,max_distance)* RandomNegPos()
			local y = position.y + math.random(min_distance,max_distance)* RandomNegPos()
			local pos = surface.find_non_colliding_position(worm, {x=x,y=y}, 6, 2)
			if pos then 
				create_remnants_particles (surface, math.random(20,40) , pos) 
				local wo = surface.create_entity{name=worm,force=force,position=pos}
				break
				end
		end
	end
end



-- returns 1 to 10 based on game evolution for that force 
function get_progress_10()
local evolution = game.forces.enemy.evolution_factor -- temporary
local p=math.min(10, math.max(math.ceil(evolution*10),1))
return p
end

function get_random_boss()
local list = {'maf-boss-biter-','maf-boss-acid-spitter-'}
if game.active_mods['ArmouredBiters'] then table.insert(list,'maf-boss-armoured-biter-') end
return list[math.random(#list)] .. get_progress_10()
end




function unit_follows_player(unit,distraction)
if unit and unit.valid then
	local players = unit.surface.find_entities_filtered{type='character', force=unit.force, position=unit.position, radius=20}
	if #players>0 then
		local command = {type = defines.command.go_to_location, destination_entity = players[1],distraction = distraction,
						pathfind_flags = {cache=true, allow_destroy_friendly_entities=false}}	--low_priority=true,
		unit.set_command(command)
	end
end
end


function secure_destroy_spill_items(entity,define_inventory)
local inv = entity.get_inventory(define_inventory)
	for i = 1, #inv do
		local stack = inv[i]
		if stack and stack.valid and stack.valid_for_read then 
			entity.surface.spill_item_stack(entity.position, stack, true)
			end
		end
entity.destroy();
end




function forbidden_construction_give_back_item(event)
local entity = event.created_entity
	if entity.type=='entity-ghost' or entity.type=='tile-ghost' then entity.destroy() return end
		if event.stack and event.player_index then
			local item=event.stack.name
			local player_index=event.player_index
				if player_index and game.players[player_index].valid and game.players[player_index].character and game.players[player_index].character.valid then
					game.players[player_index].insert{name=item, count=1}
					else
					entity.surface.spill_item_stack(entity.position, {name=item, count=1}, false)
					end
				entity.destroy()
				if player_index and game.players[player_index] then
					game.players[player_index].print({"labels.cant_build_here"},colors.red) end
				end
end


function getRandonPlayerEntity(surface,force,types,distance)
if not distance then distance=500 end
if #force.connected_players>0 then 
	local spawn_pos  = force.get_spawn_position(surface)
	local machines = surface.find_entities_filtered{force=force,position=spawn_pos,radius=distance, type=types, limit=500}
	for m=#machines,1,-1 do if not (machines[m] and machines[m].valid) then table.remove(machines,m) end end
	if #machines>0 then return machines[math.random(#machines)] end
	end
end



function Brood(mother)
local Units = mother.surface.find_entities_filtered{force= mother.force, position=mother.position, radius=10}
if #Units>40 then return end
local Min = 2
local Max = 5
local num = math.random(Min,Max) + global.settings.difficulty_level-1

local children = get_units_for_evolution()
for k=1,num do
	local name= children[math.random(#children)]
	local pos = mother.surface.find_non_colliding_position(name, mother.position, 10, 1)
		if pos then 
			mother.surface.create_entity{name="bm-acid-splash-fire", position=pos, force = mother.force}
			local child = mother.surface.create_entity{name=name, position=pos, force = mother.force}
			end
	end
end


function GetPlayerNear(surface,Pos,howfar)
local pl=nil
	for p, player in pairs(game.connected_players) do
		if player.valid and player.character then
			if player.character.valid and player.character.surface==surface then
			if distance(Pos,player.character.position)<howfar then
				pl = player
				break
				end
			end
			end
	end
return pl
end

function GetNearCharacter(surface,position,radius)
local p = surface.find_entities_filtered{name='character',position=position,radius=radius}
if #p>0 then return p[math.random(#p)] end
end


function special_entity_activity(entity, info)

local activities = info.special_entity_activity
for a=1,#activities do
	local activity = activities[a]
	local action = activity.action
	local chance = activity.chance * 2
	local surface= entity.surface


	if math.random()<=chance then 
	
		if action=='projectile_distant_shoot_at_base' then
			local will_fire = true
			if activity.progress then 
				activity.progress = activity.progress +1 
				if activity.progress<100 then will_fire=false else activity.progress=0 end
				end
				
			if will_fire then 
				if activity.reduce_fire_rate then activity.chance = activity.chance - activity.reduce_fire_rate end
				for s=1, global.settings.difficulty_level do
					local target = getRandonPlayerEntity(surface,info.force,{"assembling-machine","generator"})
					if target and target.valid then
						local target_position = get_random_pos_near(target.position,5) 
						local shoot = surface.create_entity{name =activity.projectile, target_position=target_position, position=target_position, source_position ={x=entity.position.x,y=entity.position.y}, force= entity.force, speed=5}
						CreateCameraForForce(info.force,shoot,surface,nil,nil,60)
						end
					end
				end
			
		elseif action=='projectile_shoot_near_player' then
			local target = GetNearCharacter(surface,entity.position,activity.distance)
			if target and target.valid then
				local target_position = target.position
				local shoot = surface.create_entity{name =activity.projectile, target_position=target_position, position=target_position, source_position ={x=entity.position.x,y=entity.position.y}, force= entity.force, speed=5}
				end				

		elseif action=='projectile_shoot_random_places_near' then
			local p = get_random_pos_near(entity.position,activity.distance)
			local shoot = surface.create_entity{name =activity.projectile, target_position=entity.position, position=p, source_position =p, force= entity.force, speed=5}

				
		elseif action=='grenade_launcher' then --implement
			local enemy = surface.find_nearest_enemy{position=entity.position, max_distance=35, force=entity.force} --zilla.force
			if enemy and enemy.valid and enemy.name~='entity-ghost' and enemy.type~='entity-ghost' and enemy.destructible and enemy.health then
				local weap = {'explosive-rocket','grenade', 'slowdown-capsule'}
				surface.create_entity{name=weap[math.random(#weap)], target=enemy, position=entity.position, force=entity.force, speed=0.4}
				end

		
		elseif action=='breeder' then Brood(entity)

		elseif action=='defender_capsules' then
			local ent = {'destroyer','defender'}
			surface.create_entity{name=ent[math.random(#ent)],  position=entity.position,target=entity,force=entity.force}

		elseif action=='worm_attack_near_player' then
			local target = GetNearCharacter(surface,entity.position,activity.distance)
			if target and target.valid then CallWormAttack(surface,target.position,activity.how_many + global.settings.difficulty_level-1 ,15) end

		elseif action=='shock_hazard' then entity_shock_hazard(entity,activity.radius,activity.quant + global.settings.difficulty_level-1)

		elseif action=='spawn_effect' then
			local effect = activity.effect
			if effect=='pollute' then 
				surface.pollute(entity.position,activity.pollute_value + (global.settings.difficulty_level-1)*4)
				surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=entity.position}
				surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
				end
			if effect=='explode' then 
				surface.create_entity{name = activity.explosion_name, position = entity.position}
				end
    
		elseif action=='reload_weapon' then reload_weapon(entity)


		end

		end
	end
end



function entity_shock_hazard(entity,radius,quant)
local enemy = entity.surface.find_entities_filtered{position=entity.position,radius=radius,limit=30}
for k=#enemy,1,-1 do 
	if ((enemy[k].name=='entity-ghost') or (enemy[k].type=='entity-ghost') or (not enemy[k].destructible)) or 
		(not enemy[k].health) or (entity==enemy[k]) or 
		(enemy[k].force and enemy[k].force==entity.force) then table.remove(enemy,k) end
	end
if #enemy>0 then
for x=1,quant do
	local target = enemy[math.random(#enemy)]
	if entity and entity.valid and target and target.valid and target.destructible then
		entity.surface.create_entity{name = 'electric-beam', position=entity.position, source = entity ,target=target, duration=40}
		end
	end
end
end


function reload_weapon(turret)
	if turret.type == 'electric-turret' then turret.energy = turret.energy + 1000000
	elseif turret.type =='ammo-turret' then 
		local bullet = 'firearm-magazine'
		if turret.force.evolution_factor>0.3 then bullet = 'piercing-rounds-magazine' end
		turret.insert({name=bullet, count=100})
	elseif turret.type =='artillery-turret' then turret.insert({name='artillery-shell', count=15}) 
	elseif turret.type =='fluid-turret' then turret.insert_fluid({name='light-oil', amount=10}) 
	end			
end



function clear_and_fill_area(surface, position, area_size, fill_water, fill_all)
local area = GetAreaAroundPos(position, area_size)
ClearArea(area,surface)
RemoveAliensInArea(surface, area)
if fill_water then FillWaterWith(surface,area,fill_water) end --'grass-1'
if fill_all then FillWith(surface,area,nil,fill_all) end
end
function ClearArea(area,surface)
if not surface then surface = game.surfaces.surface end
	local entities = surface.find_entities(area)			
	for _, e in pairs(entities) do
		if e.type == "simple-entity" or e.type == "resource" or e.type == "tree" or e.type=="cliff" then e.destroy()	end
	end	
end
function RemoveAliensInArea(surface, area)
    for _, entity in pairs(surface.find_entities_filtered{area = area, type={'unit-spawner','unit','turret'}}) do
		if string.sub(entity.force.name,1,5)=='enemy' then entity.destroy() end
    end
end
function FillWaterWith(surface,area,withwhat)
FillWith(surface,area,{"water","deepwater","water-green","deepwater-green","water-shallow","water-mud"},withwhat)
end
function FillWith(surface,area,what,withwhat)
local solo = {}
	local x1,x2, y1,y2
	if area[1] then 
		x1,x2 = area[1].x , area[2].x
		y1,y2 = area[1].y , area[2].y
	else	
		x1,x2 = area.left_top.x , area.right_bottom.x
		y1,y2 = area.left_top.y , area.right_bottom.y		
	end
	for y=y1,y2,1 do
		for x=x1,x2,1 do
		local tile = surface.get_tile(x, y)
		if (tile.valid) and ((not what) or in_list(what, tile.name)) then 
			local tn = withwhat
			if type(tn)=='table' then tn = withwhat[math.random(#withwhat)] end
			table.insert(solo, {name=tn, position={x=x, y=y}}) 
			end
		end
	end

if #solo>0 then
	surface.set_tiles(solo)
	end
end



function create_special_defense_things_on_area(surface,area,force,quantity,extras)
local x1 = area.left_top.x
local y1 = area.left_top.y
local x2 = area.right_bottom.x
local y2 = area.right_bottom.y

local recharge = {action='reload_weapon', chance = 1}
local things = {'gun-turret','land-mine','laser-turret','msi_protomolecule_artillery'}--'artillery-turret'
if extras then concat_lists(things, extras) end

for q=1,quantity do
	local name = things[math.random(#things)]
	local pos
	for x=1,10 do 
		local p={x=math.random(x1,x2),y=math.random(y1,y2)}
		pos = surface.find_non_colliding_position(name, p, 3, 3)
		if pos then break end 
		end
	if pos then 
		local thing = surface.create_entity{name = name, position =pos,force = force, spawn_decorations=true}
		if color then thing.color=color end
		if in_list ({'gun-turret','laser-turret','flamethrower-turret','artillery-turret','msi_protomolecule_artillery','sw-electric-stick-turret-2','sw-electric-turret-2'},name) then 
			table.insert(global.monitored_entity,{entity=thing,event="special_entity_activity",tab_event={special_entity_activity={recharge}}})
			end
		end
	end
end