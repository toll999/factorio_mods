local silo_names = {'rsc-silo-stage1','rsc-silo-stage2','rsc-silo-stage3','rsc-silo-stage4','rsc-silo-stage5','rsc-silo-stage6',
					'rsc-silo-stage1-serlp','rsc-silo-stage2-serlp','rsc-silo-stage3-serlp','rsc-silo-stage4-serlp','rsc-silo-stage5-serlp','rsc-silo-stage6-serlp',
					'rsc-silo-stage1-sesprs','rsc-silo-stage2-sesprs','rsc-silo-stage3-sesprs','rsc-silo-stage4-sesprs','rsc-silo-stage5-sesprs','rsc-silo-stage6-sesprs'}


local droid_boost_names = {
['worker-robot-speed'] = 'worker_robots_speed_modifier',
['worker-robot-battery'] = 'worker_robots_battery_modifier',
['worker-robot-storage'] = 'worker_robots_storage_bonus',
['laboratory-speed'] = 'laboratory_speed_modifier',
['laboratory-productivity'] = 'laboratory_productivity_bonus'
}
local droid_boost_by_level = {
['worker-robot-speed'] = 0.1,
['worker-robot-battery'] = 0.15,
['worker-robot-storage'] = 1,
['laboratory-speed'] = 0.1,
['laboratory-productivity'] = 0.02,
}
local synthetic_gears = {'melee',
	'pistol_gunner',
	'machine_gunner',
	'sniper',
	'laser',
	'electric',
	'rocket'}


function spawn_msi_companion(companion,force,surface,position)
local companions = global.force_control[force.name].companions
local techname = 'msi_companion_'..companion..'_tech'
local level = get_tech_level(force,techname,6)+1   --
global.force_control[force.name].companions[companion].level=level
local name='msi_companion_'..companion..'_'..level
if companion=='synthetic' then 
	local synthetic_data = companions.synthetic
	local gear_what = synthetic_data.gear_what or 1
	name = 'msi_companion_synthetic_' ..synthetic_gears[gear_what] ..'_'.. level
	end
local pos = surface.find_non_colliding_position('assembling-machine-1', position, 0, 1)
local entity = surface.create_entity({name=name, position=pos, force = force})
if companion=='synthetic' then  
	entity.ai_settings.allow_destroy_when_commands_fail=false 
	else
	entity.color = {r = 1, g = 1, b = 1}
	entity.insert{name='spidertron-remote'}
	end
global.force_control[force.name].companions[companion].entity = entity

--[[
if companion=='synthetic' then 
	local re_id = script.register_on_entity_destroyed(entity)
	global.force_control[force.name].companions[companion].re_id = re_id
	global.registered_entities[re_id] = {force=force, mission_name='MI_004_repair_synthetic'}
	end]]

-- reset working conditions...
reset_companion_state(force,companion)
end

function reset_droid_boost(droid_data,force)
if droid_data.current_boost_bonus and droid_data.boost_what>0 then 
	local boost = droid_boost_names[droid_data.boost_available[droid_data.boost_what]]
	local new_value = math.max (0,force[boost] - droid_data.current_boost_bonus)
	force[boost]=new_value 
	droid_data.current_boost_bonus=false
	end
end


function reset_companion_state(force,companion_type)
local companions = global.force_control[force.name].companions

if companion_type=='droid' then
	local droid_data = companions.droid
	droid_data.following = nil --playername
	droid_data.stay_here = nil --a position
	droid_data.science_available = droid_data.science_available or {'automation-science-pack'}
	droid_data.science_options = update_companion_science_pack_names(droid_data.science_available)
	droid_data.science_what=0
	reset_droid_boost(droid_data,force)
	droid_data.boost_available = droid_data.boost_available or {}
	droid_data.boost_options = update_companion_boost_names(droid_data.boost_available,droid_data.level)
	droid_data.boost_what =0
	
	droid_data.harvest_available = get_harvest_available(droid_data.level)
	droid_data.harvest_options = update_companion_harvest_names(droid_data.harvest_available)
	droid_data.harvest_what=0

	elseif	companion_type=='synthetic' then
	local synthetic_data = companions.synthetic
	synthetic_data.following = nil --playername
	synthetic_data.stay_here = nil --a position	
	synthetic_data.go_home   = nil --a position
	synthetic_data.gear_available = synthetic_data.gear_available or {'melee'}
	synthetic_data.gear_options = update_companion_gear_names(synthetic_data.gear_available)
	if (not synthetic_data.gear_what) or synthetic_data.gear_what<1 then  synthetic_data.gear_what=1 end
	end
	
end



function  update_companion_harvest_names(harvest_available)
local opt={}
for h, name in pairs(harvest_available) do 
	table.insert(opt,{'','[item='..name..']' , game.item_prototypes[name].localised_name})
	end
return opt
end

function update_companion_gear_names(gears)
local opt={}
for h, name in pairs(gears) do 
	table.insert(opt, {'labels.synthetic_gear_opt_'..name})  --game.item_prototypes[name].localised_name
	end
return opt
end

function update_companion_boost_names(boosts,level)
local opt={}
for h, name in pairs(boosts) do 
	local boost_bonus = level * droid_boost_by_level[name]
	table.insert(opt, {'modifier-description.'..name, boost_bonus})  --game.item_prototypes[name].localised_name
	end
return opt
end

function update_companion_science_pack_names(packs)
local opt={}
for h, name in pairs(packs) do 
	table.insert(opt,'[item='..name..']')  --game.item_prototypes[name].localised_name
	end
return opt
end





function companion_synthetic_died(surface,position,force)
local corpse = surface.create_entity({name='msi_companion_synthetic_corpse', position=position, force = force})
corpse.destructible = false
global.force_control[force.name].companions.synthetic.corpse = corpse
		
local cam_text = {'entity-name.msi_companion_synthetic_corpse'}
local camera = {entity=corpse,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/msi_companion_synthetic_corpse]', text=cam_text}
local mission_name = 'MI_004_repair_synthetic'
local data = {force=force,mission_name=mission_name,surface=surface,position=position,entity=corpse,progress=0}
local mission_id = add_mission_log(nil,force,mission_name,nil,nil, {camera},{corpse},data) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
table.insert(global.monitored_entity,{entity=corpse,event="droid_repair_synthetic",tab_event=data})
end


function get_harvest_available(level)
local av = {'coal'}

if level>=2 then table.insert(av,'stone') end
if level>=3 then table.insert(av,'iron-ore') end
if level>=4 then table.insert(av,'copper-ore') end
if level>=5 then table.insert(av,'uranium-ore') end
if game.active_mods['space-exploration'] then 
	if level>=5 then table.insert(av,'se-cryonite')  table.insert(av,'se-vulcanite')  end
	if level>=6 then table.insert(av,'se-holmium-ore') table.insert(av,'se-beryllium-ore') end
	if level==7 then table.insert(av,'se-iridium-ore') table.insert(av,'se-vitamelange') end
	end
if game.active_mods['IndustrialRevolution'] then 
	if level>=2 then table.insert(av,'tin-ore') end
	if level>=4 then table.insert(av,'gold-ore') end
	end
return av
end



function upgrade_companion_technology(force,tech_name) 
local companions = global.force_control[force.name].companions

if string.find(tech_name, "droid") then
	local droid_data = companions.droid
	local droid     = droid_data.entity
	local techname = 'msi_companion_droid_tech'
	local level = get_tech_level(force,techname,6)+1   -- droid_data.level or 1
	--level = level + 1
	droid_data.level = level
	reset_companion_state(force,'droid')
	
	local sciences = {'automation-science-pack',
				'logistic-science-pack',
				'military-science-pack',
				'chemical-science-pack',
				'production-science-pack',
				'utility-science-pack'}
	if game.active_mods['space-exploration'] then table.insert (sciences,'se-rocket-science-pack')
		else table.insert (sciences,'space-science-pack') end
	local science_available = {} 		
	for k=1,level do table.insert(science_available,sciences[k]) end
	droid_data.science_available = science_available
	droid_data.science_options = update_companion_science_pack_names(science_available)
	droid_data.boost_available = droid_data.boost_available or {}
	if level==2 then table.insert(droid_data.boost_available,'laboratory-speed') 
		elseif level==3 then table.insert(droid_data.boost_available,'laboratory-productivity') 
		elseif level==4 then table.insert(droid_data.boost_available,'worker-robot-battery') 
		elseif level==5 then table.insert(droid_data.boost_available,'worker-robot-storage') 
		elseif level==6 then table.insert(droid_data.boost_available,'worker-robot-speed') 
		end
	droid_data.boost_options = update_companion_boost_names(droid_data.boost_available,level)	
	droid_data.harvest_available = get_harvest_available(level)
	droid_data.harvest_options = update_companion_harvest_names(droid_data.harvest_available)
	
	
	if droid and droid.valid then 
		local name = 'msi_companion_droid_' .. level
		local pos = droid.surface.find_non_colliding_position(name, get_random_pos_near(droid.position,2) , 0, 1)
		local new_companion = droid.surface.create_entity{name=name, position=pos, force=force}
		for try=1,20 do
			if new_companion then break end
			pos = droid.surface.find_non_colliding_position(name, get_random_pos_near(droid.position,2+try) , 0, 1)
			new_companion = droid.surface.create_entity{name=name, position=pos, force=force}
			end
		if new_companion and new_companion.valid then 	
			droid_data.entity = new_companion
			transfer_inventory_loose(droid, new_companion, defines.inventory.spider_trunk)
			transfer_quipment_grid_from_entities(droid, new_companion)
			droid.destroy()
			Entity_Speak(new_companion,{'labels.companion_speak_level_up'},60)
			end
		end
	

	
	
	elseif string.find(tech_name, "synthetic") then
			local synthetic_data = companions.synthetic
			local synthetic     = synthetic_data.entity
			--local level = synthetic_data.level or 1
			local techname = 'msi_companion_synthetic_tech'
			local level = get_tech_level(force,techname,6)+1
			--level = level + 1
			synthetic_data.level = level
			local gear_available = {} 		
			for k=1,level do table.insert(gear_available,synthetic_gears[k]) end
			synthetic_data.gear_available = gear_available
			synthetic_data.gear_options = update_companion_gear_names(synthetic_data.gear_available)
		
		if synthetic and synthetic.valid then 
			local name = 'msi_companion_synthetic_' ..synthetic_gears[synthetic_data.gear_what] ..'_'.. level
			local new_companion = synthetic.surface.create_entity{name=name, position=synthetic.position, force=force}
			if new_companion and new_companion.valid then
				new_companion.ai_settings.allow_destroy_when_commands_fail=false
				synthetic_data.entity = new_companion
				synthetic.destroy()
				Entity_Speak(new_companion,{'labels.companion_speak_level_up'},60)
				end
			end		
			
	end

update_companion_frames(force)
end



function synthetic_change_gear(synthetic_data)
local gear = synthetic_gears[synthetic_data.gear_what]
local synthetic = synthetic_data.entity
local level = synthetic_data.level
local name = 'msi_companion_synthetic_' ..gear ..'_'.. level
local new_synthetic = synthetic.surface.create_entity{name=name, position=synthetic.position, force=synthetic.force}
new_synthetic.ai_settings.allow_destroy_when_commands_fail=false
new_synthetic.health = synthetic.health
synthetic_data.entity = new_synthetic
synthetic.destroy()
Entity_Speak(new_synthetic,synthetic_data.gear_options[synthetic_data.gear_what],10)
end





--CLICKED
function bt_companion_clicked(name,player,gui)
local force=player.force
local companions = global.force_control[force.name].companions
local droid_data = companions.droid
local synthetic_data = companions.synthetic
local droid     = droid_data.entity
local synthetic = synthetic_data.entity
local refresh = false

if droid and droid.valid then 
	if name=='bt_companion_camera_droid' then CreateCameraForPlayer(player,droid,droid.surface,{'entity-name.msi_companion_droid'},nil) closes_informatron(player)
	elseif name=='bt_companion_follow_droid' then reset_companion_state(force,'droid')  droid_data.following=player.name   refresh=true
	elseif name=='bt_companion_droid_stay' then reset_companion_state(force,'droid') droid.autopilot_destination = droid.position   refresh=true
	elseif name=='bt_companion_droid_gohome' then 
		reset_companion_state(force,'droid')  
		droid.autopilot_destination = force.get_spawn_position(droid.surface)
		refresh=true
	end
	if refresh then Entity_Speak(droid,get_what_is_companion_doing(force,'droid') ,10) end
	end
	
if synthetic and synthetic.valid then 
	if name=='bt_companion_camera_synthetic' then CreateCameraForPlayer(player,synthetic,synthetic.surface,{'entity-name.msi_companion_synthetic'},nil)  closes_informatron(player)
	elseif name=='bt_companion_follow_synthetic' then reset_companion_state(force,'synthetic')  synthetic_data.following=player.name      refresh=true   Entity_Speak(synthetic,get_what_is_companion_doing(force,'synthetic') ,10)
	elseif name=='bt_companion_synthetic_stay' then reset_companion_state(force,'synthetic')  synthetic_data.stay_here=synthetic.position refresh=true   Entity_Speak(synthetic,get_what_is_companion_doing(force,'synthetic') ,10)
	elseif name=='bt_companion_synthetic_gohome' then 
		reset_companion_state(force,'synthetic')  
		synthetic_data.go_home = force.get_spawn_position(synthetic.surface)
		refresh=true
	end
	end

if refresh then 
	local main_cf = gui.parent.parent.parent.parent.parent
	if main_cf.name and main_cf.name=='tab_companions_main' then 
		refresh_informatron_page(player, 'companion_units') 
		else update_companion_frames(force)
		end
	end
end







function bt_companion_dropdown_selected(gui,player)
local force=player.force
local companions = global.force_control[force.name].companions
local droid_data = companions.droid
local synthetic_data = companions.synthetic
local droid     = droid_data.entity
local synthetic = synthetic_data.entity
local refresh = false

if droid and droid.valid then 
	if gui.name=='bt_companion_science'  then
		reset_companion_state(force,'droid')
		droid_data.science_what=gui.selected_index
		refresh=true
	elseif gui.name=='bt_companion_harvest'  then
		reset_companion_state(force,'droid')
		droid_data.harvest_what=gui.selected_index
		refresh=true	
	elseif gui.name=='bt_companion_boost'  then
		reset_companion_state(force,'droid')
		droid_data.boost_what=gui.selected_index
		local boost = droid_boost_names[droid_data.boost_available[droid_data.boost_what]]
		local boost_bonus = droid_data.level * droid_boost_by_level[droid_data.boost_available[droid_data.boost_what]]
		force[boost]= force[boost] + boost_bonus
		droid_data.current_boost_bonus = boost_bonus
		refresh=true
		
	end
	if refresh then Entity_Speak(droid,get_what_is_companion_doing(force,'droid') ,10) end
	end

if synthetic and synthetic.valid then 
	if gui.name=='bt_companion_gear' then
		reset_companion_state(force,'synthetic')
		synthetic_data.gear_what=gui.selected_index
		synthetic_change_gear(synthetic_data)
		refresh=true
		end
	end
if refresh then 
	local main_cf = gui.parent.parent.parent.parent.parent
	if main_cf.name and main_cf.name=='tab_companions_main' then 
		refresh_informatron_page(player, 'companion_units') 
		else
		update_companion_frames(force)
		end
	end
	
end

function update_companion_frames(force)
for p,player in pairs (force.players) do
	if player.gui.screen.frame_droid then create_gui_droid(player, player.gui.screen) end
	if player.gui.screen.frame_synthetic then create_gui_synthetic(player, player.gui.screen) end
	end
end



-- GUI PANEL 
function create_gui_droid(player, element)
local force = player.force
local pl_name = player.name
if global.force_control[force.name] then 
local companions = global.force_control[force.name].companions
local droid_data = companions.droid
local droid     = droid_data.entity

if element.frame_droid and element.frame_droid.frame_droid_c then element.frame_droid.frame_droid_c.destroy() end
local main = add_gui (element, {type = "frame",  name='frame_droid', direction = "vertical"})
main.style.horizontally_stretchable =  false

local fr_droid     = main.add{type = "frame", name='frame_droid_c', caption = {"",'[img=entity/msi_companion_droid_1]',{'entity-name.msi_companion_droid'},' ',{'labels.level',droid_data.level or 0}}, direction = "vertical"}
if main.parent==player.gui.screen then fr_droid.drag_target = main end




if droid and droid.valid then 
		local tab_droid = fr_droid.add{type = "table",  name='tab_droid', column_count = 2}

		local tab_ent = tab_droid.add{type = "table",  name='tab_entity_d', column_count = 1}
		local tab_panel_d = tab_droid.add{type = "table",  name='tab_panel_d', column_count = 2}

		local epd = tab_ent.add{type = "entity-preview", name='ep_msi_companion_droid'}
			  epd.style.width = 60 epd.style.height = 100 epd.entity=droid	
		tab_ent.add{type="progressbar", name='pb_droid', value=droid.health / droid.prototype.max_health, style="health_progressbar"}.style.width=60 

		--HP / level
		tab_panel_d.add{type = "label", name='droid_hp', caption={'labels.current_hp',format_number(math.ceil(droid.health))}}
		tab_panel_d.add{type = "label"}
		--open camera
		--tab_panel_d.add{type = "label", caption={'labels.view_personal_camera'}}
		tab_panel_d.add{name='bt_companion_camera_droid', type="sprite-button", sprite = "img_camera", tooltip={'labels.view_personal_camera'},style = 'rounded_button' } 
		--follow
		--tab_panel_d.add{type = "label", caption={'labels.click_to_follow'}}
		tab_panel_d.add{name='bt_companion_follow_droid', type="sprite-button", sprite = "entity/character", tooltip={'labels.click_to_follow'},style = 'rounded_button' }
		--stay
		--tab_panel_d.add{type = "label", caption={'labels.companion_stay'}}
		tab_panel_d.add{name='bt_companion_droid_stay', type="sprite-button", sprite = "item/artillery-targeting-remote", tooltip={'labels.companion_stay'},style = 'rounded_button' } 
		--go home
		tab_panel_d.add{name='bt_companion_droid_gohome', type="sprite-button", sprite = "entity/crash-site-spaceship", tooltip={'labels.go_home'},style = 'rounded_button'} 		
		--science
		local science_options = droid_data.science_options
		local science_what = droid_data.science_what
		tab_panel_d.add{type = "label", caption={'labels.produce_science'}}
		tab_panel_d.add{name='bt_companion_science', type="drop-down", items = science_options, tooltip={'labels.produce_science_tooltip'}, selected_index=science_what} 
		--boost
		local boost_options = droid_data.boost_options
		local boost_what = droid_data.boost_what
		tab_panel_d.add{type = "label", caption={'labels.boost_bonus'}}
		tab_panel_d.add{name='bt_companion_boost', type="drop-down", items = boost_options, tooltip={'labels.boost_bonus_tooltip'}, selected_index=boost_what} 
		--harvest
		local harvest_options = droid_data.harvest_options
		local harvest_what = droid_data.harvest_what
		tab_panel_d.add{type = "label", caption={'labels.harvest'}}
		tab_panel_d.add{name='bt_companion_harvest', type="drop-down", items = harvest_options, tooltip={'labels.harvest_tooltip'}, selected_index=harvest_what} 

		-- doing what /camera
		fr_droid.add{type = "label", caption=get_what_is_companion_doing(force,'droid') }
		
	else
	local na = fr_droid.add{type="label", caption={'labels.not_available'}}
	na.style.font_color=colors.yellow  na.style.font= "default-bold"
	end

	
local tab_low = fr_droid.add{type = "table",  name='tab_low_d', column_count = 2}
tab_low.add{name='show_companion_button_droid', type="checkbox", caption={'labels.show_companion_button'}, state=global.player_settings[pl_name].show_companion_button_droid} 
if element.name == 'screen' then 
	tab_low.add{name='bt_destroy_my_3parent', type="button", style = 'rounded_button', caption={'labels.close'}} 
	end

end
end



function create_gui_synthetic(player, element)
local force = player.force
local pl_name = player.name

if global.force_control[force.name] then 
local companions = global.force_control[force.name].companions
local synthetic_data = companions.synthetic
local synthetic = synthetic_data.entity

if element.frame_synthetic and element.frame_synthetic.frame_synthetic_c then element.frame_synthetic.frame_synthetic_c.destroy() end
local main = add_gui (element, {type = "frame",  name='frame_synthetic', direction = "vertical"})
main.style.horizontally_stretchable =  false

local fr_synthetic = main.add{type = "frame", name='frame_synthetic_c', caption = {"",'[img=entity/msi_companion_synthetic_melee_1]',{'entity-name.msi_companion_synthetic'},' ',{'labels.level',synthetic_data.level or 0}}, direction = "vertical"}
if main.parent==player.gui.screen then fr_synthetic.drag_target = main end

if synthetic and synthetic.valid then 
	local tab_synthetic = fr_synthetic.add{type = "table",  name='tab_synthetic', column_count = 2}
	local tab_ent = tab_synthetic.add{type = "table",  name='tab_entity_s', column_count = 1}
	local eps = tab_ent.add{type = "entity-preview", name='ep_msi_companion_synthetic'}
		  eps.style.width = 60 eps.style.height = 100 eps.entity=synthetic	
	tab_ent.add{type="progressbar", name='pb_synthetic', value=synthetic.health / synthetic.prototype.max_health, style="health_progressbar"}.style.width=60 


		local tab_panel_s = tab_synthetic.add{type = "table",  name='tab_panel_s', column_count = 2}
		--HP / level
		tab_panel_s.add{type = "label", name='synthetic_hp', caption={'labels.current_hp',format_number(math.ceil(synthetic.health))}}
		tab_panel_s.add{type = "label"}
		--tab_panel_s.add{type = "label", caption={'labels.level',synthetic_data.level}}
		--open camera
		--tab_panel_s.add{type = "label", caption={'labels.view_personal_camera'}}
		tab_panel_s.add{name='bt_companion_camera_synthetic', type="sprite-button", sprite = "img_camera", tooltip={'labels.view_personal_camera'},style = 'rounded_button' } 
		--follow
		--tab_panel_s.add{type = "label", caption={'labels.click_to_follow'}}
		tab_panel_s.add{name='bt_companion_follow_synthetic', type="sprite-button", sprite = "entity/character", tooltip={'labels.click_to_follow'},style = 'rounded_button' }
		--stay
		--tab_panel_s.add{type = "label", caption={'labels.companion_stay'}}
		tab_panel_s.add{name='bt_companion_synthetic_stay', type="sprite-button", sprite = "item/artillery-targeting-remote", tooltip={'labels.companion_stay'},style = 'rounded_button' } 
		--go home
		tab_panel_s.add{name='bt_companion_synthetic_gohome', type="sprite-button", sprite = "entity/crash-site-spaceship", tooltip={'labels.go_home'},style = 'rounded_button'} 		
		
		--gear
		local gear_options = synthetic_data.gear_options
		local gear_what = synthetic_data.gear_what
		tab_panel_s.add{type = "label", caption={'labels.synthetic_equipe_gear'}}
		tab_panel_s.add{name='bt_companion_gear', type="drop-down", items = gear_options, tooltip={'labels.synthetic_equipe_gear_tooltip'}, selected_index=gear_what} 

		-- doing what /camera
		fr_synthetic.add{type = "label", caption=get_what_is_companion_doing(force,'synthetic') }

	elseif synthetic_data.corpse and synthetic_data.corpse.valid then 
	local tab_synthetic = fr_synthetic.add{type = "table",  name='tab_synthetic', column_count = 2}
	local eps = tab_synthetic.add{type = "entity-preview", name='ep_msi_companion_synthetic'}
		  eps.style.width = 60 eps.style.height = 100 eps.entity=synthetic_data.corpse
	local na = tab_synthetic.add{type="label", caption={'labels.david_destroyed_rapair'}}
	na.style.font_color=colors.yellow
	else
	local na = fr_synthetic.add{type="label", caption={'labels.not_available'}}
	na.style.font_color=colors.yellow  na.style.font= "default-bold"
	end
	


local tab_low = fr_synthetic.add{type = "table",  name='tab_low_s', column_count = 2}
tab_low.add{name='show_companion_button_synthetic', type="checkbox", caption={'labels.show_companion_button'}, state=global.player_settings[pl_name].show_companion_button_synthetic}
if element.name == 'screen' then 
	tab_low.add{name='bt_destroy_my_3parent', type="button", style = 'rounded_button', caption={'labels.close'}} 
	end
end
end




function informatron_companions_gui(player_index, element)
local player = game.players[player_index]
local tabmain  = element.add{type = "table",  name='tab_companions_main', column_count = 1}
create_gui_droid(player, tabmain)
create_gui_synthetic(player, tabmain)
end


function companion_has_mission(companion,mission_name,event)
if mission_name == 'M_unique_oil' then 
	local entity = event.entity -- oil
	local surface=entity.surface
	local mission_id = event.mission_id 
	if entity.surface == companion.surface and distance(companion.position,entity.position)<=15 then 
		entity.surface.create_entity{name = 'green-laser-beam', position=companion.position, source = companion, target_position=entity.position, duration=40}
		event.progress=event.progress + 0.6
		Entity_Speak(entity,math.floor(event.progress) ..'%   [img=technology/' .. event.choosen_tech..']')
		entity.surface.pollute(entity.position,25) 
		entity.surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=entity.position}
		entity.surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
		if math.random(13)==1 then CallFrenzyAttack(surface,entity.position) end
		if math.random(3)==1 then 
			entity.surface.create_entity{name="big-artillery-explosion", position=entity.position, force = game.forces.neutral}
			local target = get_random_pos_near(entity.position,40)
			entity.surface.create_entity{name ="maf-cluster-fire-projectile", target_position=target, position=target, source=entity, force= game.forces.enemy, speed=4}
			end
		if event.progress>=100 then advance_mission_control(event.mission_name,event) end
		end
	
	elseif mission_name == 'M_unique_msi_dorment_protomolecule' then 
	local entity = event.entity -- dorment_protomolecule
	local surface=entity.surface
	local mission_id = event.mission_id 
	if entity.surface == companion.surface and distance(companion.position,entity.position)<=15 then 
		entity.surface.create_entity{name = 'green-laser-beam', position=companion.position, source = companion, target_position=entity.position, duration=40}
		event.progress=event.progress + 0.4 -- test 10
		Entity_Speak(entity,math.floor(event.progress) ..'%')
		entity.surface.pollute(entity.position,10) 
		entity.surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
		create_spark_particles(surface, 50, entity.position,2)
		create_remnants_particles(surface, 1, entity.position,2)
		if math.random(10)==1 then CallFrenzyAttack(surface,entity.position) end
		if math.random(5)==1 then entity_shock_hazard(entity,25,math.random(4)) end
		if event.progress>=100 then 
			advance_mission_control(event.mission_name,event) 
			end
		end
	end
end


function droid_companion_repair(droid,droid_data)
local range = 13 + droid_data.level*2
local buildings = droid.surface.find_entities_filtered{force=droid.force, position=droid.position, radius=range}
local qt = 0
for _,e in pairs (buildings) do
	if e.name~='entity-ghost'  and e.valid and e.prototype and e.prototype.max_health and e.health and e~=droid  then   --and e.type and e.type~='character'
		if e.health<e.prototype.max_health then
			droid.surface.create_entity{name = 'green-laser-beam', position=droid.position, source = droid, target=e, duration=40}  --target_position=e.position
			e.health = e.health + droid_data.level*6
			qt = qt + 1
			if qt >= droid_data.level then break end
			end
		end
	end
end


-- helps building the silo
function synthethic_companion_build_silo(synthetic)
local buildings = synthetic.surface.find_entities_filtered{name=silo_names, force=synthetic.force, position=synthetic.position, radius=20}
local qt = 0
for _,e in pairs (buildings) do
	if e.products_finished % 2 ==0 then
		e.products_finished = e.products_finished + 1
		synthetic.surface.create_entity{name = 'green-laser-beam', position=synthetic.position, source = synthetic, target=e, duration=40}  --target_position=e.position
		break
		end
	end
end



function get_what_is_companion_doing(force,companion)
local companions = global.force_control[force.name].companions

local what_d

if companion=='droid' then 
	local droid_data = companions.droid
	local droid     = droid_data.entity
	local surfname = ''
	if droid and droid.valid then surfname =  get_se_zone_icon(droid.surface.name) .. droid.surface.name end
	if droid_data.following then what_d = {'labels.companion_doing_what',{'labels.following'},game.players[droid_data.following].name,surfname}
		elseif droid_data.stay_here then what_d = {'labels.companion_doing_what',{'labels.guarding'},get_gps_tag(droid_data.stay_here),surfname}
		elseif droid_data.science_what>0 then what_d = {'labels.companion_doing_what',{'labels.producing'}, droid_data.science_options[droid_data.science_what] ,surfname}
		elseif droid_data.harvest_what>0 then what_d = {'labels.companion_doing_what',{'labels.harvesting'}, droid_data.harvest_options[droid_data.harvest_what] ,surfname}
		elseif droid_data.boost_what>0 then what_d = {'labels.companion_doing_what',{'labels.boosting'},droid_data.boost_options[droid_data.boost_what] ,surfname}
		else  what_d = {'labels.companion_doing_what',{'labels.nothing'},'',surfname}
		end
elseif companion=='synthetic' then 
	local synthetic_data = companions.synthetic
	local synthetic = synthetic_data.entity
	local surfname = ''
	if synthetic and synthetic.valid then surfname =  get_se_zone_icon(synthetic.surface.name) .. synthetic.surface.name end
	if synthetic_data.following then what_d = {'labels.companion_doing_what',{'labels.following'},game.players[synthetic_data.following].name,surfname}
		elseif synthetic_data.stay_here then what_d = {'labels.companion_doing_what',{'labels.guarding'},get_gps_tag(synthetic_data.stay_here),surfname}
		elseif synthetic_data.go_home then what_d = {'labels.companion_doing_what',{'labels.going_home'},get_gps_tag(synthetic_data.go_home),surfname}
		else  what_d = {'labels.companion_doing_what',{'labels.nothing'},'',surfname}
		end
	end

return what_d
end


function check_synthetic_defense(synthetic,level)
if synthetic and synthetic.valid and game.tick % 1200 ==0 then 
	local e = synthetic.surface.find_nearest_enemy{position=synthetic.position, max_distance=32, force=synthetic.force}
	if e then 
		for x=1, level do 
			local ent ={'destroyer','defender','distractor'}
			local name = ent[math.random(#ent)]
			local target = synthetic
			if name=='defender' then target=nil end
			synthetic.surface.create_entity{name=name, position=get_random_pos_near(synthetic.position,5),target=target,force=synthetic.force}
			end
			
		if level>1 and math.random (4)==1 then
			if e and e.valid and e.type~='unit' then
				local weap = {'slowdown-capsule','poison-capsule'}
				synthetic.surface.create_entity{name=weap[math.random(#weap)], target=e, position=synthetic.position, force=synthetic.force, speed=0.4}
				end		
			end
		end
	end
end

function check_companions()
--cycle all forces
for F=1, #global.player_forces do
	local force_name = global.player_forces[F].force
	local home_name  = global.player_forces[F].surface
	
	if game.forces[force_name] and global.force_control[force_name] and #game.forces[force_name].connected_players>0 then
		local force = game.forces[force_name] 
		local companions = global.force_control[force.name].companions
		local droid_data = companions.droid
		local synthetic_data = companions.synthetic
		local droid     = droid_data.entity
		local synthetic = synthetic_data.entity
		
		if droid and droid.valid then
			local following = droid_data.following
			local stay_here = droid_data.stay_here
			local science_what = droid_data.science_what
			local harvest_what = droid_data.harvest_what
			local boost_what = droid_data.boost_what 
			local surface = droid.surface
			
			if following and game.players[following] and game.players[following].character and game.players[following].character.valid 
				and surface==game.players[following].surface 
				and distance(game.players[following].character.position, droid.position)>=10
				and distance(game.players[following].character.position, droid.position)<200 then 
					
					droid.follow_target = game.players[following].character
					--droid.autopilot_destination = game.players[following].character.position
				--elseif stay_here and distance(stay_here, droid.position)>=10 and distance(stay_here, droid.position)<150 then 
				--	droid.autopilot_destination = stay_here
				elseif boost_what>0 and math.random(3)==1 then 
					droid.surface.create_entity{name = "flying-text", position = {x=droid.position.x-1,y=droid.position.y-2}, text = "+ + +", color = colors.lightgreen}	
				elseif science_what>0 then companion_produces_something(droid,droid_data.science_available[science_what],science_what)
				elseif harvest_what>0 then companion_harvest(droid,droid_data.harvest_available[harvest_what],droid_data.level)
				
				end
			if droid_data.level>1 then droid_companion_repair(droid,droid_data) end
			

			end
		
		
		if synthetic and synthetic.valid then
			local following = synthetic_data.following
			local stay_here = synthetic_data.stay_here
			local go_home   = synthetic_data.go_home
			local surface = synthetic.surface
			
			if following and game.players[following] and game.players[following].character and game.players[following].character.valid 
				and surface==game.players[following].surface 
				and distance(game.players[following].character.position, synthetic.position)>=10 and 
					distance(game.players[following].character.position, synthetic.position)<200 then
					unit_go_to(synthetic,game.players[following].character)
				elseif stay_here and distance(stay_here, synthetic.position)>=10 then unit_go_to_loc(synthetic,stay_here) 
				elseif go_home and distance(go_home, synthetic.position)>=10 then unit_go_to_loc(synthetic,go_home,defines.distraction.none) 
				end

			
			for mission_name, event in pairs (synthetic_data.missions) do
				companion_has_mission(synthetic,mission_name,event) 
				end
				
			if synthetic_data.level>1 then check_synthetic_defense(synthetic,synthetic_data.level) end	
			if synthetic and synthetic.valid and synthetic.force.technologies['rocket-silo'].researched then 
				synthethic_companion_build_silo(synthetic)
				end
			
			end
		if game.tick%240==0 then update_companion_frames(game.forces[force_name]) end
		end
	end
end



function companion_produces_something(companion,what,dif)
if math.random (5+dif*3)==1 then 
local stack = {name=what, count=2}
local ship = global.force_control[companion.force.name].spaceship_wreck
if companion.can_insert(stack) then 
	companion.insert(stack)
	Entity_Speak(companion,'[item='..what..']',1)
	elseif ship and ship.valid and ship.surface==companion.surface and distance(companion.position,ship.position)<20 then 
	Entity_Speak(ship,'[item='..what..']',1)
	ship.insert(stack)
	end
end
end


function companion_harvest(companion,what,level)
local stack = {name=what, count=level}
if companion.can_insert(stack) then
	local range = 13 + level*2
	local ores = companion.surface.find_entities_filtered{type='resource', name=what, position=companion.position, radius=range, limit=50}
	for k=1,level*2 do
	if #ores>0 then
		local ore = ores[math.random(#ores)]
		if ore and ore.valid then
			local amount = ore.amount
			local ore_pos =ore.position
			local qt = level+1
			if qt>amount then qt=amount end
			companion.surface.create_entity{name = 'blue-laser-beam', position=companion.position, source = companion, target_position=ore_pos, duration=40}
			companion.insert({name=what, count=qt})
			if amount>qt then ore.amount=amount-qt else ore.destroy() break end
			end
		end
		end
	end
end



function show_companion_button(player,menu,state)
global.player_settings[player.name][menu] = state
if menu=='show_companion_button_droid' then 
	player.gui.top.bt_companion_droid.visible = state   
	if player.gui.screen.frame_droid then player.gui.screen.frame_droid.destroy() end
elseif menu=='show_companion_button_synthetic' then player.gui.top.bt_companion_synthetic.visible = state
	if player.gui.screen.frame_synthetic then player.gui.screen.frame_synthetic.destroy() end
	end
end


