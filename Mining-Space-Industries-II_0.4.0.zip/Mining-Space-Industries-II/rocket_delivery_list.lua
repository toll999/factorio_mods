-- in thousands
return {
	["steel-plate"] =       50,
	["advanced-circuit"]=   10,
	["processing-unit"]=	5,
	["rocket-fuel"]= 45,
	["battery"]=3,
	["low-density-structure"]=10,
	["uranium-rounds-magazine"]=10,
	["explosives"]=50,
	
	-- SE
	["se-vulcanite-block"]=50,
	["se-cryonite-rod"]=50,
	["se-beryllium-plate"]=20,
	["se-holmium-plate"]=20,
	["se-iridium-plate"]=20,
	["se-vitamelange-roast"]=20,
	
	-- KR
	["imersium-beam"]=20,
	
	-- IR
	["gold-ingot"]=50,
	["charged-battery"]=2,
	["charged-advanced-battery"]=1,
	["computer-mk2"]=5,
	["computer-mk3"]=1,
	["lead-plate-special"]=30,
	["tellurium-foil"]=30,	
	["stainless-beam"]=30,
	}