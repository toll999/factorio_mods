util = require("util")
colors = require("colors")
maf_icons = require("maf_icons")
format_number = util.format_number
require("utils")
local mod_gui = require("mod-gui")
local MSI_cargo_list = require("rocket_delivery_list")
require "cameras"
require "particles"
require "stdlib/area/chunk"
require "stdlib/area/area"
require "speech-bubbles"
require "control-functions"
require "control-informatron"
require "control-missions"
require "control-companions"
require "control-protomolecule"


-- vars
function avoid_game_ores()
return {'coal','stone','iron-ore','copper-ore','uranium-ore','se-core-fragment-omni','se-cryonite','se-vulcanite','se-holmium-ore','se-beryllium-ore','se-iridium-ore','se-vitamelange','tin-ore','gold-ore'}
end
function avoid_water_tiles()
return {"water","deepwater","water-green","deepwater-green","water-shallow","water-mud"}
end


function get_mission_categories()
return {'unique','science_packs','power','production','military','transportation','ultimate_techs','upgrades','space_rockets'}
end

--[[
Mission types: [status: faltam  unique(protomolecula), special bosses (night?, turret worm)]
- science_packs = Repair + Escort Droid
- military = Kill something
- power = Charge fallen accumulator
- production = Repair + Power to Craft machine
- upgrades = Green circuit connect Ship to Terminal
- ultimate_techs = Take companion to the fallen shipwreck
- transportation = Bring car back to ship
- space_rockets = Requires rocket launching 1 stack of something on different silos / locations
- unique:
	> oil-processing = Bring the Synthetic to an oil-pitch, it will test a sample to discover how to extract oil. "Lava" goes up. Spawns lava monsters?
	> robotics = Colocar itens na nave inicial ? Timer + waves + minhocas 
	> atomic-bomb = Some test with atomic explosion (it will explode / die). Pay items on the gui (via char) will trigger the effect. Timer + Boom

]]


function ReadRunTimeSettings(event)
global.settings.difficulty_level   = settings.global["msi-difficulty-level"].value
--if game and game.players['Coyote101'] then global.settings.difficulty_level = math.max(global.settings.difficulty_level,2) end

global.settings.mission_distance   = settings.global["msi-mission-distance-mp"].value
global.settings.turrets_prepare_time = 12+(global.settings.difficulty_level*2) -- seconds
global.settings.allow_mission_planets = settings.global["msi-allow-missions-other-planets"].value

if event and event.setting_type=='runtime-per-user' and event.setting=='msi-disable-camera-popup' then
	local player = game.players[event.player_index]
	global.disabled_player_camera[player.name] = settings.get_player_settings(player)["msi-disable-camera-popup"].value
	end

end
script.on_event(defines.events.on_runtime_mod_setting_changed, ReadRunTimeSettings)


function setup_mod_vars()
global.settings = global.settings or {}
global.wait_for_event = global.wait_for_event or {}
global.monitored_entity = global.monitored_entity or {}
global.player_forces    = global.player_forces or {} 
global.force_control    = global.force_control or {}
global.msi_informatron_menu = global.msi_informatron_menu or {}
global.registered_entities = global.registered_entities  or {}
global.registered_entities_unitnumber = global.registered_entities_unitnumber or {}
global.current_mission_ID = global.current_mission_ID or 0
global.control_e_tick = global.control_e_tick or {}
global.player_settings = global.player_settings or {}
setup_mission_techs_settings()
global.protomolecule_spawned_bases = global.protomolecule_spawned_bases or 0
global.surface_effects = global.surface_effects or {}

global.MSI_cargo_list = {}
for name,_ in pairs (MSI_cargo_list) do if game.item_prototypes["msi_" ..name.."_container"] then
	table.insert(global.MSI_cargo_list,"msi_" ..name.."_container")
	end end

global.msi_double_recipes = {'msi_double_advanced-circuit','msi_double_processing-unit','msi_double_low-density-structure','msi_double_rocket-fuel',
				'msi_double_speed-module','msi_double_productivity-module','msi_double_effectivity-module'}

if game.active_mods['IndustrialRevolution'] then 
	global.msi_double_recipes = {'msi_double_advanced-circuit','msi_double_processing-unit','msi_double_low-density-structure','msi_double_rocket-fuel',
				'msi_double_rocket-control-unit','msi_double_plastiglass','msi_double_advanced-battery'}
	end

ReadRunTimeSettings()
end


function reset_all_mod_vars()
global = {}

cam_on_init()
setup_mod_vars()
table.insert(global.wait_for_event,{event='initialize_game_settings'})

for _,player in pairs (game.players) do 
	init_player_settings_and_gui(player)
	end
end



function on_init()
game.map_settings.max_failed_behavior_count = 50
cam_on_init()
setup_mod_vars()
register_other_mod_events()
setup_forces()
if not game.active_mods['team_competition'] then 
	table.insert(global.player_forces,{force='player',surface='nauvis'})
	table.insert(global.wait_for_event,{event='initialize_force_settings', player_force=global.player_forces[1]})
	end
table.insert(global.wait_for_event,{event='initialize_game_settings'})
end
script.on_init(on_init)



function on_configuration_changed()
cam_on_init()
setup_mod_vars()
update_all_forces_settings()
bug_fixes()
if game.active_mods['space-exploration'] then add_planet_effects() end
end
script.on_configuration_changed(on_configuration_changed)



local function On_Load()
register_other_mod_events()  -- event handlers only
end
script.on_load(On_Load)


function bug_fixes() 

-- ups save	
for k=#global.monitored_entity,1,-1 do
	local entity = global.monitored_entity[k].entity
	if entity and entity.valid and entity.name=='msi_protomolecule_artillery' then
		table.remove(global.monitored_entity,k)
		end
	end	
	
--'M_military'
end


function setup_forces()
if not game.forces["protomolecule"] then 
	local p=game.create_force("protomolecule")
	p.ai_controllable = true
	p.evolution_factor=0.75
	protomolecule_add_damage_bonuses(0.5)
	end
end

function register_other_mod_events()

script.on_event(remote.call("RocketSiloCon", "get_on_silo_stage_finished"), function (event)
	on_silo_stage_finished(event)
   end)

if remote.interfaces["portals"] then 
  script.on_event(remote.call("portals", "get_on_player_placed_portal_event"), function(event)
    --on_portal_built_event(event)
  end)	
	end

if remote.interfaces["space-exploration"] then 
   script.on_event(remote.call("space-exploration", "get_on_cargo_rocket_launched_event"), function (event)
	on_cargo_rocket_launched(event)
   end)
end

if remote.interfaces["silo_script"] then
	remote.call("silo_script","set_no_victory", true)
--	remote.call("silo_script","remove_tracked_item", "satellite")
	end

end


function setup_other_mods()
-- SPACE EXPLORATION
global.se_universe = {}
global.se_universe.by_index = {}
global.se_universe.by_name = {}

remote.call("RocketSiloCon", "add_automated_force","protomolecule")   


if game.active_mods['space-exploration'] then 
	local universe = remote.call("space-exploration", "get_zone_index", {})
	for p=1,#universe do
		local se = universe[p]
		local type = se.type -- "planet / moon"
		local index = se.index
		local name = se.name 
		
		if type and name and index and in_list({"planet","moon"},type) then
			local tags = se.tags
			local radius = se.radius
			local primary_resource = se.primary_resource
			local enemy_base = se.controls["enemy-base"] --      frequency = 1e-06,    richness = -1,  size = -1
			local icon =  '[img='..remote.call("space-exploration", "get_zone_icon", {zone_index = index})..']'
			local astro = {index=index,name=name,type=type,tags=tags,radius=radius,primary_resource=primary_resource, enemy_base=enemy_base, icon=icon, missions=0}
			
			global.se_universe.by_index[index] = astro
			global.se_universe.by_name[name] = astro
			if name=='Nauvis' then 
				astro.missions=10
				global.se_universe.by_name['nauvis'] = table.deepcopy(astro)
				end
			end
		end
	add_planet_effects()
	end
	
	
end

function se_update_known_zones(force) -- get the player force discovered zones on SE
if game.active_mods['space-exploration'] then 
global.force_control[force.name].se_known_zones = remote.call("space-exploration", "get_known_zones", {force_name = force.name})
end
end


function choose_se_planet_for_effetc(effect,requirements) 
local opt1 = {}
for index,astro in pairs (global.se_universe.by_index) do
	if (astro.name~='Nauvis') and (astro.name~='nauvis') then 
		if not astro.effect then 
			if requirements.type=='enemy' then 
				if astro.enemy_base and astro.enemy_base.frequency>=requirements.value and astro.enemy_base.frequency<=requirements.max and
					astro.enemy_base.size>=requirements.value and astro.enemy_base.size<=requirements.max then
					table.insert(opt1,index)
					end 
					end
			end
		end
	end

local id = opt1[math.random(#opt1)] 
local zone = global.se_universe.by_index[id]
zone.effect = effect
return zone.name 
end
	
function add_planet_effects()

local effects = {{name='only_big_spawners', requirements={type='enemy',value=1.3, max=5}, count=3 + global.settings.difficulty_level}}
local check = {}

for surfname, effect in pairs (global.surface_effects) do
    check[effect] = (check[effect] or 0) + 1
	end
	
for e=1,#effects do
	local effect = effects[e]
	if not check[effect.name] then check[effect.name] =0 end
    if effect.count > check[effect.name] then
		local qt = effect.count - check[effect.name]
		for c=1,effect.count - check[effect.name] do
			local planet_name = choose_se_planet_for_effetc(effect.name,effect.requirements)
			if planet_name then global.surface_effects[planet_name]=effect.name end
			end
		end
	end
end


function on_silo_stage_finished(event)
local silo = event.created_entity
if silo.force==game.forces.protomolecule then 
	table.insert(global.monitored_entity,{entity=silo,event="protomolecule_activity",tab_event={progress=0}})
	end
end



-- CLICK
local function on_gui_click(event)
cam_on_gui_click(event)

local element = event.element
local player = game.players[event.player_index]
if element and element.valid then 
	local name = event.element.name
	local force_name = player.force.name

	if string.sub(name,1,15)=="bt_mission_cam_" then 
			local mission_name_vkey = element.parent.name
			local c=tonumber(string.sub(name,16,17)) --camera = {entity=entity,surface=surface,position=position,icon='[img=entity/crash-site-lab-repaired]', text=cam_text}
			local camera = global.msi_informatron_menu[force_name .. '<CAMERAS>'][mission_name_vkey][c]
			local cam_on = camera.entity
			if (not (cam_on and cam_on.valid)) and (camera.position) then cam_on = camera.position end
			local surface=game.surfaces[camera.surface_name]
			if surface and surface.valid then 
				CreateCameraForPlayer(player,cam_on,surface,camera.text,nil) 
				closes_informatron(player)
				else
				player.print({'labels.cant_open_camera_se'}, colors.yellow)
				end

		elseif name == "bt_companion_synthetic" then 
			local gui = player.gui.screen
			if gui.frame_synthetic then gui.frame_synthetic.destroy() else 
				create_gui_synthetic(player, gui)
				gui.frame_synthetic.force_auto_center()
				end
		elseif name == "bt_companion_droid" then 
			local gui = player.gui.screen
			if gui.frame_droid then gui.frame_droid.destroy() else 
				create_gui_droid(player, gui)
				gui.frame_droid.force_auto_center()
				end
				
		elseif name == "bt_destroy_my_parent" then element.parent.destroy() 
		elseif name == "bt_destroy_my_2parent" then element.parent.parent.destroy() 
		elseif name == "bt_destroy_my_3parent" then element.parent.parent.parent.destroy() 
		elseif name == "bt_cancel_receive_free_tech" then bt_cancel_receive_free_tech(player,element.parent.name)
		elseif name == "bt_save_message_board" then save_message_board(element,player)
		elseif string.sub(name,1,12)=="bt_companion" then bt_companion_clicked(name,player,element)
		elseif string.sub(name,1,17)=="bt_mission_items_" then bt_track_mission_items(name,player)
		
		elseif element.parent and in_list({'msi_recover_free_tech',"msi_receive_free_tech"},element.parent.name)  then receive_free_tech(player,element.name,element.parent.parent)
		
		end


end
end
script.on_event(defines.events.on_gui_click, on_gui_click)



function update_player_tracking_screens()
for _,player in pairs (game.connected_players) do
	if global.player_settings and global.player_settings[player.name] and global.player_settings[player.name].tracking_items then
		for s=#global.player_settings[player.name].tracking_items,1,-1 do
			local name=global.player_settings[player.name].tracking_items[s]
			local vkey = string.sub(name,18,200)
			if player.gui.screen["msi_track_items" .. vkey] then bt_track_mission_items(name,player)
				else table.remove(global.player_settings[player.name].tracking_items,s) end
			end
		end
end
end


function bt_track_mission_items(name,player)
local vkey = string.sub(name,18,200)
local required_items = global.msi_informatron_menu[player.force.name .. '<REQUIRED_ITEMS>'][vkey]
local gui = player.gui.screen

if gui["msi_track_items" .. vkey] then 
	local tab = gui["msi_track_items" .. vkey].tab
	for r=1,#required_items do
		local print_icon = maf_icons.check_red
		if check_container_for_items(player,{required_items[r]}) then print_icon = maf_icons.check_green end
		tab['icon'..r].caption = print_icon
		end
	
	else
	local frame = add_gui (gui,{type = "frame", name = "msi_track_items" .. vkey , caption ={'labels.track-items'}, direction = "vertical"},true)
	frame.add{type = "label", caption = {'labels.required-items'}}.style.font = "default-large-semibold"
		local tab = add_gui (frame, {type = "table",  name='tab', column_count = 2})
		for r=1,#required_items do
			local lname = get_localized_name(required_items[r].name)
			local item = {'',required_items[r].count ..'[img=item/'..required_items[r].name..'] ',  lname}
			local print_icon = maf_icons.check_red
			if check_container_for_items(player,{required_items[r]}) then print_icon = maf_icons.check_green end
			tab.add{type = "label", caption = item}
			tab.add{type = "label", caption = print_icon, name='icon'..r}
			end
	frame.add{name='bt_destroy_my_parent', type="button", style = 'rounded_button', caption={'labels.close'}} 
	frame.force_auto_center()
	global.player_settings[player.name].tracking_items = global.player_settings[player.name].tracking_items or {}
	table.insert (global.player_settings[player.name].tracking_items, name)
	end
end


-- DROPDOWN
local function on_gui_selection_state_changed(event) 
local gui = event.element
local player = game.players[event.player_index]

if string.sub(gui.name,1,12)=="bt_companion" then bt_companion_dropdown_selected(gui,player) end
end
script.on_event(defines.events.on_gui_selection_state_changed, on_gui_selection_state_changed)

--picker
local function on_gui_elem_changed(event) 
local gui = event.element
local player = game.players[event.player_index]

if gui.name=="message_board_icon_picker" then add_icon_message_board(gui) end
end
script.on_event(defines.events.on_gui_elem_changed, on_gui_elem_changed)

--checkbox
local function on_gui_checked_state_changed(event) 
local gui = event.element
local player = game.players[event.player_index]
if gui.name=="hide_menu_mission_acc" or gui.name=="hide_menu_mission_fail" then informatron_hide_tab(player,gui.name,gui.state) 
	elseif gui.name=="show_companion_button_droid" or gui.name=="show_companion_button_synthetic" then show_companion_button(player,gui.name,gui.state) 
	end
end
script.on_event(defines.events.on_gui_checked_state_changed, on_gui_checked_state_changed)



------------------------------------------------------------------------------------------

function init_player_settings_and_gui(player)
global.player_settings[player.name] = global.player_settings[player.name] or {}
global.player_settings[player.name].show_companion_button_droid = global.player_settings[player.name].show_companion_button_droid or true
global.player_settings[player.name].show_companion_button_synthetic = global.player_settings[player.name].show_companion_button_synthetic or true
global.player_settings[player.name].hide_menu_mission_acc = global.player_settings[player.name].hide_menu_mission_acc or false
global.player_settings[player.name].hide_menu_mission_fail = global.player_settings[player.name].hide_menu_mission_fail or false

if game.active_mods['team_competition'] then 
	global.player_settings[player.name].show_companion_button_droid = false
	global.player_settings[player.name].show_companion_button_synthetic = false
	end


local gui = player.gui.top
  
--local gui = mod_gui.get_frame_flow(player)
--local maf_main_menu_frame = gui.maf_main_menu_frame
--if not maf_main_menu_frame then maf_main_menu_frame=gui.add{name="maf_main_menu_frame", direction = "vertical", type="frame", style=mod_gui.frame_style} end
--	tc_frame.style.minimal_height = 100
-- 	Topframe.style.maximal_height = 37
--	Topframe.style.minimal_width = 100

  local button = gui.bt_companion_droid
  if not button then
    button = gui.add
    {
      type = "sprite-button",
      name = "bt_companion_droid",
      style = mod_gui.button_style,
      sprite = "entity/msi_companion_droid_1",
      tooltip = {'entity-name.msi_companion_droid'}
    }
  end
  button.visible = global.player_settings[player.name].show_companion_button_droid


  local button = gui.bt_companion_synthetic
  if not button then
    button = gui.add
    {
      type = "sprite-button",
      name = "bt_companion_synthetic",
      style = mod_gui.button_style,
      sprite = "entity/msi_companion_synthetic_melee_1",
      tooltip = {'entity-name.msi_companion_synthetic'}
    }
  end
  button.visible = global.player_settings[player.name].show_companion_button_synthetic
   

end


script.on_event(defines.events.on_player_joined_game, function(event)
local player = game.players[event.player_index]
init_player_settings_and_gui(player)
end)

------------------------------------------------------------------------------------------


local function on_tick(event)
cam_on_tick(event)
end
script.on_event(defines.events.on_tick, on_tick )


function setup_mission_techs_settings()
--[[
science_packs = 18    /8
transportation = 12   /6
power = 12            /6
production = 11       /7
military = 12         /18
upgrades = 18         /9
ultimate_techs = 7+mods
space_rockets = 3

TOTAL 93  / 63
]]

-- VANILLA
global.mission_techs = {}
global.mission_techs.unique = {'oil-processing'} --'robotics', 'atomic-bomb'
global.mission_techs.science_packs={"logistic-science-pack","chemical-science-pack",
									"military-science-pack","utility-science-pack","production-science-pack"} --        {"space-science-pack", 1}

global.mission_techs.transportation = {'engine','railway','tank','fluid-wagon'} --'automobilism'
global.mission_techs.power = {
	'solar-energy','electric-energy-distribution-2','electric-energy-accumulators','laser',
	'uranium-processing','nuclear-power'}
global.mission_techs.production = {
	'logistics-2','logistics-3','automation-3','advanced-material-processing-2',  --'advanced-material-processing',
	'modules'}
global.mission_techs.space_rockets = {'msi_protomolecule_scan', 'atomic-bomb','spidertron'} --not for space exploration
global.mission_techs_space_rockets_items = {
		['atomic-bomb']='nuclear-fuel',
		['spidertron']='uranium-fuel-cell',
		['msi_protomolecule_scan']='satellite',		
		}
global.mission_techs.upgrades = {
	'military-3','military-4','rocketry','flamethrower','energy-shield-equipment',
	'explosive-rocketry','artillery','power-armor-mk2','msi_sniper_rifle',}

global.mission_techs.ultimate_techs = {'advanced-oil-processing','robotics','modular-armor','effect-transmission','logistic-system','kovarex-enrichment-process','rocket-silo'}

global.mission_techs.military = {}



if game.active_mods['IndustrialRevolution'] then
	table.insert (global.mission_techs.science_packs,'ir2-steel-milestone')
	table.insert (global.mission_techs.science_packs,'ir2-nickel-milestone')
	table.insert (global.mission_techs.science_packs,'ir2-stainless-milestone')
	table.insert (global.mission_techs.transportation,'ir2-transmat')
	global.mission_techs.power = {'ir2-advanced-batteries','ir2-solar-energy-1','ir2-solar-energy-2','electric-energy-distribution-2','electric-energy-accumulators','laser',
	'uranium-processing','nuclear-power'}
	global.mission_techs.production = {'ir2-furnaces-2','ir2-furnaces-3','ir2-washing-1','ir2-mining-1','ir2-mining-2',
	'logistics-2','logistics-3','automation-3'}
	table.insert (global.mission_techs.ultimate_techs,'ir2-arc-turret')
	table.insert (global.mission_techs.ultimate_techs,'ir2-pressing')
	end

for k=1,6 do  if k%2==0 then
	if not game.active_mods['IndustrialRevolution'] then table.insert (global.mission_techs.science_packs,'research-speed-'..k) end
	table.insert (global.mission_techs.transportation,'worker-robots-speed-'..k)
	--table.insert (global.mission_techs.science_packs ,'msi_companion_droid_tech-'..k)
	--table.insert (global.mission_techs.power,'msi_companion_synthetic_tech-'..k)
	end end
for k=1,6 do if k%2==0 then
	table.insert (global.mission_techs.military,'weapon-shooting-speed-'..k)  -- up to 6
	table.insert (global.mission_techs.military,'physical-projectile-damage-'..k) -- up to 7
	table.insert (global.mission_techs.military,'stronger-explosives-'..k) -- up to 7
	table.insert (global.mission_techs.military,'refined-flammables-'..k) -- up to 7
	table.insert (global.mission_techs.military,'laser-shooting-speed-'..k) -- up to 7  --"laser-turret-speed-2"
	table.insert (global.mission_techs.military,'energy-weapons-damage-'..k) -- up to 7
	
	
	if game.active_mods['RampantArsenal'] then 
		table.insert (global.mission_techs.military,'rampant-arsenal-technology-bullet-speed-'..k) 
		table.insert (global.mission_techs.military,'rampant-arsenal-technology-bullet-damage-'..k) 
		table.insert (global.mission_techs.military,'rampant-arsenal-technology-stronger-explosives-'..k) 
		table.insert (global.mission_techs.military,'rampant-arsenal-technology-energy-weapons-damage-'..k) 
		end
	
	end end
for k=1,4 do if k%2==0 then table.insert (global.mission_techs.production,'mining-productivity-'..k) end end


if game.active_mods['jetpack'] then 
	table.insert(global.mission_techs.ultimate_techs,'jetpack-1') 
	end
if game.active_mods['space-exploration'] then 
	table.insert (global.mission_techs.science_packs,'se-rocket-science-pack')
--	table.insert(global.mission_techs.ultimate_techs,'industrial-furnace')
	table.insert(global.mission_techs.ultimate_techs,'se-spaceship') -- in other planets
	table.insert(global.mission_techs.ultimate_techs,'se-naquium-cube')
	table.insert(global.mission_techs.ultimate_techs,'se-naquium-tessaract')
	table.insert(global.mission_techs.ultimate_techs,'se-antimatter-reactor')
	table.insert(global.mission_techs.ultimate_techs,'se-antimatter-engine')
	table.insert(global.mission_techs.ultimate_techs,'se-energy-beaming')
	table.insert(global.mission_techs.ultimate_techs,'se-space-elevator')
	
	table.insert(global.mission_techs.military,'se-cryogun')
	table.insert(global.mission_techs.military,'se-biogun')	
	table.insert(global.mission_techs.military,'se-plague')	
	table.insert(global.mission_techs.military,'se-railgun')
	table.insert(global.mission_techs.military,'se-tesla-gun')
	table.insert(global.mission_techs.military,'se-delivery-cannon-weapon')
	
	table.insert(global.mission_techs.power,'se-addon-power-pole')
	table.insert(global.mission_techs.power,'se-pylon-substation')
	table.insert(global.mission_techs.power,'se-space-accumulator')
	table.insert(global.mission_techs.power,'se-big-heat-exchanger')

	table.insert(global.mission_techs.production,'se-wide-beacon')	
	table.insert(global.mission_techs.production,'se-pylon-construction')
	
	global.mission_techs.space_rockets = {'msi_protomolecule_scan','atomic-bomb','spidertron',
											'se-astronomic-science-pack-1',
											'se-biological-science-pack-2','se-deep-space-science-pack-2',
											'se-energy-science-pack-4',
											'se-material-science-pack-3',
											}  --'se-astronomic-science-pack-3','se-energy-science-pack-2'
	global.mission_techs_space_rockets_items = {
												['spidertron']='uranium-fuel-cell',
												['atomic-bomb']='nuclear-fuel',	
												['msi_protomolecule_scan']='satellite',														
												['se-deep-space-science-pack-2']='se-naquium-cube',
												['se-astronomic-science-pack-1']='se-beryllium-plate',
												--['se-astronomic-science-pack-3']='se-astronomic-insight',
												['se-biological-science-pack-2']='se-experimental-specimen',
												--['se-energy-science-pack-2']='se-holmium-plate',
												['se-energy-science-pack-4']='se-energy-insight',
												['se-material-science-pack-3']='se-material-insight'}

	end


-- other mods
if game.active_mods['aai-vehicles-ironclad'] then table.insert(global.mission_techs.transportation,'ironclad') end
if game.active_mods['Repair_Turret'] then table.insert(global.mission_techs.ultimate_techs,'repair-turret-construction') end
if game.active_mods['portals'] then table.insert(global.mission_techs.ultimate_techs,'portals') end
if game.active_mods['OmegaDrill'] then table.insert(global.mission_techs.ultimate_techs,'omega-drill') end
if game.active_mods['NapalmArtillery'] then table.insert(global.mission_techs.ultimate_techs,'napalm-artillery-shell-tech') end
if game.active_mods['Electric-Weapons'] then table.insert(global.mission_techs.ultimate_techs,'sw-tech-electric-gun') end
if game.active_mods['Mining_Drones'] then table.insert(global.mission_techs.ultimate_techs,'mining_drones_tech') end
if game.active_mods['stargate'] then table.insert(global.mission_techs.ultimate_techs,'stargate_sgu') end
 
if game.active_mods['Krastorio2'] then -- there is no nuclear-fuel on k2
	global.mission_techs_space_rockets_items['atomic-bomb']='uranium-fuel-cell'
	table.insert (global.mission_techs.science_packs,'kr-advanced-tech-card')
	table.insert (global.mission_techs.science_packs,'kr-singularity-tech-card')
	table.insert (global.mission_techs.science_packs,'kr-matter-tech-card')
	table.insert (global.mission_techs.ultimate_techs,'kr-matter-processing')
	table.insert (global.mission_techs.production,'kr-quantum-computer')
	table.insert (global.mission_techs.power,'kr-antimatter-reactor')
	table.insert(global.mission_techs.military,'kr-antimatter-ammo')
	end
 
if game.active_mods['shield-projector'] then -- there is no nuclear-fuel on k2
	table.insert(global.mission_techs.power,'shield-projector') -- another mod 
	end

end

function find_mission_category(tech)
local cat
for category,list in pairs(global.mission_techs) do
	if in_list(list,tech) then cat=category break end
	end
return cat	
end


function lock_mission_techs(force)
local locked_list = {'msi_tech_lock_satellites','msi_tech_lock_cargo_delivery'}
for x=1,#locked_list do 
	if not force.technologies[locked_list[x]].researched then force.technologies[locked_list[x]].enabled=false end
	end

local cur_res = force.current_research
if cur_res then cur_res = force.current_research.name end

for t,tab in pairs (global.mission_techs) do
	for k=#global.mission_techs[t],1,-1 do 
		local tech = global.mission_techs[t][k]
		if force.technologies[tech] then
			table.insert (locked_list,tech)
			force.technologies[tech].visible_when_disabled = true
			if (not force.technologies[tech].researched) and 
			   (not force.get_saved_technology_progress(tech)) and 
			   ((not cur_res) or cur_res~=tech) and
			   (not in_list(global.force_control[force.name].unlocked_techs, tech)) then
					force.technologies[tech].enabled=false 
					else
					force.technologies[tech].enabled=true
				end
			else 
				game.print('MSI2 ERROR: tech invalid:' ..tech .. '. Removing it from missions...') 
				table.remove (global.mission_techs[t],k)
				end
		end
	end

-- checking other techs not in locked_list
for tech, proto in pairs (force.technologies) do
	if (not in_list(locked_list,tech)) and force.technologies[tech].visible_when_disabled and (not force.technologies[tech].enabled) then 
		force.technologies[tech].enabled=true
		end
	end
end


function initialize_game_settings()
setup_mission_techs_settings()
setup_other_mods()
end

function initialize_force_settings(player_force)
local fname = player_force.force
local force   = game.forces[fname]
local surface = game.surfaces[player_force.surface]
local spawn_pos  = force.get_spawn_position(surface)

-- Local or create spaceship
local wreckname = 'crash-site-spaceship'
local spaceship_wreck = surface.find_entities_filtered{name=wreckname, position=spawn_pos, radius=100, limit=1}
if #spaceship_wreck==1 then spaceship_wreck=spaceship_wreck[1]
	else
	local pos = surface.find_non_colliding_position(wreckname, spawn_pos, 0, 1) or spawn_pos
	spaceship_wreck = surface.create_entity{name=wreckname, position=pos, force=force}
	end
spaceship_wreck.destructible=false
spaceship_wreck.minable=false

-- remove near oil and destroy krastorio entities
local de=surface.find_entities_filtered{
	name={"crude-oil",'kr-crash-site-lab-repaired','kr-crash-site-assembling-machine-2-repaired','kr-crash-site-assembling-machine-1-repaired','kr-crash-site-generator',
			"aai-big-ship-wreck-1","aai-big-ship-wreck-2","aai-big-ship-wreck-3"},
	position=spawn_pos, radius=100}
for k=1,#de do de[k].destructible=true de[k].destroy() end



-- initial items
spaceship_wreck.insert{name='iron-plate', count=math.random(100,200)}
spaceship_wreck.insert{name='copper-plate', count=math.random(100,200)}
spaceship_wreck.insert{name='transport-belt', count=math.random(20,100)}
spaceship_wreck.insert{name='inserter', count=math.random(10,30)}
spaceship_wreck.insert{name='medium-electric-pole', count=math.random(15,30)}
spaceship_wreck.insert{name='landfill', count=math.random(100,200)}
if game.item_prototypes["broken_droid"] then spaceship_wreck.insert{name='broken_droid', count=2}	end



-- set starting missions
if not game.active_mods['IndustrialRevolution'] then --skip if IR

	-- initial lab recipes
	if force.recipes['basic-tech-card'] then force.recipes['basic-tech-card'].enabled=false 
	else force.recipes['automation-science-pack'].enabled=false end

	if force.recipes['burner-lab'] then force.recipes['burner-lab'].enabled=false 
	 else force.recipes['lab'].enabled=false end   
	local placing_data= {surface=surface,
						 entity_name='msi_broken_lab',
						 force=force,
						 ungenerated_chunk=false,
						 chunk_distance=8,
						 from_position=force.get_spawn_position(surface),
						 avoid_near = avoid_game_ores(),
						 avoid_near_tile = avoid_water_tiles(),						 
						 extraInfo={mission_name ='MI_001_broken_lab'}}
	table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick+ 60*(30 + math.random (25)), data_table=placing_data})
end

local placing_data= {surface=surface,
					 entity_name='msi-broken-generator',
					 force=force,
					 ungenerated_chunk=false,
					 chunk_distance=2,
					 from_position=force.get_spawn_position(surface),
					 avoid_near = avoid_game_ores(),	
					 avoid_near_tile = avoid_water_tiles(),	
					 extraInfo={mission_name ='MI_002_broken_generator'}
					 }
table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick+ 120*(70 + math.random (70)), data_table=placing_data})

local placing_data= {surface=surface,
					 entity_name='big-ship-wreck-2',
					 force=force,
					 ungenerated_chunk=false,
					 chunk_distance=8,
					 avoid_near_tile = avoid_water_tiles(),						 
					 from_position=force.get_spawn_position(surface),
					 extraInfo={mission_name ='MI_010_machines_shipwreck'}
					 }
local tick = game.tick + 60*60*(30 + math.random (10))					 
table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=tick, data_table=placing_data})

local placing_data= {surface=surface,
					 entity_name='big-ship-wreck-2',
					 force=force,
					 ungenerated_chunk=false,
					 chunk_distance=8,
					 avoid_near_tile = avoid_water_tiles(),						 
					 from_position=force.get_spawn_position(surface),
					 extraInfo={mission_name ='MI_011_military_shipwreck'}
					 }
local tick = game.tick + 60*60*(45 + math.random (10))					 
table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=tick, data_table=placing_data})


global.force_control[fname] = global.force_control[fname] or {}
global.force_control[fname].home_surface=surface
global.force_control[fname].spaceship_wreck=spaceship_wreck

update_force_settings(force)
end


function update_force_settings(force)
local fname = force.name
if not global.force_control[fname] then return end --weird crash reported
global.force_control[fname].spawned_missions = global.force_control[fname].spawned_missions or {} -- indexed by mission_category, with list of techs
global.force_control[fname].unlocked_techs = global.force_control[fname].unlocked_techs or {}
global.force_control[fname].entities = global.force_control[fname].entities or {}
global.force_control[fname].message_board = global.force_control[fname].message_board or {text='',last_user='', tick=0}
global.force_control[fname].companions = global.force_control[fname].companions or {}
global.force_control[fname].companions.synthetic = global.force_control[fname].companions.synthetic or {} -- level, entity, spawn_wreck, gear_type, missions={}
global.force_control[fname].companions.synthetic.missions = global.force_control[fname].companions.synthetic.missions or {} -- level, entity, spawn_wreck, gear_type, missions={}
global.force_control[fname].companions.droid = global.force_control[fname].companions.droid or {} -- level, entity, spawn_wreck, activity{repair/science}
global.force_control[fname].companions.droid.missions = global.force_control[fname].companions.droid.missions or {}
global.force_control[fname].rocket_launch_missions = global.force_control[fname].rocket_launch_missions or {}
global.force_control[fname].research_missions = global.force_control[fname].research_missions or {}
global.force_control[fname].rocket_silo_sites = global.force_control[fname].rocket_silo_sites or {}
global.force_control[fname].se_known_zones=global.force_control[fname].se_known_zones or {}


--global.force_control[fname].informatron_menu = {}

-- informatron menu
global.msi_informatron_menu[fname] = global.msi_informatron_menu[fname] or {
    technologies=1,
    companion_units=1,
	message_board=1,	
	missions = {
		current_missions={},  --science_packs = mission_id
		accomplished_missions={},
		failed_missions={},
		},
	}
 
-- version updates 
if not global.msi_informatron_menu[fname].message_board then global.msi_informatron_menu[fname].message_board=1 end

global.msi_informatron_menu[fname .. '<MISSION_GROUP>'] = global.msi_informatron_menu[fname .. '<MISSION_GROUP>'] or {}
global.msi_informatron_menu[fname .. '<REWARD>'] = global.msi_informatron_menu[fname .. '<REWARD>'] or {}
global.msi_informatron_menu[fname .. '<PICTURES>'] =global.msi_informatron_menu[fname .. '<PICTURES>'] or {}
global.msi_informatron_menu[fname .. '<ENTITIES>'] =global.msi_informatron_menu[fname .. '<ENTITIES>'] or  {}
global.msi_informatron_menu[fname .. '<CAMERAS>'] = global.msi_informatron_menu[fname .. '<CAMERAS>'] or {}
global.msi_informatron_menu[fname .. '<START_TICK>'] = global.msi_informatron_menu[fname .. '<START_TICK>'] or {}
global.msi_informatron_menu[fname .. '<ACCOMPLISHED_TICK>'] = global.msi_informatron_menu[fname .. '<ACCOMPLISHED_TICK>'] or {}
global.msi_informatron_menu[fname .. '<FAIL_TICK>'] = global.msi_informatron_menu[fname .. '<FAIL_TICK>'] or {}
global.msi_informatron_menu[fname .. '<EXTRA_TEXT>'] =global.msi_informatron_menu[fname .. '<EXTRA_TEXT>'] or {}
global.msi_informatron_menu[fname .. '<REQUIRED_ITEMS>'] =global.msi_informatron_menu[fname .. '<REQUIRED_ITEMS>'] or {}


--fix renamed techs on v 1.1
--[[
local renames = {}
for k=1,7 do renames["laser-turret-speed-"..k] = 'laser-shooting-speed-'..k end
renames['turrets'] = 'gun-turret'
renames['laser-turrets'] = 'laser-turrets'
renames['tanks'] = 'tank'
for vkey, content in pairs (global.msi_informatron_menu[fname .. '<REWARD>']) do
	if content then
		for r=1,#content do
			local REWARD = content[r]
			if REWARD.type == 'unlock_tech' then 
					local techs = REWARD.techs
					local auto_research = REWARD.auto_research
					for t=1,#techs do 
						local tech= techs[t]
						if renames[tech] then REWARD.techs[t]=renames[tech] end
						end
				end
			end
		end
	end
for category,list in pairs(global.force_control[fname].spawned_missions) do
	for x=1,#list do 
		if renames[list[x] ] then 
			global.force_control[fname].spawned_missions[category][x] = renames[list[x ] ] 
			end
		end
	end
]]

-- fix for k2
if game.active_mods['Krastorio2'] then -- there is no nuclear-fuel on k2
	for mid, rlm in pairs (global.force_control[fname].rocket_launch_missions) do
		if rlm.rocket_launch_request.items_required.name == 'nuclear-fuel' then 
			rlm.rocket_launch_request.items_required.name = 'uranium-fuel-cell' end
		end
	end


-- fix for se
if game.active_mods['space-exploration'] then
	for mid, rlm in pairs (global.force_control[fname].rocket_launch_missions) do
		if rlm.rocket_launch_request.items_required.name == 'se-significant-specimen' then 
			rlm.rocket_launch_request.items_required.name = 'se-experimental-specimen' end
		end
	end

local repaired_lab=false
-- re-enable recipes (some other mod is disabling it) - fount it is AAIndustries
for vkey, _ in pairs (global.msi_informatron_menu[fname..'<ACCOMPLISHED_TICK>']) do
	if string.find(vkey,'MI_001_broken_lab') then repaired_lab=true end
	local REWARDS = global.msi_informatron_menu[fname..'<REWARD>'][vkey]
	if REWARDS then
		for r=1,#REWARDS do
			local REWARD = REWARDS[r]
			if REWARD.type == 'unlock_recipe' then 
				local recipes = REWARD.recipes
				for r=1,#recipes do
					local recipe = recipes[r]
					if game.forces[fname].recipes[recipe] then game.forces[fname].recipes[recipe].enabled=true end
					end
				end
			end
		end
	end

-- fix AAIndustries resetting force recipes
if not game.active_mods['IndustrialRevolution'] then --skip if IR

	if force.recipes['basic-tech-card'] then force.recipes['basic-tech-card'].enabled=repaired_lab 
	else force.recipes['automation-science-pack'].enabled=repaired_lab end

	if force.recipes['burner-lab'] then force.recipes['burner-lab'].enabled=force.technologies['laboratory'].researched
	 else force.recipes['lab'].enabled=force.technologies['laboratory'].researched end   
	end



-- fix for cargo recipe beeing disabled by other mod
for mid, rlm in pairs (global.force_control[fname].rocket_launch_missions) do
	local item_name = rlm.rocket_launch_request.items_required.name
	if string.find(item_name, "msi_") and string.find(item_name, "_container") and game.forces[fname].recipes[item_name] then 
		game.forces[fname].recipes[item_name].enabled=true
		end
	end



if is_mission_accomplished(force,'M_unique_msi_protomolecule_spawner_boss') and 
	(not force.technologies['msi_protomolecule_antidote_bomb'].enabled) then 
	force.technologies['msi_protomolecule_antidote_bomb'].enabled=true
	register_research_mission(force, 'msi_protomolecule_antidote_bomb')
	end


-- fix for bosses disapearing
if global.msi_informatron_menu[fname .. '<MISSION_GROUP>']['M_military'] then 
	for mission_id, mstatus in pairs (global.msi_informatron_menu[fname .. '<MISSION_GROUP>']['M_military']) do
		if mstatus=='ACTIVE' then
			local vkey = 'M_military' .. mission_id
			local boss= global.msi_informatron_menu[fname .. '<ENTITIES>'][vkey][1]
			if boss and boss.valid then 
				local unit_number =boss.unit_number 
				if unit_number then global.registered_entities_unitnumber[boss.unit_number]=0 end  -- to test if it really died		
				else -- fail mission if disapeared
				local REWARDS = global.msi_informatron_menu[fname..'<REWARD>'][vkey]
				if REWARDS then
					for r=1,#REWARDS do 
						local REWARD = REWARDS[r]
						if REWARD.type == 'unlock_tech' then 
							local tech = REWARD.techs[1]
							mission_failed(mission_id, game.forces[fname],'M_military', {choosen_tech=tech, mission_category='military'})
							break
							end
						end
					end				
				end
			end
		end
	end


-- initialize techs
lock_mission_techs(force)
end

function update_all_forces_settings()
for f=1,#global.player_forces do
	local forcen = global.player_forces[f].force
	local force = game.forces[forcen]
	if force and force.valid then update_force_settings(force) end 
	end
end

script.on_nth_tick(60, function (event)
update_player_tracking_screens()
if #global.wait_for_event>0 then check_events() end
if #global.monitored_entity>0 then Monitored_Entities() end
if game.tick%120==0 then check_companions() end -- game.tick > 1000
end)

-- Each 7 minutes, look for a new available mission
script.on_nth_tick(60 * 60 * 7, function (event)
if game.tick > 150 then check_for_available_missions() end
end)


script.on_event(defines.events.on_research_finished, function(event)
local research = event.research
local force = research.force
local tech_name =research.name
if global.force_control[force.name] then 
	if tech_name == "laboratory" then 
		local lab = global.force_control[force.name].entities.initial_lab
		if lab and lab.valid then lab.destructible=true end


	elseif in_list({"logistic-system","flamethrower"},tech_name) then
		if force.technologies["logistic-system"].researched and force.technologies["flamethrower"].researched then
			create_unique_boss_mission(force,'msi-smoke-boss-spawner') -- smoke boss
			end
		
		
	elseif tech_name == "rocket-silo" then 
		local event = {event='create_new_mission', force=force, mission_category='unique', choosen_tech='rocket-silo', 
			           surface=global.force_control[force.name].home_surface, surface_name=global.force_control[force.name].home_surface.name, tick = 1,}
		table.insert(global.wait_for_event,event)
		
	
		local event = {event='create_new_mission', force=force, mission_category='unique', choosen_tech='msi_tech_lock_satellites', 
			           surface=global.force_control[force.name].home_surface, surface_name=global.force_control[force.name].home_surface.name, tick = game.tick+ 61*71*3}
		table.insert(global.wait_for_event,event)
	
		if not game.active_mods['space-exploration'] then create_unique_boss_mission(force,'msi-worm-boss-fire-shooter') end 
		
		
	elseif tech_name =='msi_tech_lock_satellites' then create_unique_boss_mission(force,'msi-worm-boss-fire-shooter') -- fire worm
	
	elseif tech_name =='msi_rocket_delivery_requests' then create_rocket_delivery_requests(force)

	elseif string.sub(tech_name,1,14)=="msi_companion_" then upgrade_companion_technology(force,tech_name) 
	
	elseif global.force_control[force.name].research_missions[tech_name] then 
			local data = global.force_control[force.name].research_missions[tech_name]
			advance_mission_control(data.mission_name,data)
	
	end
	

if tech_name == "msi_protomolecule_scan" then CreateNewMissionEvent(force,nil,'unique','start_protomolecule_0') end
	
end
end)





script.on_event(defines.events.on_entity_died, function(event)
local entity = event.entity
local name = entity.name
local force = entity.force
local killer_force=event.force

local unit_number =entity.unit_number 
if unit_number and global.registered_entities_unitnumber[unit_number] then global.registered_entities_unitnumber[unit_number]=1 end


if ((string.sub(name,1,19)=="msi_companion_droid") or (string.sub(name,1,23)=="msi_companion_synthetic")) and global.force_control[force.name]  then 
	if (string.sub(name,1,23)=="msi_companion_synthetic") then 
		force.print({'labels.alert_entity_destroyed',{'entity-name.msi_companion_synthetic'},get_gps_tag(entity.position,entity.surface)}, colors.lightred)
		CreateCameraForForce(force,entity.position,entity.surface)
		companion_synthetic_died(entity.surface,entity.position,force)	
		else
		force.print({'labels.alert_entity_destroyed',{'entity-name.msi_companion_droid'},get_gps_tag(entity.position,entity.surface)}, colors.lightred)
		CreateCameraForForce(force,entity.position,entity.surface)
		reset_companion_state(force,'droid')
		end
	end

-- explosao nuclear
if entity.name=="nuclear-reactor" then
	entity.force.print({"",{"labels.reactor_explode"},get_gps_tag(entity.position,entity.surface)})
	entity.surface.create_entity{name = "atomic-explosion", position = entity.position}
	entity.force.play_sound{path='tc_sound_alarm_1'}
	end


--protomolecule infection spread
if entity.type=="unit-spawner" and force.name=='enemy' then
	if killer_force and killer_force.name=='protomolecule' and math.random()<0.5 then 
		local spawner = entity.surface.create_entity{name="msi_protomolecule_spawner", position=entity.position, force='protomolecule', spawn_decorations=true}
		--table.insert(global.monitored_entity,{entity=spawner,event="protomolecule_activity",tab_event={progress=0}})
		--convert
			for _,e in pairs (entity.surface.find_entities_filtered{force='enemy', position=spawner.position, radius=15}) do e.force=spawner.force end
			
		end
	end


if entity.name=="msi_protomolecule_spawner_boss" then
		local position=entity.position
		local surface=entity.surface
		
		if killer_force and global.force_control[killer_force.name] and 
			global.force_control[killer_force.name].companions.synthetic.disabled then
			global.force_control[killer_force.name].companions.synthetic.disabled = false
			CreateCameraForForce(killer_force,entity.position,entity.surface)
			companion_synthetic_died(surface,position,killer_force)			
			end
			
		
		local boss = "msi_protomolecule_infected_boss_electric_".. (5+global.settings.difficulty_level)
		local p = surface.find_non_colliding_position(boss, position, 0, 1)
		local boss_e = surface.create_entity{name = boss, position=p, force=force}
		
		local boss = "msi_protomolecule_infected_boss_machine_gunner_" .. (5+global.settings.difficulty_level)
		local p = surface.find_non_colliding_position(boss, position, 0, 1)
		local boss_e = surface.create_entity{name = boss, position=p, force=force}
		
		for x=1, global.settings.difficulty_level do
			local boss = "msi_protomolecule_infected_boss_pistol_gunner_" .. (5+global.settings.difficulty_level)
			local p = surface.find_non_colliding_position(boss, position, 0, 1)
			local boss_e = surface.create_entity{name = boss, position=p, force=force}		
			end
		end


end)


function On_entity_destroyed(event)
local id = event.registration_number
-- also Contains  unit_number :: uint (optional)
local unit_number = event.unit_number


local reg = global.registered_entities[id]
if reg then
	local mission_name=reg.mission_name
	if mission_name then 
		if mission_name=='MI_002_broken_generator' then fail_mission_control(mission_name,reg) 
			elseif mission_name=='M_science_packs' then fail_mission_control(mission_name,reg) 
			elseif mission_name=='M_military' then 
				local was_killed = false
				if reg.surface and reg.surface.valid then
					if (not unit_number) or (unit_number and global.registered_entities_unitnumber[unit_number]==1) then was_killed = true end
					end
				if was_killed then 
					advance_mission_control(mission_name,reg) 
					else
					fail_mission_control(mission_name,reg)
					end
			elseif mission_name=='M_power' then fail_mission_control(mission_name,reg)
			elseif mission_name=='M_transportation' then fail_mission_control(mission_name,reg)
			elseif mission_name=='M_upgrades' then fail_mission_control(mission_name,reg)
			elseif mission_name=='M_production' then fail_mission_control(mission_name,reg)
			elseif mission_name=='M_ultimate_techs' then fail_mission_control(mission_name,reg)
			elseif mission_name=='M_unique_boss_msi-worm-boss-fire-shooter' then advance_mission_control(mission_name,reg)
			elseif mission_name=='M_unique_boss_msi-smoke-boss-spawner' then advance_mission_control(mission_name,reg)
			elseif (mission_name=='MI_010_machines_shipwreck' or mission_name=='MI_011_military_shipwreck') then fail_mission_control(mission_name,reg)
			elseif (mission_name=='M_unique_kill_protomolecule_spawner' or mission_name=='M_unique_msi_protomolecule_spawner_boss') then advance_mission_control(mission_name,reg)
			
			end
		end
	global.registered_entities[id] = nil
	end
end
script.on_event(defines.events.on_entity_destroyed, On_entity_destroyed) 


function On_Built(event)
local entity = event.created_entity or event.entity 
local surface = entity.surface
local name=entity.name 
local type = entity.type
if type=='entity-ghost' then name=entity.ghost_name end
local force =entity.force 

if global.force_control[force.name] then 
	if name == "rocket-silo" or name == "rsc-silo-stage1" then
		local home_surface = global.force_control[force.name].home_surface  
		local rocket_silo_sites = global.force_control[force.name].rocket_silo_sites     --global.force_control[force.name].rocket_silo_sites = {{surface=surface,position=position}}
		local valid = true
		local one_valid
		
		for R=1, #rocket_silo_sites do
			local surface_name = rocket_silo_sites[R].surface_name
			local rs_surf =  game.surfaces[surface_name]
			if rs_surf and rs_surf.valid and surface==rs_surf then
				local rocket_silo_site = rocket_silo_sites[R].position
				if (distance(rocket_silo_site,entity.position)>16) then valid = false else one_valid=true end
				end
			end
		if one_valid then valid=true end
		if not valid then forbidden_construction_give_back_item(event) end
		end
end

if (type=="electric-turret" or type=="ammo-turret") and global.settings.turrets_prepare_time>0 then  
	entity.active = false
	local activate_turret = {event='activate_turret', entity=entity, tick = game.tick + global.settings.turrets_prepare_time*60}
	table.insert(global.wait_for_event,activate_turret)
	end
	
end		
local filters = {{filter = "type", type = "electric-turret"}, {filter = "type", type = "ammo-turret"}, {filter = "type", type = "entity-ghost"},
	{filter = "name", name = "rsc-silo-stage1"}, {filter = "name", name = "rocket-silo"}}
script.on_event(defines.events.on_built_entity, On_Built, filters) 
script.on_event(defines.events.on_robot_built_entity, On_Built, filters) 
script.on_event(defines.events.script_raised_built, On_Built, filters) 
script.on_event(defines.events.script_raised_revive, On_Built,filters)




function create_gui_tech_free_shop(player,name)
local allow_locked = false
if name=='msi_portable_technology_recovery' then allow_locked=true end
local techs = get_techs_available_for_force(player.force,{'laboratory'},allow_locked)
local gui = player.gui.screen
local qn,ql=0,0
if gui[name] then bt_cancel_receive_free_tech(player,name) end 
local frame = add_gui (gui,{type = "frame", name = name, caption ={"",'[img=item/'..name..']',{'item-name.'..name}}, direction = "vertical"},true)
local c1 = add_gui (frame, {type = "label",  name='c1', caption={'labels.select_one_tech_for_free'}})
local tab1 = add_gui (frame, {type = "table", name='msi_receive_free_tech', column_count = 8})
local c2 = add_gui (frame, {type = "label",  name='c2', caption={'labels.select_one_tech_to_recover'}})
local tab2 = add_gui (frame, {type = "table", name='msi_recover_free_tech', column_count = 8})
for t=1,#techs do
	if player.force.technologies[techs[t]].enabled then 
		local bt= add_gui(tab1, {type = "sprite-button", sprite = "technology/"..techs[t], name=techs[t], tooltip=game.technology_prototypes[techs[t]].localised_name})
		qn=qn+1
		else
		ql=ql+1
		local bt= add_gui(tab2, {type = "sprite-button", sprite = "technology/"..techs[t], name=techs[t], tooltip=game.technology_prototypes[techs[t]].localised_name})
		end
	end
c1.visible=qn>0
c2.visible=ql>0
local bt_none = add_gui(frame, {type = "button", caption ={'labels.none'}, name = "bt_cancel_receive_free_tech", style = "back_button"})
frame.force_auto_center()
end


function bt_cancel_receive_free_tech(player,name)
player.insert{name=name}
player.gui.screen[name].destroy()
end



function receive_free_tech(player,tech,gui_to_destroy)
if player.force.technologies[tech] then
	if player.force.technologies[tech].enabled then 
		player.force.technologies[tech].researched = true
		player.force.play_sound{path='utility/research_completed'}
		player.force.print({'',maf_icons.arrow_right, {'labels.free_technology_received','[technology='..tech.. ']'}},colors.lightgreen)
		else
		player.force.technologies[tech].enabled = true
		player.force.play_sound{path='utility/research_completed'}
		player.force.print({'',maf_icons.arrow_right, {'labels.free_technology_received','[technology='..tech.. ']'}},colors.lightgreen)
		end
	gui_to_destroy.destroy()
	--player.gui.screen.msi_frame_free_technology.destroy()
	end
end


function bomb_destroy_protomolecule(surface,force)
local infected = surface.find_entities_filtered{force='protomolecule'}
local do_once = true
for _,p in pairs (infected) do
	if do_once and p and p.valid and p.type == 'unit-spawner' then 
		CreateCameraForForce(force,p.position,surface)
		surface.create_entity{name = "atomic-explosion", position = p.position}
		force.play_sound{path='tc_sound_alarm_1'}
		do_once=false
		p.die()
		
		elseif p and p.valid then p.destroy()
		end
	end

local icon = ''
if global.se_universe.by_name[surface.name] and global.se_universe.by_name[surface.name].icon then 
	icon = global.se_universe.by_name[surface.name].icon end
force.print({"labels.proto_antidote_launched",icon .. surface.name},colors.lightgreen)
end

-- ROCKET LAUNCH - disabled on v 0.3.2 - changes on SE
function on_cargo_rocket_launched(event)
--local struct = event.struct
--local silo_container = struct.container
--if math.random(0,1)==1 and silo_container and silo_container.valid then CallFrenzyAttack(silo_container.surface,silo_container.position) end
end

script.on_event(defines.events.on_rocket_launched, function(event)
local rocket = event.rocket
local silo = event.rocket_silo
local surface = rocket.surface

--player_index :: uint (optional): The player that is riding the rocket, if any.
local force =rocket.force

if force==game.forces.protomolecule and surface and surface.valid then 
	on_protomolecule_rocket_launched(surface,silo, false)
	return
	end

if math.random(0,2)==1 and silo.valid then CallFrenzyAttack(surface,silo.position) end


if rocket.get_item_count('msi_protomolecule_antidote_bomb')>0 then 
	bomb_destroy_protomolecule(surface,force)
	end


if global.force_control[force.name] then 
	if rocket.get_item_count('satellite')>0 then 
		se_update_known_zones(force) 
		end
	if global.force_control[force.name].rocket_launch_missions then 
		for mission_id, mission_info in pairs (global.force_control[force.name].rocket_launch_missions) do
			if not mission_info.accomplished then 
				check_mission_rocket_launched(force,silo,rocket,mission_id, mission_info)
				end
			end
		end
	end
end)







function Chunk_Generated(event)
if game.active_mods['space-exploration'] then 
	local surface = event.surface
	if global.surface_effects[surface.name] and global.surface_effects[surface.name]=='only_big_spawners' then 
		local area = event.area
		local spawns = surface.find_entities_filtered{area = area, type = "unit-spawner"}
		if #spawns>0 then 
			local s = spawns[math.random(#spawns)]
			local pos = s.position
			local f = s.force
			for e, entity in pairs(spawns) do entity.destroy() end 
			pos=surface.find_non_colliding_position("msi-big-boss-spawner", pos, 0, 1)
			if pos then surface.create_entity{name="msi-big-boss-spawner", position=pos, force=f, spawn_decorations=true} end
			end	
		end
	end
end
script.on_event(defines.events.on_chunk_generated, Chunk_Generated)



-- Capsule
script.on_event(defines.events.on_player_used_capsule, function(event)
local player = game.players[event.player_index]
local item = event.item
--local position = event.position
--local surface = player.surface 
if item.name=='msi_portable_technology_data' or item.name=='msi_portable_technology_recovery' then create_gui_tech_free_shop(player,item.name) end

end)


--protomolecule infection spread
script.on_event(defines.events.on_biter_base_built, function(event)
local entity=event.entity
local surface=entity.surface
local position=entity.position
local force=entity.force
local do_replace=false
local do_replace_turret=false

if force.name=='protomolecule' then 
		if entity.type=="unit-spawner" then do_replace=true 
			elseif entity.type=="turret" then do_replace_turret=true 
			end
		
	elseif force.name=='enemy' then 
		local infected = entity.surface.find_entities_filtered{force='protomolecule', position=entity.position, radius=64, limit=1}
		if #infected>0 then 
			if entity.type=="unit-spawner" then do_replace=true 
			  elseif entity.type=="turret" and math.random(3)==1 then do_replace_turret=true 
				else entity.destroy() end
			end 
	end
if do_replace then 
	if entity and entity.valid then entity.destroy() end
	local spawner = surface.create_entity{name="msi_protomolecule_spawner", position=position, force='protomolecule', spawn_decorations=true}
	--table.insert(global.monitored_entity,{entity=spawner,event="protomolecule_activity",tab_event={progress=0}})
elseif do_replace_turret then 	
	if entity and entity.valid then entity.destroy() end
	local p=surface.find_non_colliding_position("msi_protomolecule_artillery", position, 0, 1)
	local arty = surface.create_entity{name="msi_protomolecule_artillery", position=p, force='protomolecule', spawn_decorations=true}
	arty.insert({name='artillery-shell', count=15}) 
	--local recharge = {action='reload_weapon', chance = 1}
	--table.insert(global.monitored_entity,{entity=arty,event="special_entity_activity",tab_event={special_entity_activity={recharge}}})
	end	
end)


function on_entity_cloned(event)
local clone = event.destination
local source = event.source
local name = source.name
local force=source.force 

if (not string.find(name, "corpse")) and force and global.force_control[force.name] then
	if (string.sub(name,1,19)=="msi_companion_droid") then 
	local droid_data = global.force_control[force.name].companions.droid
	droid_data.entity=clone
	
	elseif 	(string.sub(name,1,23)=="msi_companion_synthetic") then 
	local synthetic_data = global.force_control[force.name].companions.synthetic
	synthetic_data.entity=clone
	end

end

local destroy_this =  {'msi-science-escort-droid'}
if in_list (destroy_this,source.name) then 
	clone.destroy()
	end

if (destination and destination.valid) and (destination.type=="electric-turret" or destination.type=="ammo-turret") then 
	if not destination.active then destination.active=true end end

end
script.on_event(defines.events.on_entity_cloned, on_entity_cloned)



function player_press_CTRL_E(player)
	local function set_command(unit,character)
		local command = {type = defines.command.go_to_location, destination_entity = character,
						pathfind_flags = {cache=true, low_priority=true, allow_destroy_friendly_entities=false},
						distraction = defines.distraction.none}
		unit.set_command(command)	
	end
	
if player and player.valid and player.character and player.character.valid then
local surface = player.surface
local force = player.force
	
	if global.force_control[force.name] then
		local companion_droid = global.force_control[force.name].companions.droid.entity
		local companion_synthetic = global.force_control[force.name].companions.synthetic.entity
		if companion_droid and companion_droid.valid and surface==companion_droid.surface and 
			distance(companion_droid.position,player.position)<50 then companion_droid.autopilot_destination=player.position end
		if companion_synthetic and companion_synthetic.valid and surface==companion_synthetic.surface and 
			distance(companion_synthetic.position,player.position)<50 then set_command(companion_synthetic,player.character) end
		end
	

	local names = {'msi-science-escort-droid'}
	local units = surface.find_entities_filtered{name=names,force=player.force, position=player.position, radius =50}
	for _,unit in pairs (units) do set_command(unit,player.character) end
	global.control_e_tick[player.force.name] = game.tick

end
end
script.on_event("msi-special-key", function(event) player_press_CTRL_E(game.players[event.player_index]) end)












--------------------------------------------------------------------------------------

-- INTERFACE
	
--------------------------------------------------------------------------------------

local interface = {}

function interface.add_player_force(force_name,surface_name)
if force_name and surface_name and game.forces[force_name] and game.surfaces[surface_name] then
	add_list(global.player_forces, {force=force_name,surface=surface_name}) 
	initialize_force_settings({force=force_name,surface=surface_name})
	end
end

function interface.spawn_new_random_mission()
check_for_available_missions(true)
end

function interface.spawn_new_mission(force_name,category)
local mission_categories = get_mission_categories()
local force = game.forces[force_name]
if force and global.force_control[force.name] then 
if category and in_list(mission_categories,category) then
	global.force_control[force.name].spawned_missions[category] = global.force_control[force.name].spawned_missions[category] or {} 
 
	local choosen_tech = get_mission_tech_available(force, global.mission_techs[category], global.force_control[force.name].spawned_missions[category] ) 
	if choosen_tech then 
		CreateNewMissionEvent(force,nil,category,choosen_tech,30) 
		end
	end
	end
end

function interface.reset_all_mod_vars()
reset_all_mod_vars()
end

function interface.protomolecule_rocket_launch(surface_name)
on_protomolecule_rocket_launched(game.surfaces[surface_name])
end


remote.add_interface( "MSI2", interface )


--[[
 Usage for creating adding a new force for msi missions and events:
 force_name    = New player force name, with its spawn location already set
 surface_name  = The starting (initial spawn) surface of that force (eg: a planet name, on multiplayer Space Exploration)

include player force for its own missions
/c remote.call( "MSI2","add_player_force",force_name,surface_name)

spawn a mission by category
/c remote.call( "MSI2","spawn_new_mission","player","science_packs")
/c remote.call( "MSI2","spawn_new_mission","player","military")
]]



