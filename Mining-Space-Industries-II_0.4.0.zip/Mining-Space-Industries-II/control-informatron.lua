-- Informatron content for MSI2
--local format_time   = util.formattime
local modname = "Mining-Space-Industries-II"

remote.add_interface("Mining-Space-Industries-II", {
  informatron_menu = function(data)
    return MSI_menu(data.player_index)
  end,
  informatron_page_content = function(data)
    return MSI_page_content(data.page_name, data.player_index, data.element)
  end
})


function MSI_menu(player_index)
local force_name = game.players[player_index].force.name
local pl_name =  game.players[player_index].name
local player_menu = table.deepcopy(global.msi_informatron_menu[force_name])

if global.player_settings[pl_name] then
	if global.player_settings[pl_name].hide_menu_mission_acc then 
		player_menu.missions.accomplished_missions=nil
		end
	if global.player_settings[pl_name].hide_menu_mission_fail then 
		player_menu.missions.failed_missions=nil
		end
end

return player_menu
end


function MSI_page_content(page_name, player_index, element)
local force_name = game.players[player_index].force.name
local pl_name =  game.players[player_index].name
local refresh = false
 -- main page

  if page_name == modname then
    element.add{type="button", name="image_1", style="img_msi_welcome"} -- defined in data.lua. MUST be a completely unique style name
    local txt = element.add{type="label",  name="text_1", caption={modname..".".."page_" .. page_name .. "_text_1"}}
	txt.style.font = "default-large-semibold"
 
  elseif string.find(page_name, "mission_name_")  then
	local mission_name,status,mc
	
	if string.find(page_name, "F_mission_name_") then 
		mission_name = string.sub(page_name,16)
		status = 'FAILED'
		mc="F_mission_name_"
		elseif string.find(page_name, "A_mission_name_") then 
		mission_name = string.sub(page_name,16)
		status = 'ACCOMPLISHED'
		mc="A_mission_name_"
		else
		mission_name = string.sub(page_name,14)
		status = 'ACTIVE'
		mc="mission_name_"
		end
	
	local MISSION_GROUP = global.msi_informatron_menu[force_name .. '<MISSION_GROUP>'][mission_name]
	local mkey = 'page_mission_name_'..mission_name
	element.add{type="label", name="text_1", caption={modname.."."..mkey}}.style.font = "scenario-message-dialog"
	

	for mission_id, mstatus in pairs (global.msi_informatron_menu[force_name .. '<MISSION_GROUP>'][mission_name]) do
		if mstatus==status then
			local vkey = mission_name .. mission_id
			local mcapt = {"",{modname..".menu_"..mc.. mission_name},' #'..mission_id..'  ',{'labels.'..status} }
			local mframe = element.add{type = "frame", caption = mcapt, direction = "vertical"}

			local PICTURES= global.msi_informatron_menu[force_name .. '<PICTURES>'][vkey]
			local ENTITIES= global.msi_informatron_menu[force_name .. '<ENTITIES>'][vkey]
			local CAMERAS = global.msi_informatron_menu[force_name .. '<CAMERAS>'][vkey]
			local REWARDS  = global.msi_informatron_menu[force_name .. '<REWARD>'][vkey]
			local START_TICK = global.msi_informatron_menu[force_name .. '<START_TICK>'][vkey]
			local ACC_TICK   = global.msi_informatron_menu[force_name .. '<ACCOMPLISHED_TICK>'][vkey]
			local FAIL_TICK  = global.msi_informatron_menu[force_name .. '<FAIL_TICK>'][vkey]
			local EXTRA_TEXT
			if global.msi_informatron_menu[force_name .. '<EXTRA_TEXT>'] and global.msi_informatron_menu[force_name .. '<EXTRA_TEXT>'][vkey] then
				EXTRA_TEXT = global.msi_informatron_menu[force_name .. '<EXTRA_TEXT>'][vkey] end 
			local REQUIRED_ITEMS
			if global.msi_informatron_menu[force_name .. '<REQUIRED_ITEMS>'] and global.msi_informatron_menu[force_name .. '<REQUIRED_ITEMS>'][vkey] then
				REQUIRED_ITEMS = global.msi_informatron_menu[force_name .. '<REQUIRED_ITEMS>'][vkey] end 			
			


			if PICTURES then
				local tabpic = mframe.add {type = "table",  name='tab_pic'..mission_id, column_count = #PICTURES}
				for p=1,#PICTURES do tabpic.add{type="button", name="image_"..p, style=PICTURES[p]} end
				end

			if ENTITIES then 
				for e=#ENTITIES,1,-1 do if not (ENTITIES[e] and ENTITIES[e].valid) then table.remove(ENTITIES,e) end end
				if #ENTITIES>0 then 
					local tab = mframe.add {type = "table",  name='tab_ent'..mission_id, column_count = #ENTITIES}
					for e=1,#ENTITIES do 
						local entity = ENTITIES[e] 
						local ep = tab.add{type = "entity-preview", name='entity_'..e}
						ep.style.width = 200
						ep.style.height = 200
						ep.entity=entity
						end
					end
				end

			mframe.add{type="label", caption={'labels.mission_start_tick', format_time_hour(START_TICK)}}.style.minimal_width=200  --format_time(START_TICK)
			if ACC_TICK  then mframe.add{type="label", caption={'labels.mission_acc_tick', format_time_hour(ACC_TICK)}} end
			if FAIL_TICK then mframe.add{type="label", caption={'labels.mission_fail_tick', format_time_hour(FAIL_TICK)}} end

			if CAMERAS and status == 'ACTIVE' then
				local tab = mframe.add {type = "table",  name=vkey, column_count = 1+#CAMERAS*2}
				tab.add{type="label", caption={"",'[img=img_camera]',{'labels.point_of_interest'}}}
				for c=1,#CAMERAS do 
					local camera = CAMERAS[c] -- local camera = {entity=entity,surface=surface,position=position,icon='[img=entity/crash-site-lab-repaired]', text=cam_text}
					if camera.surface then tab.add{type="label", caption=get_se_zone_icon(camera.surface_name)..camera.surface_name..':'} else tab.add{type="label",caption=''} end
					tab.add{type = "button", caption =camera.icon, name = "bt_mission_cam_"..c , style = "quick_bar_page_button", tooltip=camera.text}
					end
				end

			if mission_name=='M_space_rockets' then
				local rocket_launch_request = global.force_control[force_name].rocket_launch_missions[mission_id].rocket_launch_request
				local surface_name = rocket_launch_request.surface_name
				local from = {'labels.anywhere'}
				if surface_name then 
					local surface = game.surfaces[rocket_launch_request.surface_name]
					if surface and surface.valid then from = get_se_zone_icon(surface.name) .. surface.name end
					end
				local position = rocket_launch_request.position
				if position then from={"",from, ' [x='..position.x .. ' , y='..position.y ..']'} end 
				local items_required = rocket_launch_request.items_required
				local force_launched=''
				if rocket_launch_request.count_force_launched then 
					force_launched={'labels.launched',game.forces[force_name].get_item_launched(items_required.name)}
					end
				mframe.add{type="label", caption={'labels.launch_rocket_at_with',from, 
					{"",items_required.count,'[img=item/'..items_required.name..']',get_localized_name(items_required.name)},
					force_launched	}}
				end

			if mission_name=='M_unique_satellites' then
				local rocket_launch_request = global.force_control[force_name].rocket_launch_missions[mission_id].rocket_launch_request
				local items_required = rocket_launch_request.items_required
				
				mframe.add{type="label", caption={'labels.launch_rocket_with', items_required.count,
								{"",'[img=item/'..items_required.name..']',get_localized_name(items_required.name)},
								game.forces[force_name].get_item_launched(items_required.name)
								}}
				end


			if REWARDS then
				mframe.add{type="label", caption={'labels.if_accomplished'}}.style.minimal_width=200
				for r=1,#REWARDS do
					local REWARD = REWARDS[r]
					if REWARD.type == 'team_XP' and game.active_mods['RPGsystem'] then 
						if REWARD.XP then mframe.add{type="label", caption={"labels.team_XP",format_number(REWARD.XP)}}
							elseif REWARD.XPPerc then mframe.add{type="label", caption={"labels.perc_XP",format_number(REWARD.XPPerc)}} end
					elseif REWARD.type == 'unlock_tech' then 
						local techs = REWARD.techs
						for t=1,#techs do
							local tech= techs[t]
							if game.technology_prototypes[tech] then 
								local text = game.technology_prototypes[tech].localised_name 
								mframe.add{type="label", caption={"labels.unlocks_technology", {"","[img=technology/"..tech.."]",text}}}
								-- check if it has already been unlocked (tech data item)
								if game.forces[force_name].technologies[tech].enabled and status == 'ACTIVE' then 
									mission_accomplished(mission_id,game.forces[force_name],mission_name,{choosen_tech=tech, mission_category=find_mission_category(tech)})
									end
								end
							end

					elseif REWARD.type == 'unlock_recipe' then 
						local recipes = REWARD.recipes
						for r=1,#recipes do
							local recipe = recipes[r]
							 if game.recipe_prototypes[recipe] then 
								local text = game.recipe_prototypes[recipe].localised_name
								mframe.add{type="label", caption={"labels.unlocks_recipe", {"","[img=recipe/"..recipe.."]",text}}}
								end
							end
							
					elseif REWARD.type == 'print_text' then 
						local texts = REWARD.texts
						for t=1,#texts do
							mframe.add{type="label", caption=texts[t]}
							end
							
						end
						
						
					end
				end
				
				
				if EXTRA_TEXT then
					for t=1,#EXTRA_TEXT do
						mframe.add{type="label", caption=EXTRA_TEXT[t]}
						end
					end
				
				if REQUIRED_ITEMS then 
					mframe.add{type = "button", caption ={'labels.track-items'}, name = "bt_mission_items_"..vkey, style = "rounded_button", tooltip={'labels.track-items-tooltip'}}
					end
					
			end--status==
		end --M

  else
	element.add{type="label", name="text_1", caption={modname..".".."page_" .. page_name .. "_text_1"}}.style.font = "scenario-message-dialog"
	
	if page_name=='companion_units' then informatron_companions_gui(player_index, element) 

	elseif page_name=='missions' then
		--local tab_mopt = element.add {type = "table",  name='tab_mopt', column_count = 2}
		if not global.player_settings[pl_name] then 
			global.player_settings[pl_name]={} 
			global.player_settings[pl_name].hide_menu_mission_acc=false
			global.player_settings[pl_name].hide_menu_mission_fail=false
			end
		element.add{type="label",  caption={'labels.menu_options'}}
		element.add{name='hide_menu_mission_acc', type="checkbox", caption={'labels.hide_acc_mission_tab'}, state=global.player_settings[pl_name].hide_menu_mission_acc} 
		element.add{name='hide_menu_mission_fail', type="checkbox", caption={'labels.hide_failed_mission_tab'}, state=global.player_settings[pl_name].hide_menu_mission_fail}
	

	elseif page_name=='message_board' then
		local mbframe = element.add{type = "frame", caption = {'labels.message_updated_on',format_time_hour(global.force_control[force_name].message_board.tick)} , direction = "vertical"}
		local scroll = mbframe.add{type = "scroll-pane", name= "message_board_scroll", vertical_scroll_policy="auto", horizontal_scroll_policy="never"}
	
		local tab_text = scroll.add {type = "table",  name='tab_text', column_count = 2}
		local text = tab_text.add{type="text-box", name="message_board_textbox",text=global.force_control[force_name].message_board.text}
		text.style.width=800
		text.style.height=400 --300
		text.style.horizontally_stretchable=false
		text.word_wrap=true 
		
		local tab2 = tab_text.add {type = "table", name='tab2', column_count = 1}
		tab2.add{type="label",caption={'labels.add_icon'}}
		tab2.add{name='message_board_icon_picker',type="choose-elem-button",elem_type ='item', item=nil}
		
		mbframe.add{type="label", name="last_user", caption={'labels.last_user',global.force_control[force_name].message_board.last_user}}

		local btsave = mbframe.add{name="bt_save_message_board",  type="button", style = "confirm_button", caption={'labels.save'}}
		end 
	
  end

--if refresh then refresh_informatron_page(game.players[player_index], page_name) end
end


function print_force_goal(force,text)
for p, player in pairs(game.connected_players) do
	if player.valid then player.set_goal_description (text,false) end
	end
end

function Get_Next_Mission_ID()
global.current_mission_ID = global.current_mission_ID +1
return global.current_mission_ID
end


function is_mission_accomplished(force,mission_name)
local mkey = 'A_mission_name_'..mission_name 
if global.msi_informatron_menu[force.name].missions.accomplished_missions[mkey] then
	return true 
	end
end


function add_mission_log(mission_id,force,mission_name,rewards, pictures, cameras, entities, data,print_goal,extra_text,REQUIRED_ITEMS)
if not mission_id then mission_id = Get_Next_Mission_ID() end
local mkey = 'mission_name_'..mission_name 
local vkey = mission_name .. mission_id

global.msi_informatron_menu[force.name].missions.current_missions[mkey] = 1
global.msi_informatron_menu[force.name .. '<MISSION_GROUP>'][mission_name] = global.msi_informatron_menu[force.name .. '<MISSION_GROUP>'][mission_name]  or {}
global.msi_informatron_menu[force.name .. '<MISSION_GROUP>'][mission_name][mission_id]='ACTIVE'

global.msi_informatron_menu[force.name .. '<START_TICK>'][vkey] = game.tick
if pictures then global.msi_informatron_menu[force.name .. '<PICTURES>'][vkey] = pictures end
if entities then global.msi_informatron_menu[force.name .. '<ENTITIES>'][vkey] = entities end
if cameras  then global.msi_informatron_menu[force.name .. '<CAMERAS>'][vkey] = cameras end
if rewards  then global.msi_informatron_menu[force.name .. '<REWARD>'][vkey] = rewards end
if extra_text then global.msi_informatron_menu[force.name .. '<EXTRA_TEXT>'][vkey] = extra_text end
if REQUIRED_ITEMS then global.msi_informatron_menu[force.name .. '<REQUIRED_ITEMS>'][vkey] = REQUIRED_ITEMS end 


if data then 
	data.mission_id=mission_id
	if data.choosen_tech and data.mission_category then 
		add_list(global.force_control[force.name].spawned_missions[data.mission_category],data.choosen_tech) --avoid duplicates
		end
	end
	
if print_goal then  
	force.print({modname..".".."page_mission_name_" .. mission_name}, colors.yellow)
	force.print('')
	end
force.print({'labels.new_mission_entry',{modname..".".."menu_mission_name_" .. mission_name}}, colors.yellow)
force.play_sound{path="utility/new_objective"}
return mission_id
end


function CheckHideActiveMission(force,mission_name)
local found=false
local mkey = 'mission_name_'..mission_name 
for mission_id, status in pairs (global.msi_informatron_menu[force.name .. '<MISSION_GROUP>'][mission_name]) do
	
	if status == 'ACTIVE' then 
		found = true
		break
		end
	end
if not found then
	global.msi_informatron_menu[force.name].missions.current_missions[mkey] = nil
	end
end  


function mission_accomplished(mission_id,force,mission_name,data,skip_acc_log)

global.msi_informatron_menu[force.name .. '<MISSION_GROUP>'][mission_name][mission_id]='ACCOMPLISHED'
local mkey = 'A_mission_name_'..mission_name 
local vkey = mission_name .. mission_id

CheckHideActiveMission(force,mission_name)

if not skip_acc_log then
	global.msi_informatron_menu[force.name].missions.accomplished_missions[mkey] = 1
	global.msi_informatron_menu[force.name .. '<ACCOMPLISHED_TICK>'][vkey] = game.tick
	end

local gps_tag=''
if data and data.surface and data.position then gps_tag = get_gps_tag(data.position,data.surface) end
 force.print({'labels.mission_accomplished',{modname..".".."menu_mission_name_" .. mission_name},gps_tag}, colors.lightgreen)
force.play_sound{path="utility/game_won"}

local REWARDS  = global.msi_informatron_menu[force.name .. '<REWARD>'][vkey]
	if REWARDS then
		for r=1,#REWARDS do
			local REWARD = REWARDS[r]
			if REWARD.type == 'team_XP' and game.active_mods['RPGsystem'] then 
					if REWARD.XP then remote.call("RPG","TeamXP",force.name,REWARD.XP)
						elseif REWARD.XPPerc then remote.call("RPG","TeamXPPerc",force.name,REWARD.XPPerc) end
				elseif REWARD.type == 'unlock_tech' then 
					local techs = REWARD.techs
					local auto_research = REWARD.auto_research
					for t=1,#techs do 
						local tech= techs[t]
						force.technologies[tech].enabled=true
						if auto_research then force.technologies[tech].researched=true end
						local text = game.technology_prototypes[tech].localised_name 
						force.print({'labels.unlocks_technology', {"","[img=technology/"..tech.."]",text}}, colors.lightgreen)
						table.insert (global.force_control[force.name].unlocked_techs, tech)
						end
				elseif REWARD.type == 'unlock_recipe' then 
					local recipes = REWARD.recipes
					for r=1,#recipes do
						local recipe = recipes[r]
						force.recipes[recipe].enabled=true
						local text = game.recipe_prototypes[recipe].localised_name
						force.print({"labels.unlocks_recipe",{"","[img=recipe/"..recipe.."]",text}}, colors.lightgreen)
						end
				end
			end
		end
		
if data then
    if data.map_tag and data.map_tag.valid then data.map_tag.destroy() end
	if data.choosen_tech and data.mission_category then 
		del_list(global.force_control[force.name].spawned_missions[data.mission_category],data.choosen_tech)
		end
	end
end


function mission_failed(mission_id,force,mission_name,data)

global.msi_informatron_menu[force.name .. '<MISSION_GROUP>'][mission_name][mission_id]='FAILED'
local mkey = 'F_mission_name_'..mission_name 
local vkey = mission_name .. mission_id
CheckHideActiveMission(force,mission_name)

global.msi_informatron_menu[force.name].missions.failed_missions[mkey] = 1
global.msi_informatron_menu[force.name .. '<FAIL_TICK>'][vkey] = game.tick

force.print({'labels.mission_failed',{modname..".".."menu_mission_name_" .. mission_name}}, colors.lightred)
force.play_sound{path="utility/scenario_message"}

if data then
	 if data.map_tag and data.map_tag.valid then data.map_tag.destroy() end
	 if data.surface and data.position then 
		force.print({"",{'labels.point_of_interest'},get_gps_tag(data.position,data.surface)})
		end
	 if data.choosen_tech and data.mission_category then 
		del_list(global.force_control[force.name].spawned_missions[data.mission_category],data.choosen_tech)
		end
	end
	
end



function save_message_board(gui,player)
local force=player.force
local parent = gui.parent
local tb=parent.message_board_scroll.tab_text.message_board_textbox
if global.force_control[force.name].message_board.text ~= tb.text then 
	global.force_control[force.name].message_board= {text=tb.text,last_user=player.name, tick=game.tick}
	force.print({"labels.message_board_updated",player.name},colors.yellow)
	end
closes_informatron(player)
end

function add_icon_message_board(gui)
local parent = gui.parent.parent
local tb=parent.message_board_textbox
tb.text = tb.text .. '[img=item/'..gui.elem_value..']'
end


function informatron_hide_tab(player,menu,state)
global.player_settings[player.name][menu] = state
refresh_informatron_page(player, 'missions')
end


function closes_informatron(player)
local window= player.gui.screen.informatron_main
if window then window.destroy() end
end

function refresh_informatron_page(player, page)
closes_informatron(player)
remote.call('informatron', 'informatron_open_to_page',{player_index=player.index,interface=modname,page_name=page})
end
