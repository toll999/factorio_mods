


function advance_mission_control(mission_name,data)
--
if mission_name == 'MI_001_broken_lab' then 
		local entity = data.entity
		local force = entity.force
		local initial_lab = entity.surface.create_entity({name='crash-site-lab-repaired', position=entity.position, force = force})
		initial_lab.destructible = false
		initial_lab.minable = false
		global.force_control[force.name].entities.initial_lab = initial_lab
		secure_destroy_spill_items(entity,defines.inventory.chest)
		mission_accomplished(data.mission_id,force,mission_name)
	
	elseif mission_name == 'MI_002_broken_generator' then 
		local entity = data.entity
		local force = entity.force
		entity.surface.create_entity({name='crashed-generator', position=entity.position, force = force})
		secure_destroy_spill_items(entity,defines.inventory.chest)
		global.registered_entities[data.re_id] = nil
		mission_accomplished(data.mission_id,force,mission_name)


	
	elseif (mission_name=='MI_010_machines_shipwreck' or mission_name=='MI_011_military_shipwreck') then 
		local entity = data.entity
		local force = entity.force
		local surface=entity.surface 
		global.registered_entities[data.re_id] = nil
		CallFrenzyAttack(surface,entity.position)
		if mission_name=='MI_010_machines_shipwreck' then
			local furnace = "steel-furnace"
			if game.active_mods['IndustrialRevolution'] then furnace = "bronze-furnace" end
			surface.spill_item_stack(entity.position,{name="solar-panel", count=math.random(15,30)}, false)
			surface.spill_item_stack(entity.position,{name="assembling-machine-2", count=math.random(20,40)}, false)
			surface.spill_item_stack(entity.position,{name="electric-mining-drill", count=math.random(25,50)}, false)
			surface.spill_item_stack(entity.position,{name=furnace, count=math.random(20,30)}, false)
			surface.spill_item_stack(entity.position,{name="electric-furnace", count=math.random(2,5)}, false)
			surface.spill_item_stack(entity.position,{name="accumulator", count=math.random(15,30)}, false)
			surface.spill_item_stack(entity.position,{name="steam-engine", count=math.random(5,15)}, false)
			surface.spill_item_stack(entity.position,{name="boiler", count=math.random(5,10)}, false)
			surface.spill_item_stack(entity.position,{name="msi_portable_technology_data", count=1}, false)
			else
			surface.spill_item_stack(entity.position,{name="defender-capsule", count=math.random(30,60)}, false)
			surface.spill_item_stack(entity.position,{name="poison-capsule", count=math.random(10,20)}, false)
			surface.spill_item_stack(entity.position,{name="slowdown-capsule", count=math.random(10,20)}, false)
			surface.spill_item_stack(entity.position,{name="grenade", count=math.random(30,60)}, false)
			surface.spill_item_stack(entity.position,{name="gun-turret", count=math.random(20,30)}, false)
			surface.spill_item_stack(entity.position,{name="laser-turret", count=math.random(1,2)}, false)
			surface.spill_item_stack(entity.position,{name="military-science-pack", count=math.random(100,200)}, false)
			surface.spill_item_stack(entity.position,{name="piercing-rounds-magazine", count=math.random(300,500)}, false)
			surface.spill_item_stack(entity.position,{name="land-mine", count=math.random(30,50)}, false)
			end
		mission_accomplished(data.mission_id,force,mission_name)
		remove_also_speak_from_entity(entity)

	elseif mission_name == 'MI_003_companion_droid' then 
		local entity = data.entity
		local force = entity.force
		local level = global.force_control[force.name].companions.droid.level
		if (not level) and data.mission_id then mission_accomplished(data.mission_id,force,mission_name) end
		spawn_msi_companion('droid',force,entity.surface,entity.position)
		Entity_Speak(entity,'[img=entity/msi_companion_droid_1]')

	elseif mission_name == 'MI_003_companion_synthetic' then 
		local entity = data.entity
		local force = entity.force
		local level = global.force_control[force.name].companions.synthetic.level
		if (not level) and data.mission_id then mission_accomplished(data.mission_id,force,mission_name) end
		spawn_msi_companion('synthetic',force,entity.surface,entity.position)
		Entity_Speak(entity,'[img=entity/msi_companion_synthetic_melee_1]')


	elseif mission_name == 'MI_004_repair_synthetic' then 
		local entity = data.entity
		local force = entity.force
		spawn_msi_companion('synthetic',force,entity.surface,entity.position)
		mission_accomplished(data.mission_id,force,mission_name,data,true)
		entity.destroy()


	elseif mission_name == 'M_science_packs' then
		if not data.state then data.state=1 end
		local entity = data.entity
		local force = entity.force	
		local surface = entity.surface		
		if data.state==1 then 
			
			local name = 'msi-science-escort-droid'			
			local pos = surface.find_non_colliding_position(name, entity.position, 0, 1)
			local droid = surface.create_entity{name=name, position=pos, force=entity.force}
			global.registered_entities[data.re_id] = nil
			secure_destroy_spill_items(entity,defines.inventory.chest)
			local cam_text = get_localized_name(droid.name)
			CreateCameraForForce(force,droid,surface,cam_text,nil,nil,0.3)
			local reward = data.reward
			Entity_Speak(droid,'[img=technology/' .. reward[1].techs[1]..']')
			local camera = {entity=droid,surface=surface,surface_name=surface.name,icon='[img=entity/'..name..']', text=cam_text}
			local mission_id = add_mission_log(data.mission_id,force,mission_name,reward,nil, {camera},{entity},data) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
			data.entity=droid
			data.force=droid.force
			register_entity_destruction(droid,data)
			table.insert(global.monitored_entity,{entity=droid,event=mission_name,tab_event=data})
			if game.active_mods['mferrari-mod-sounds'] then data.force.play_sound{path='mferrari_tense_music_1m',override_sound_type='ambient'} end
		
			elseif data.state==2 then 
			surface.create_entity{name='msi_raising_achievement_golem', position=data.entity.position, target={x=data.entity.position.x,y=data.entity.position.y-40} ,speed=0.2}
			data.surface = data.entity.surface  data.position = data.entity.position 
			global.registered_entities[data.re_id] = nil
			data.entity.destroy()
			mission_accomplished(data.mission_id,force,mission_name,data)
			end

	elseif mission_name == 'M_military' or mission_name=='M_unique_boss_msi-worm-boss-fire-shooter' then mission_accomplished(data.mission_id,data.force,mission_name,data)

	elseif mission_name == 'M_unique_boss_msi-smoke-boss-spawner' then 
		data.force.worker_robots_speed_modifier = data.force.worker_robots_speed_modifier + 1
		if data.surface and data.surface.valid then data.surface.always_day = false end
		mission_accomplished(data.mission_id,data.force,mission_name,data)

	
	elseif mission_name == 'M_power' then 
		global.registered_entities[data.re_id] = nil
		local entity = data.entity
		Entity_Speak(entity,';)')
		local surface = entity.surface	
		surface.create_entity{name='msi_raising_achievement_golem', position=entity.position, target={x=entity.position.x,y=entity.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)

	elseif mission_name == 'M_transportation' then 
		global.registered_entities[data.re_id] = nil
		local entity = data.entity
		Entity_Speak(entity,';)',60)
		local surface = entity.surface	
		surface.create_entity{name='msi_raising_achievement_golem', position=entity.position, target={x=entity.position.x,y=entity.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		
		-- make it explodes after a timer
		data.timer_tick = game.tick + 60*60 + math.random(60*20)
		data.speak_time_left=true data.finish_effect='explode' data.explosion_name='small-atomic-explosion'
		data.left_icon=maf_icons.nuke	
		table.insert(global.monitored_entity,{entity=entity,event="timer_event",tab_event=data})
		if game.active_mods['mferrari-mod-sounds'] then data.force.play_sound{path='mferrari_tense_music_1m',override_sound_type='ambient'} end

	elseif mission_name == 'M_upgrades' then 
		global.registered_entities[data.re_id] = nil
		local entity = data.entity
		Entity_Speak(entity,';)')
		local surface = entity.surface	
		surface.create_entity{name='msi_raising_achievement_golem', position=entity.position, target={x=entity.position.x,y=entity.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)

	elseif mission_name == 'M_ultimate_techs' then 
		global.registered_entities[data.re_id] = nil
		local entity = data.entity
		Entity_Speak(entity,';)')
		local surface = entity.surface	
		surface.create_entity{name='msi_raising_achievement_golem', position=entity.position, target={x=entity.position.x,y=entity.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)



	elseif mission_name == 'M_production' then 
		local entity = data.entity
		local force = entity.force	
		local surface = entity.surface		
		if data.state==1 then -- fixed, then create assemb machine
			global.registered_entities[data.re_id] = nil
			local position = entity.position
			secure_destroy_spill_items(entity,defines.inventory.chest)
			local level = get_progress_10(force)
			local repaired_machine = surface.create_entity{name='msi_repaired_machine-'..level, position=position, force=force}
			Entity_Speak(repaired_machine,'[img=technology/' .. data.choosen_tech..']')
			repaired_machine.minable=false
			data.entity=repaired_machine
			table.insert(global.monitored_entity,{entity=repaired_machine,event=mission_name,tab_event=data})
			register_entity_destruction(repaired_machine,data)
			local camera = {entity=repaired_machine,surface=surface,surface_name=surface.name,icon='[img=entity/'..repaired_machine.name..']', text=cam_text}
			add_mission_log(data.mission_id,force,mission_name,data.reward,nil, {camera},{repaired_machine},data) 
			if game.active_mods['mferrari-mod-sounds'] then data.force.play_sound{path='mferrari_tense_music_2m',override_sound_type='ambient'} end


			elseif data.state==2 then -- crafted 1
			global.registered_entities[data.re_id] = nil
			local machine = surface.create_entity({name='msi_broken_machine', position=entity.position, force = entity.force})
			if math.random (2) ==1 then 
				if math.random (3)==1 then machine.insert{name='msi_portable_technology_recovery'}  
					else machine.insert{name='msi_portable_technology_data'} end 
				end
			machine.minable=false
			data.entity = machine
			Entity_Speak(machine,';)')
			entity.destroy()
			surface.create_entity{name='msi_raising_achievement_golem', position=machine.position, target={x=machine.position.x,y=machine.position.y-40} ,speed=0.2}
			mission_accomplished(data.mission_id,data.force,mission_name,data)
			end

	elseif mission_name == 'M_unique_oil' then 
		local entity = data.entity
		local surface = entity.surface	
		Entity_Speak(entity,';)', 30)
		surface.create_entity{name='msi_raising_achievement_golem', position=entity.position, target={x=entity.position.x,y=entity.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		global.force_control[data.force.name].companions.synthetic.missions[mission_name]=nil
	
	elseif mission_name == 'M_space_rockets' then 
		local silo = data.silo
		local surface = silo.surface	
		surface.create_entity{name='msi_raising_achievement_golem', position=silo.position, target={x=silo.position.x,y=silo.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		
		if data.choosen_tech=='msi_protomolecule_scan' then 
			register_research_mission(data.force, data.choosen_tech)
			end
		
		-- check if all delivery recipes are unlocked
		check_msi_cargo_delivery_accomplished(data.force)

	elseif mission_name == 'M_unique_satellites' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
	
	elseif mission_name == 'M_research_msi_protomolecule_scan' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		--CreateNewMissionEvent(data.force,nil,'unique','start_protomolecule_0') -- gone to research_finished
	
	elseif mission_name == 'M_unique_msi_dorment_protomolecule' then
		local entity = data.entity
		local position= entity.position
		local surface = entity.surface	
		surface.create_entity{name='msi_raising_achievement_golem', position=entity.position, target={x=entity.position.x,y=entity.position.y-40} ,speed=0.2}
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		global.force_control[data.force.name].companions.synthetic.missions[mission_name]=nil

		--CAPTURE SYNTHETIC - become a reactor to charge... once charged, 
		global.force_control[data.force.name].companions.synthetic.disabled = true
		local synthetic = global.force_control[data.force.name].companions.synthetic.entity
		if synthetic and synthetic.valid then synthetic.destroy() end
		local protomolecule_waking = surface.create_entity{name='msi_protomolecule_waking', position=entity.position, force=entity.force,spawn_decorations=true }
		protomolecule_waking.destructible=false protomolecule_waking.minable=false
		entity.destroy()

		--EFFECTS UNTIL WAKE PROTOMOLECULE
		--local act1 = {action='projectile_distant_shoot_at_base',projectile='cb-cluster-cold-projectile-big',chance = 0.3}
		local act1 = {action='projectile_shoot_near_player',projectile='cb-cluster-cold-projectile-big',distance=100, chance = 0.15}
		local act2 = {action='spawn_effect',effect='explode', explosion_name='big-artillery-cold-explosion',chance = 0.4}
		local act3 = {action='shock_hazard',radius = 30, quant = 5, chance = 0.4}
		local act4 = {action='projectile_shoot_random_places_near',distance = 40, chance = 0.4, projectile='cb-cluster-cold-projectile-big'}
		local activities = {act1,act2,act3,act4}
		data.entity = protomolecule_waking
		data.progress = 0
		data.special_entity_activity=activities
		table.insert(global.monitored_entity,{entity=protomolecule_waking,event="special_entity_activity",tab_event=data})
		table.insert(global.monitored_entity,{entity=protomolecule_waking,event="protomolecule_waking",tab_event=data})


	elseif mission_name == 'M_research_msi_protomolecule_awaken' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		data.entity.destructible = true
		data.mission_name = 'M_unique_kill_protomolecule_spawner'
		data.mission_category = 'unique'
		register_kill_mission_force(data.force, data.entity, data.mission_name, data)

	elseif mission_name == 'M_unique_kill_protomolecule_spawner' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		CreateNewMissionEvent(data.force,nil,'unique','start_protomolecule_main_boss')
		--generate big boss, and then erradicate protomolecule
			--novo menu para escanear planetas ??
		
	elseif mission_name == 'M_unique_msi_protomolecule_spawner_boss' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		-- last mission - erradicate protomolecule 
		
		data.force.technologies['msi_protomolecule_antidote_bomb'].enabled=true
		register_research_mission(data.force, 'msi_protomolecule_antidote_bomb')


	elseif mission_name == 'M_research_msi_protomolecule_antidote_bomb' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		local event={}
		event.force=data.force
		event.mission_name = "M_unique_launch_protomolecule_antidote_bomb"
		local reward = {{type = 'team_XP', XP = Get_XP_ratio(1000)}}
		event.reward=reward
		local rocket_launch_request = {items_required={name='msi_protomolecule_antidote_bomb',count=1}, count_force_launched=true}
		create_rocket_request_mission(event, rocket_launch_request)
			
			
	elseif mission_name == 'M_unique_launch_protomolecule_antidote_bomb' then 
		mission_accomplished(data.mission_id,data.force,mission_name,data)
		if not game.active_mods['space-exploration'] then
			game.set_game_state{game_finished = true, player_won = true, can_continue = true}
			end
	
	end

end

function fail_mission_control(mission_name,data)

if mission_name == 'MI_002_broken_generator' then mission_failed(data.mission_id, data.force,mission_name,data)	
	elseif mission_name == 'M_science_packs' then mission_failed(data.mission_id, data.force,mission_name,data)
	elseif mission_name == 'M_military' then mission_failed(data.mission_id, data.force,mission_name,data)
	elseif mission_name == 'M_power' then mission_failed(data.mission_id, data.force,mission_name,data)		
	elseif mission_name == 'M_production' then mission_failed(data.mission_id, data.force,mission_name,data)
	elseif mission_name == 'M_transportation' then mission_failed(data.mission_id, data.force,mission_name,data)		
	elseif mission_name == 'M_upgrades' then mission_failed(data.mission_id, data.force,mission_name,data)		
	elseif mission_name == 'M_ultimate_techs' then mission_failed(data.mission_id, data.force,mission_name,data)		
	elseif (mission_name=='MI_010_machines_shipwreck' or mission_name=='MI_011_military_shipwreck') then  mission_failed(data.mission_id, data.force,mission_name,data)
	
	end

end


function check_msi_cargo_delivery_accomplished(force)
local done=true
for x=1,5 do
	if not force.recipes[global.msi_double_recipes[x]].enabled then 
		done=false
		break
		end
	end
if done then 
	force.technologies['msi_tech_lock_cargo_delivery'].enabled = true
	force.technologies['msi_tech_lock_cargo_delivery'].researched = true
	end
end


function remove_also_speak_from_entity(entity)
for m=1,#global.monitored_entity do
	if global.monitored_entity[m].entity==entity then global.monitored_entity[m].tab_event.also_speak=nil end
	end
end


function event_protomolecule_awaken(data)
local entity = data.entity
local position= entity.position
local surface = entity.surface	
local proto_force = game.forces.protomolecule
local tile = surface.get_tile(entity.position.x,entity.position.y).name

--FillWith(surface,GetAreaAroundPos(entity.position, 4),nil,{'cyan-refined-concrete'})
local protomolecule_spawner = surface.create_entity{name='msi_protomolecule_spawner', position=position, force=proto_force,spawn_decorations=true }
protomolecule_spawner.destructible=false
entity.destroy()

local act1 = {action='projectile_shoot_near_player',projectile='cb-cluster-cold-projectile-big',distance=100, chance = 0.15}
local act2 = {action='projectile_shoot_near_player',projectile='explosive-rocket',distance=35, chance = 0.4}
local act3 = {action='spawn_effect',effect='explode', explosion_name='big-artillery-cold-explosion',chance = 0.4}
local act4 = {action='shock_hazard',radius = 30, quant = 4, chance = 0.3}
local act5 = {action='defender_capsules', chance = 0.4}
local activities = {act1,act2,act3,act4,act5}
data.entity = protomolecule_spawner
data.special_entity_activity=activities
table.insert(global.monitored_entity,{entity=protomolecule_waking,event="special_entity_activity",tab_event=data})
data.force.technologies['msi_protomolecule_awaken'].enabled = true
register_research_mission(data.force,'msi_protomolecule_awaken', data)

-- create spawners and instant cold streams

local area = GetAreaAroundPos(protomolecule_spawner.position, 30)
FillWaterWith(surface,area,{tile})
protomolecule_spawns_nearby(protomolecule_spawner,true)

table.insert(global.monitored_entity,{entity=protomolecule_spawner,event="protomolecule_activity",tab_event={progress=0, extra_activity ='spawns_nearby'}})

data.force.play_sound{path='tc_sound_siren'}
if game.active_mods['mferrari-mod-sounds'] then data.force.play_sound{path='mferrari_tense_music_3m',override_sound_type='ambient'} end
data.force.print({"",{"Mining-Space-Industries-II.page_mission_name_M_research_msi_protomolecule_awaken"},get_gps_tag(protomolecule_spawner.position,protomolecule_spawner.surface)},colors.yellow)

if game.active_mods['space-exploration'] then 
	for d=1,global.settings.difficulty_level do 
		remote.call("space-exploration", "begin_solar_flare", {zone_name = global.se_universe.by_name[surface.name].name, targeting="basic"}) 
		end
	end
end



function get_se_zone_for_mission(forces,requirements,skip_home) 
local opt1, opt2, all = {},{},{}
local surf_name

if forces then
	for f=1,#forces do 
		local force=forces[f]

		local known_zones = global.force_control[force.name].se_known_zones
		local home_id = remote.call("space-exploration", "get_zone_from_surface_index", {surface_index = global.force_control[force.name].home_surface.index})
		local mi_qt = 10
		
		for id,_ in pairs (known_zones) do
			if (not skip_home) or (home_id~=id) then 
				local zone = global.se_universe.by_index[id]
				if zone then 
					zone.missions = zone.missions or 0
					if zone.missions < mi_qt then mi_qt=zone.missions end 
					end
				end
			end
		
		for id,_ in pairs (known_zones) do
			if (not skip_home) or (home_id~=id) then 
				local zone = global.se_universe.by_index[id]
				if zone then
					local missions = zone.missions
					if missions<=mi_qt then 
						if requirements.type=='enemy' then if zone.enemy_base and 
							zone.enemy_base.frequency>=requirements.value and zone.enemy_base.frequency<=requirements.max and
							zone.enemy_base.size>=requirements.value and zone.enemy_base.size<=requirements.max then table.insert(opt1,id) end end
						table.insert(opt2,id)
						end
					table.insert(all,id)
					end
				end
			end
		end
	end

local id
if #opt1>0 then id=opt1[math.random(#opt1)] 
	elseif #opt2>0 then id=opt2[math.random(#opt2)] 
	elseif #all>0 then id=all[math.random(#all)] end

if id then 
	local zone = global.se_universe.by_index[id]
	zone.missions = zone.missions+1
	return zone.name 
	end
end


--local mission_categories = {'unique','science_packs','power','production','transportation','military','ultimate_techs','upgrades'}
function  CreateNewMissionEvent(force,surface_name,mission_category,choosen_tech,tick)
if not tick then tick =game.tick + 60*(math.random(2)) end
local home_name =  global.force_control[force.name].home_surface.name

if not surface_name then surface_name = home_name end

local event_protomolecule
if mission_category=='unique' and choosen_tech=='start_protomolecule_0' then 
	tick = game.tick
	choosen_tech=nil
	event_protomolecule='msi_dorment_protomolecule'
	elseif mission_category=='unique' and choosen_tech=='start_protomolecule_main_boss' then 
	tick = game.tick
	choosen_tech=nil
	event_protomolecule='msi_protomolecule_spawner_boss'
	end

if game.active_mods['space-exploration'] then 
	if (not event_protomolecule) and (global.settings.allow_mission_planets) then --surface_name = get_se_zone_for_mission({force},{type='enemy',value=1.5, max=10},true) or surface_name
	    if (in_list({'power','production','military','space_rockets'}, mission_category) and force.technologies['se-rocket-launch-pad'].researched ) or 
		(mission_category=='ultimate_techs' and force.technologies['se-spaceship'].researched)	then 
		-- choose another planets for specific missions 
			surface_name = get_se_zone_for_mission({force},{type='enemy',value=0.3, max=1.5}) or surface_name
			end
		elseif event_protomolecule=='msi_protomolecule_spawner_boss' then  -- protomolecule 
			on_protomolecule_rocket_launched(game.surfaces[surface_name],nil,true)
		end
	end

local surface= game.surfaces[surface_name]
local event = {event='create_new_mission', force=force, mission_category=mission_category, choosen_tech=choosen_tech,  tick = tick, 
			surface=surface,surface_name=surface_name, protomolecule=event_protomolecule}

table.insert(global.wait_for_event,event)	
end




function spawn_companion_for_force(force, home_name, companion) 
local surface= game.surfaces[home_name]
if companion=='droid' then 
	local spawn_wreck = global.force_control[force.name].companions.droid.spawn_wreck
	local mission_name = 'MI_003_companion_droid'
	local mission_category='unique' 
	if not (spawn_wreck and spawn_wreck.valid) then 
			local extraInfo = {force=force, mission_category=mission_category, mission_name=mission_name}	
			local placing_data= {surface=surface,
								 entity_name="big-ship-wreck-1",
								 force=force,
								 from_position=force.get_spawn_position(surface),
								 ungenerated_chunk=false,
								 avoid_near = avoid_game_ores(),
								 avoid_near_tile = avoid_water_tiles(),								 
								 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
								 extraInfo=extraInfo,
								 }
			table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})

		else 
		local add = true
		for m=1,#global.monitored_entity do 
			if global.monitored_entity[m].entity==spawn_wreck and global.monitored_entity[m].event=="repair_event" then add=false break end
			end
		if add then 
			local required_items,speach=GetRandonRepairItems(force,2,nil,nil,0.7)
			Entity_Speak(spawn_wreck,{'labels.insert_to_repair',speach})
			force.print({"",{"Mining-Space-Industries-II.title_mission_name_MI_003_companion_droid"},get_gps_tag(spawn_wreck.position,spawn_wreck.surface)},colors.yellow)
			extraInfo = {required_items=required_items, force=force, call_attacks=false,mission_name=mission_name, mission_category=mission_category}
			table.insert(global.monitored_entity,{entity=spawn_wreck,event="repair_event",tab_event=extraInfo})
			end
		end 
	
	elseif companion=='synthetic' then 
		local spawn_wreck = global.force_control[force.name].companions.synthetic.spawn_wreck
		local mission_name = 'MI_003_companion_synthetic'
		local mission_category='unique' 
		if not (spawn_wreck and spawn_wreck.valid) then 
				local extraInfo = {force=force, mission_category=mission_category, mission_name=mission_name}	
				local placing_data= {surface=surface,
									 entity_name="big-ship-wreck-3",
									 force=force,
									 ungenerated_chunk=false,
									 avoid_near = avoid_game_ores(),
									 from_position=force.get_spawn_position(surface),
									 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
									 extraInfo=extraInfo,
									 }
				table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})

			else 
			local add = true
			for m=1,#global.monitored_entity do 
				if global.monitored_entity[m].entity==spawn_wreck and global.monitored_entity[m].event=="repair_event" then add=false break end
				end
			if add then 
				local required_items,speach=GetRandonRepairItems(force,2,nil,nil,0.7)
				Entity_Speak(spawn_wreck,{'labels.insert_to_repair',speach})
				force.print({"",{"Mining-Space-Industries-II.title_A_mission_name_MI_003_companion_synthetic"},get_gps_tag(spawn_wreck.position,spawn_wreck.surface)},colors.yellow)
				extraInfo = {required_items=required_items, force=force, call_attacks=false,mission_name=mission_name, mission_category=mission_category}
				table.insert(global.monitored_entity,{entity=spawn_wreck,event="repair_event",tab_event=extraInfo})
				end
			end 	
	end
end



function register_kill_mission_force(force, target, mission_name, data)
	local position = target.position
	local surface = target.surface
	local cam_text = get_localized_name(target.name)
	CreateCameraForForce(force,target,surface,cam_text,nil,nil,0.15)
	local camera = {entity=target,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..target.name..']', text=cam_text}
	local reward = { {type = 'team_XP', XP = Get_XP_ratio(2000)}}
	if data.choosen_tech then table.insert(reward, {type = 'unlock_tech', techs = {data.choosen_tech}}) end
	local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{target},data) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
	register_entity_destruction(target,data)
	data.target=target data.surface=surface
	create_tatoo_for_unit(target)
	if game.active_mods['mferrari-mod-sounds'] then data.force.play_sound{path='mferrari_tense_music_2m',override_sound_type='ambient'} end
end



function register_entity_destruction(entity,data)
local re_id = script.register_on_entity_destroyed(entity) 
data.re_id = re_id
global.registered_entities[re_id] = data
local unit_number =entity.unit_number 
if unit_number then global.registered_entities_unitnumber[entity.unit_number]=0 end  -- to test if it really died
end

function register_research_mission(force, tech_name, data)
if not data then data={} end
data.force=force
data.tech_name=tech_name
data.mission_name='M_research_'..tech_name
data.mission_category='research'
local reward = { {type = 'print_text', texts = {{'technology-description.'..tech_name}}},
					{type = 'team_XP', XP = Get_XP_ratio(2000)}}
add_mission_log(nil,force,data.mission_name,reward,nil, nil,nil,data) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
global.force_control[force.name].research_missions[tech_name] = data
end



function create_unique_boss_mission(force, boss) 
local event = {event='create_new_mission', force=force, mission_category='unique', boss=boss, 
               surface=global.force_control[force.name].home_surface,surface_name=global.force_control[force.name].home_surface.name, tick = game.tick + 60*60*4 + math.random(60*60*9)}
table.insert(global.wait_for_event,event)
end



function get_force_game_progress(force)
local progress = game.forces.enemy.evolution_factor / 2
local qt, acc= 0,0
for cat, techs in pairs ( global.mission_techs) do
	qt = qt + #techs
	for t=1, #techs do  
		if force.technologies[techs[t]].researched then acc=acc+1 end
		end
	end
local tr = acc/qt
progress = progress + tr / 2
return progress
end

function Get_Chunk_Distance_For_Mission(surface, force, mp_dist)
-- to do: add another progress metrics (techs ?),
local surf_name=surface.name
local progress = get_force_game_progress(force)
if not mp_dist then mp_dist=1 end
mp_dist = mp_dist * global.settings.mission_distance
local min_dist = 8
local maxdist = 80
local max_modded = maxdist
if game.active_mods['space-exploration'] then
		local pradius = 5000 
		if global.se_universe.by_name[surf_name] then pradius =global.se_universe.by_name[surf_name].radius end
		max_modded = math.floor (pradius/32) - 3
	else 
	local mpg = surface.map_gen_settings
	local w,h=mpg.width, mpg.height
		if w+h>0 then 
			if w==0 then w=maxdist*32 end
			if h==0 then h=maxdist*32 end
			max_modded = math.floor(math.min(w,h)/32)-3
			end
	end
maxdist = math.min(maxdist,max_modded)	
if min_dist>maxdist then min_dist = maxdist-1 end
local extra_distance = math.floor((maxdist - min_dist) * progress * mp_dist)
local final_dist = min_dist + extra_distance
if final_dist>maxdist then final_dist=maxdist end
return final_dist + math.random(0,2)
end


function create_new_mission(event)
local mission_category=event.mission_category
local choosen_tech=event.choosen_tech
local force=event.force
event.mission_name = 'M_' ..mission_category


local surface
if event.surface_name then 
	if game.surfaces[event.surface_name] and game.surfaces[event.surface_name].valid then surface = game.surfaces[event.surface_name]
		else  -- create surface on space exploration 
		if game.active_mods['space-exploration'] then 
			surface = remote.call("space-exploration", "zone_get_make_surface", {zone_index =  remote.call("space-exploration", "get_zone_from_name", {zone_name = event.surface_name}).index})
			end
		end
	end
if not surface then surface = event.surface end



if mission_category=='science_packs' then
		-- Go fix a droid somewere and escort it back a Science Droid do the spaceship, or from ship to distant place (harder)?
		-- if fail. Create a new mission with same event tab
		local placing_data= {surface=surface,
							 entity_name='msi_broken_lab',
							 force=force,
							 from_position=force.get_spawn_position(surface),
							 ungenerated_chunk=false,
							 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force,0.5),
							 extraInfo=event,
							 }
		table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})



	elseif mission_category=='power' then
	--Acumulador caido, precisa ser recarregado
		local level = get_progress_10(force)
		local placing_data= {surface=surface,
							 entity_name="msi_charge_generator-"..level,
							 force=force,
							 from_position=force.get_spawn_position(surface),
							 ungenerated_chunk=false,
							 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
							 extraInfo=event,
							 }
		table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})


	elseif mission_category=='transportation' then
	--Carro distante, precisa voltar pra base
		local placing_data= {surface=surface,
							 entity_name="msi_mission_car",
							 force=force,
							 from_position=force.get_spawn_position(surface),
							 ungenerated_chunk=false,
							 avoid_near_tile = avoid_water_tiles(),							 
							 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force,0.6),
							 extraInfo=event,
							 }
		table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})

	elseif mission_category=='upgrades' then
	--Terminal, precisa conectar com circuito verde ate a nave inicial
		local placing_data= {surface=surface,
							 entity_name="msi_mission_terminal",
							 force=force,
							 from_position=force.get_spawn_position(surface),
							 ungenerated_chunk=false,
							 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force,0.7),
							 extraInfo=event,
							 }
		table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})


	elseif mission_category=='ultimate_techs' then
	--shipwreck, levar o companion droid para abrir com laser tech
		local placing_data= {surface=surface,
							 entity_name="crash-site-spaceship-wreck-medium-2",
							 force=force,
							 from_position=force.get_spawn_position(surface),
							 ungenerated_chunk=false,
							 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
							 extraInfo=event,
							 }
		table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})

	elseif mission_category=='production' then
	--crashed assembling machine, repair + crafting
		local placing_data= {surface=surface,
							 entity_name="msi_broken_machine",
							 force=force,
							 from_position=force.get_spawn_position(surface),
							 ungenerated_chunk=false,
							 chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
							 extraInfo=event,
							 }
		table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})


	elseif mission_category=='military' then
		local target
		if game.forces.enemy.evolution_factor < 0.05 then 
			local nests = surface.find_entities_filtered{type='unit-spawner', position=force.get_spawn_position(surface), radius=500, limit=100}
			if #nests>0 then 
				target = nests[math.random(#nests)]
				local name=target.name
				local p = surface.find_non_colliding_position(name, target.position, 0, 1)
				local boss = surface.create_entity{name = name, position=p, force=target.force, spawn_decorations=true}
				register_kill_mission_force(force, boss, event.mission_name, event)
				end
			end
		if not target then 
			local boss = get_random_boss()
			local placing_data={surface=surface,
						entity_name=boss,
						force=game.forces.enemy,
						from_position=force.get_spawn_position(surface),
						ungenerated_chunk=false,
					    avoid_near_tile = avoid_water_tiles(),						
						chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
						extraInfo=event}
			table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick + 60, data_table=placing_data})
			end

			
	-- UNIQUE MISSIONS CATEGORY
	elseif mission_category=='unique' then
		
		if choosen_tech then
		if choosen_tech=='oil-processing' then 
			event.mission_name = event.mission_name .. '_oil'
			local placing_data={surface=surface,
						entity_name='crude-oil',
						force=nil,
						from_position=force.get_spawn_position(surface),
						ungenerated_chunk=false,
						chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
						extraInfo=event}
		    table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})
			end


		if choosen_tech=='rocket-silo' then 
			event.mission_name = event.mission_name .. '_rocket_silo'
			local placing_data={surface=surface,
						entity_name='a_place_with_land',
						force=force,
						from_position=force.get_spawn_position(surface),
						ungenerated_chunk=false,
						avoid_near = avoid_game_ores(),
						chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
						extraInfo=event}
		    table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})
			end


		if choosen_tech=='msi_tech_lock_satellites' then 
			event.mission_name = event.mission_name .. '_satellites'
			local reward = {{type = 'unlock_tech', techs = {event.choosen_tech}, auto_research=true}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
			event.choosen_tech=nil event.reward=reward
			local rocket_launch_request = {items_required={name='satellite',count=13 + global.settings.difficulty_level*2}, count_force_launched=true}
			create_rocket_request_mission(event, rocket_launch_request) -- data = {force=,mission_name=,reward=}			
			end			
		
		else -- no choosen_tech
			if event.boss then 
				local boss = event.boss
				event.mission_name = event.mission_name .. '_boss_' .. boss
				local placing_data={surface=surface,
							entity_name=boss,
							force=game.forces.enemy,
							from_position=force.get_spawn_position(surface),
							ungenerated_chunk=false,
							chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
							extraInfo=event}
				table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})				
			end

			if event.protomolecule then 
				local protomolecule = event.protomolecule
				event.mission_name = event.mission_name .. '_' .. protomolecule
				local placing_data={surface=surface,
							entity_name=protomolecule,
							force=game.forces.protomolecule,
							from_position=force.get_spawn_position(surface),
							ungenerated_chunk=true,
							chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
							extraInfo=event}
				table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})				
			end
			
		end

	-- space_rockets
	elseif mission_category=='space_rockets' then
		if in_list({'atomic-bomb','spidertron'},event.choosen_tech) then  
			local reward = {{type = 'unlock_tech', techs = {event.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
			event.reward=reward
			local item_req = global.mission_techs_space_rockets_items[choosen_tech]
			local count = game.item_prototypes[item_req].stack_size
			local rocket_launch_request = {items_required={name=item_req,count=count}, count_force_launched=true}
			create_rocket_request_mission(event, rocket_launch_request) -- data = {force=,mission_name=,reward=}
		else
		
			local placing_data={surface=surface,
						entity_name='a_place_with_land',
						force=force,
						from_position=force.get_spawn_position(surface),
						ungenerated_chunk=false,
						chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
						extraInfo=event}
			table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick, data_table=placing_data})
		end
	end

end




function add_map_tag (force, surface, position, icon, text, data)
local tag = {icon=icon,text=text,position=position}
local eve = {event='add_map_tag',surface=surface,force=force,tag=tag, data=data}
table.insert (global.wait_for_event, eve)
end


function check_events()
for k=#global.wait_for_event, 1,-1 do
	
	local theEvent = global.wait_for_event[k]
	local tick   = theEvent.tick or 1
	local event  = theEvent.event
	
	if game.tick >= tick  then
		
		if event == 'initialize_force_settings' then initialize_force_settings(theEvent.player_force)
		elseif event == 'initialize_game_settings' then initialize_game_settings()
		elseif event == 'create_new_mission' then create_new_mission(theEvent)
		elseif event == 'add_map_tag' then 
			local tag = theEvent.force.add_chart_tag(theEvent.surface,theEvent.tag)
			if theEvent.data then theEvent.data.map_tag=tag end
	
		elseif event == 'activate_turret' then
			local entity=theEvent.entity
			if entity and entity.valid then entity.active=true end
		
		elseif event == 'placing_entity_on_map' then Create_Mission_Entity(theEvent.data_table) 
		
		elseif event == 'unit_goes_to' then 
			if theEvent.unit and theEvent.unit.valid then unit_go_to_loc(theEvent.unit,theEvent.destination) end
		end
			
		table.remove(global.wait_for_event,k)
		end

	end

end




function Monitored_Entities()


for k=#global.monitored_entity,1,-1 do
	
	local entity = global.monitored_entity[k].entity
	local event  = global.monitored_entity[k].event
	local tab_event=global.monitored_entity[k].tab_event
		

	if not (entity and entity.valid) then
		table.remove(global.monitored_entity,k)
		else
		local force = entity.force
		local surface=entity.surface


		if event=="repair_event" then
			local items = tab_event.required_items
			if check_container_for_items(entity,items) then
				remove_items_from_container(entity,items)
				if tab_event.call_attacks then CallFrenzyAttack(surface,entity.position) end 
				local mission_name=tab_event.mission_name
				tab_event.entity = entity
				if mission_name then advance_mission_control(mission_name,tab_event) end
				table.remove(global.monitored_entity,k)
				end

		elseif event=="M_science_packs" then -- escort tech droid
			local destination = global.force_control[entity.force.name].spaceship_wreck.position
			if math.random(15)==1 then CallFrenzyAttack(surface,entity) end
			if math.random(25)==1 then if distance(entity.position,destination)>120 then CallWormAttack(surface,entity.position,1,20) end end
			if (not global.control_e_tick[force.name]) or (game.tick > global.control_e_tick[force.name]+ 60*5) then unit_follows_player(entity,defines.distraction.none) end
			if distance(entity.position,destination)<20 then
				tab_event.state=2
				advance_mission_control(tab_event.mission_name,tab_event)
				table.remove(global.monitored_entity,k)
				end


		elseif event=="charge_event" then
			if entity.energy>0 then 
				entity.surface.pollute(entity.position,25) 
				entity.surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=entity.position}  
				entity.surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
				if math.random(20)==1 then CallFrenzyAttack(surface,entity.position) end
				if math.random(25)==1 then CallWormAttack(surface,entity.position,1,15) end
				end
			if entity.energy >= entity.electric_buffer_size-10 then
				advance_mission_control(tab_event.mission_name,tab_event)
				table.remove(global.monitored_entity,k)
				end


		elseif event=="mission_car_event" then
			if entity.get_driver() then 
				if math.random(20)==1 then CallFrenzyAttack(surface,entity) end
				if math.random(25)==1 then CallWormAttack(surface,entity.position,1,15) end
				end
			local destination = global.force_control[entity.force.name].spaceship_wreck.position
			if distance(entity.position,destination)<20 then
				advance_mission_control(tab_event.mission_name,tab_event)
				table.remove(global.monitored_entity,k)
				end


		elseif event=="circuit_upgrade_event" then
			local CN = entity.get_circuit_network(defines.wire_type.green) 
			if CN then
				local spaceship = global.force_control[entity.force.name].spaceship_wreck
				local SS_CN = spaceship.get_circuit_network(defines.wire_type.green)
				local network_id = CN.network_id
				if SS_CN and SS_CN.network_id == network_id then 
					tab_event.progress=tab_event.progress + 0.5
					Entity_Speak(entity,math.floor(tab_event.progress) ..'%   [img=technology/' .. tab_event.choosen_tech..']')
					entity.surface.pollute(entity.position,25) 
					entity.surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=entity.position}
					entity.surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
					create_spark_particles(surface, 50, entity.position,2)
					if math.random(20)==1 then CallFrenzyAttack(surface,entity.position) end
					if math.random(25)==1 then CallWormAttack(surface,entity.position,1,15) end	
					if tab_event.progress>=100 then 
						advance_mission_control(tab_event.mission_name,tab_event)
						table.remove(global.monitored_entity,k)
						end
					end
				end


		elseif event=="droid_laser_event" then	
			local companion = global.force_control[force.name].companions.droid.entity
			if companion and companion.valid and  entity.surface == companion.surface and
				distance(companion.position,entity.position)<=15 then 
				
				surface.create_entity{name = 'blue-laser-beam', position=companion.position, source = companion, target_position=entity.position, duration=40}
				tab_event.progress=tab_event.progress + 0.4
				Entity_Speak(entity,math.floor(tab_event.progress) ..'%   [img=technology/' .. tab_event.choosen_tech..']')
				entity.surface.pollute(entity.position,25) 
				entity.surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=entity.position}
				entity.surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
				create_spark_particles(surface, 50, entity.position,2)
				if math.random(20)==1 then CallFrenzyAttack(surface,entity.position) end
				if math.random(25)==1 then CallWormAttack(surface,entity.position,1,15) end	
				if tab_event.progress>=100 then 
					advance_mission_control(tab_event.mission_name,tab_event)
					table.remove(global.monitored_entity,k)
					end
				end
				

		elseif event=="droid_repair_synthetic" then	
			local companion = global.force_control[force.name].companions.droid.entity
			if companion and companion.valid and  entity.surface == companion.surface and
				distance(companion.position,entity.position)<=15 then 
				surface.create_entity{name = 'green-laser-beam', position=companion.position, source = companion, target_position=entity.position, duration=40}
				tab_event.progress=tab_event.progress + 1
				Entity_Speak(entity,math.floor(tab_event.progress) ..' %')
				create_blood_particles(surface, 3, entity.position)
				--if math.random(10)==1 then CallFrenzyAttack(surface,entity.position) end
				if tab_event.progress>=100 then 
					advance_mission_control(tab_event.mission_name,tab_event)
					table.remove(global.monitored_entity,k)
					end
				end


		elseif event=="protomolecule_waking" then	
			tab_event.progress=tab_event.progress + 0.75
			if tab_event.progress==99 then entity.surface.create_entity{name = "small-atomic-cold-explosion", position = entity.position} end
			if math.random(8)==1 then Entity_Speak(entity,{'labels.david_suffering_'..math.random(5)}, 3) end
			create_blood_particles(surface, 5, entity.position)
			if tab_event.progress>=100 then 
				event_protomolecule_awaken(tab_event)
				table.remove(global.monitored_entity,k)
				end


		elseif event=="M_production" then	
			if tab_event.state==1 then 
				if entity.products_finished>0 then
					tab_event.state=2
					advance_mission_control(tab_event.mission_name,tab_event)
					table.remove(global.monitored_entity,k)
				elseif entity.is_crafting() and entity.energy>0 then 
					if math.random(20)==1 then CallFrenzyAttack(surface,entity.position) end
					if math.random(30)==1 then CallWormAttack(surface,entity.position,1,15) end
					entity.surface.pollute(entity.position,25) 
					entity.surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=entity.position}
					entity.surface.create_trivial_smoke{name='turbine-smoke', position=entity.position}
					create_spark_particles(surface, 50, entity.position,2)
					end
				end

	
		elseif game.tick%120==0 and event=="special_entity_activity" then special_entity_activity(entity,tab_event) 
		elseif event=="protomolecule_activity" then protomolecule_activity(entity,tab_event) 

		
		elseif event=="timer_event" then
			local tick = tab_event.timer_tick
			if game.tick<tick then
				if tab_event.call_attacks and math.random(20)==1 then CallFrenzyAttack(surface,entity.position) end
				if tab_event.speak_time_left then
					local timer = format_time_from_tick(tick)
					local also_speak = tab_event.also_speak
					local left_icon = tab_event.left_icon
					if left_icon then  timer = {"",left_icon,timer} end
					if also_speak then timer = {"",timer, " ",also_speak} end
					Entity_Speak(entity,timer)
					end
				else
				table.remove(global.monitored_entity,k)
				on_timed_event_finish(entity,tab_event)
				end
	

		end
	end
	end
	

end


function on_timed_event_finish(entity,tab_event)
if tab_event.finish_effect then
	if tab_event.finish_effect=='explode' then 
		entity.surface.create_entity{name = tab_event.explosion_name, position = entity.position}
		end
	end
end


function on_Entity_Mission_Created(tab)
local entity=tab.entity
local extraInfo=tab.extraInfo
local surface = entity.surface
local mission_name = extraInfo.mission_name

local eforce = entity.force
if eforce.name~='enemy' and eforce.name~='neutral' and eforce.name~='protomolecule' then 
	eforce.chart(surface, square_area(entity.position,5))
	end

if extraInfo and extraInfo.print_text then 
	game.print({"",icons.info,extraInfo.print_text}, colors.lightblue) end
	
if entity.name=='msi_broken_lab' then
	local force = entity.force
	local position = entity.position
	if mission_name=='MI_001_broken_lab' then 
			entity.destructible = false
			local falling_lab = surface.create_entity({name='falling-entity-msi_broken_lab', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
			local cam_text = get_localized_name(entity.name)
			CreateCameraForForce(force,falling_lab,surface,cam_text,nil,nil,0.15)
			local  required_items,speach,full_list=GetRandonRepairItems(force,3,nil,nil,0.5)
			local repair_items_list = {{'labels.repair_items_list'}}
			concat_lists(repair_items_list, full_list)
			Entity_Speak(entity,{'labels.insert_to_repair',speach})
			local recipe = 'automation-science-pack'
			if force.recipes['basic-tech-card'] then recipe ='basic-tech-card' end
			local reward = { {type = 'unlock_recipe', recipes = {recipe}}, {type = 'team_XP', XP = 650}}
			local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/crash-site-lab-repaired]', text=cam_text}
			local data = {}
			add_map_tag (force, surface, position, {type="item",name="lab"}, nil, data)
			local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},data,true,repair_items_list,required_items) --(mission_id,force,mission_name,rewards, pictures, cameras, entities, data,print_goal)
			extraInfo = {required_items=required_items, call_attacks=true,mission_name=mission_name, mission_id=mission_id}
			table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=extraInfo})
			
		
		 --extraInfo={mission_name ='MISSION_'..mission_category, choosen_tech=event.choosen_tech}
		elseif mission_name=='M_science_packs' then 
			local cam_text = get_localized_name(entity.name)
			CreateCameraForForce(force,entity,surface,cam_text,nil,nil,0.15)
			local required_items,speach,full_list=GetRandonRepairItems(force,4)
			local repair_items_list = {{'labels.repair_items_list'}}
			concat_lists(repair_items_list, full_list)
			Entity_Speak(entity,{'labels.insert_to_repair',speach})
			local reward = { {type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
			local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/crash-site-lab-repaired]', text=cam_text}
			extraInfo.required_items=required_items extraInfo.reward=reward
			register_entity_destruction(entity,extraInfo)
			add_map_tag (force, surface, position, {type="item",name="utility-science-pack"}, nil, extraInfo)
			local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo,nil,repair_items_list,required_items) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
			table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=extraInfo})
			
		
		end

	elseif entity.name=='msi-broken-generator' then
		mission_name='MI_002_broken_generator'
		local position = entity.position
		local force = entity.force
		local falling_generator = surface.create_entity({name='falling-entity-msi-broken-generator', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		local cam_text = get_localized_name(entity.name)
		CreateCameraForForce(force,falling_generator,surface,cam_text,nil,nil,0.15)
		local  required_items,speach,full_list=GetRandonRepairItems(force,3,nil,nil,0.4)
		local repair_items_list = {{'labels.repair_items_list'}}
		concat_lists(repair_items_list, full_list)
		Entity_Speak(entity,{'labels.insert_to_repair',speach})
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/crashed-generator]', text=cam_text}
		local reward = {{type = 'team_XP', XP = 500}}
		local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},nil,nil,repair_items_list,required_items) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		local data={required_items=required_items, mission_name=mission_name, mission_id=mission_id,force=force, entity_name=entity.name, position=entity.position, surface=surface}
		register_entity_destruction(entity,data)
		table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=data})
			add_map_tag (force, surface, position, {type="item",name="accumulator"}, nil, data)
			data.timer_tick = game.tick + 60*60*45 + math.random(60*7)
			data.speak_time_left=true data.finish_effect='explode' data.explosion_name='small-atomic-explosion'
			data.also_speak={'labels.insert_to_repair',speach}    data.left_icon=maf_icons.nuke		
			table.insert(global.monitored_entity,{entity=entity,event="timer_event",tab_event=data})	

	elseif mission_name and (mission_name=='MI_010_machines_shipwreck' or mission_name=='MI_011_military_shipwreck') then
		local position = entity.position
		local force = entity.force
		extraInfo.force=force
		local falling_wreck = surface.create_entity({name='falling-entity-big-ship-wreck-2', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		local cam_text = get_localized_name(entity.name)
		CreateCameraForForce(force,falling_wreck,surface,cam_text,nil,nil,0.15)
		local required_items,speach,full_list=GetRandonRepairItems(force,3,nil,nil,0.4)
		local repair_items_list = {{'labels.repair_items_list'}}
		concat_lists(repair_items_list, full_list)
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/big-ship-wreck-2]', text=cam_text}
		local reward = {{type = 'print_text', texts = {{'labels.recover_useful_materials'}}},
						{type = 'team_XP', XP = 500}}		
		add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo,nil,repair_items_list,required_items) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		extraInfo.required_items=required_items extraInfo.entity=entity  extraInfo.position=entity.position extraInfo.surface=surface
		register_entity_destruction(entity,extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=extraInfo})
		extraInfo.timer_tick = game.tick + 60*60*35 + math.random(60*6)
		extraInfo.speak_time_left=true extraInfo.finish_effect='explode' extraInfo.explosion_name='small-atomic-explosion'
		extraInfo.also_speak={'labels.insert_to_repair',speach}    extraInfo.left_icon=maf_icons.nuke	
		add_map_tag (force, surface, position, {type="item",name="cargo-wagon"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="timer_event",tab_event=extraInfo})
		CallWormAttack(surface,entity.position,3+math.random(3),4)


	elseif mission_name and mission_name=='M_military' then
		entity.ai_settings.allow_destroy_when_commands_fail=false
		register_kill_mission_force(extraInfo.force, entity, mission_name, extraInfo)
		local evo = game.forces.enemy.evolution_factor
		local activities = {}
		if evo>0.4 then 
			if math.random (2)==1 then table.insert(activities,{action='shock_hazard',radius = 30, quant = 5, chance = 0.3}) end
			end
		if evo>0.65 then 
			if math.random(2)==1 then table.insert(activities,{action='defender_capsules', chance = global.settings.difficulty_level/10}) end 
			if math.random(2)==1 then table.insert(activities,{action='worm_attack_near_player',chance = 0.03 + global.settings.difficulty_level/100, distance=60, how_many=1}) end 
			end
		if evo>0.85 then
			if math.random (3)==1 then table.insert(activities,{action='breeder',chance = global.settings.difficulty_level/10 }) 
				elseif math.random (3)==1 then table.insert(activities,{action='grenade_launcher',chance = global.settings.difficulty_level/10 })
				end
			end
		if #activities>0 then 
			extraInfo.special_entity_activity=activities
			table.insert(global.monitored_entity,{entity=entity,event="special_entity_activity",tab_event=extraInfo})
			end
		
		if evo>0.15 and math.random (2)==1 then 
			local event = {event='unit_goes_to', unit=entity, tick=game.tick + 60*60* (15 + math.random(15)),
				destination=extraInfo.force.get_spawn_position(entity.surface)}
			table.insert(global.wait_for_event,event)
			end

	
	elseif mission_name and mission_name=='M_unique_oil' then
		entity.amount=1000
		extraInfo.entity = entity  extraInfo.progress=0
		local position = entity.position
		local force = extraInfo.force
		local cam_text = get_localized_name(entity.name)
		CreateCameraForForce(force,entity,surface,cam_text,nil,nil)
		force.chart(surface, square_area(position,5))
		add_map_tag (force, surface, position, {type="item",name="pumpjack"}, nil, extraInfo)
		Entity_Speak(entity,'[img=technology/' .. extraInfo.choosen_tech..']')
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name..']', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		global.force_control[force.name].companions.synthetic.missions[mission_name] = extraInfo


	elseif mission_name and mission_name=='M_power' then -- MODELO PADRAO
		entity.minable=false
		local position = entity.position
		local force = extraInfo.force
		local falling_generator = surface.create_entity({name='falling-entity-msi-broken-generator', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		local cam_text = get_localized_name(entity.name)
		CreateCameraForForce(force,falling_generator,surface,cam_text,nil,nil,0.15)
		Entity_Speak(entity,'[img=technology/' .. extraInfo.choosen_tech..']')
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name..']', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		register_entity_destruction(entity,extraInfo)
		extraInfo.entity = entity
		add_map_tag (force, surface, position, {type="item",name="steam-engine"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="charge_event",tab_event=extraInfo})

	elseif mission_name and mission_name=='M_transportation' then -- MODELO PADRAO
		entity.minable=false
		if game.active_mods['Krastorio2'] then entity.insert{name='fuel', count=30} end
		local position = entity.position
		local force = extraInfo.force
		local cam_text = get_localized_name(entity.name)
		CreateCameraForForce(force,entity,surface,cam_text,nil,nil,0.15)
		Entity_Speak(entity,'[img=technology/' .. extraInfo.choosen_tech..']')
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name..']', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		register_entity_destruction(entity,extraInfo)
		extraInfo.entity = entity
		add_map_tag (force, surface, position, {type="item",name="car"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="mission_car_event",tab_event=extraInfo})

		
	elseif mission_name and mission_name=='M_upgrades' then
		entity.minable=false
		local position = entity.position
		local force = extraInfo.force
		local cam_text = get_localized_name(entity.name)
		local falling_terminal = surface.create_entity({name='falling-entity-msi_mission_terminal', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		CreateCameraForForce(force,falling_terminal,surface,cam_text,nil,nil,0.15)
		Entity_Speak(entity,'[img=technology/' .. extraInfo.choosen_tech..']')
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name..']', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		register_entity_destruction(entity,extraInfo)
		extraInfo.entity = entity
		extraInfo.progress=0
		add_map_tag (force, surface, position, {type="item",name="roboport"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="circuit_upgrade_event",tab_event=extraInfo})
		
	elseif mission_name and mission_name=='MI_003_companion_droid' then
		entity.destructible = false
		entity.minable = false
		local force = extraInfo.force
		global.force_control[force.name].companions.droid.spawn_wreck=entity
		local cam_text = get_localized_name(entity.name)
		local position = entity.position
		local falling_wreck = surface.create_entity({name='falling-entity-'..entity.name, position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		CreateCameraForForce(force,falling_wreck,surface,cam_text,nil,nil,0.15)
		local required_items,speach=GetRandonRepairItems(force,2,nil,nil,0.7)   --(force,nitems,add_this,always_add_this,mp)
		Entity_Speak(entity,{'labels.insert_to_repair',speach})
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name.. ']', text=cam_text}
		extraInfo.required_items=required_items extraInfo.call_attacks=false
		add_mission_log(nil,force,mission_name,nil,nil, {camera},{entity},extraInfo) 
		add_map_tag (force, surface, position, {type="item",name="defender-capsule"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=extraInfo})
		
	elseif mission_name and mission_name=='MI_003_companion_synthetic' then
		entity.destructible = false
		entity.minable = false
		local force = extraInfo.force
		global.force_control[force.name].companions.synthetic.spawn_wreck=entity
		local cam_text = get_localized_name(entity.name)
		local position = entity.position
		local falling_wreck = surface.create_entity({name='falling-entity-'..entity.name, position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		CreateCameraForForce(force,falling_wreck,surface,cam_text,nil,nil,0.15)
		local required_items,speach=GetRandonRepairItems(force,2,nil,nil,0.7)
		Entity_Speak(entity,{'labels.insert_to_repair',speach})
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name.. ']', text=cam_text}
		extraInfo.required_items=required_items  extraInfo.call_attacks=false
		add_mission_log(nil,force,mission_name,nil,nil, {camera},{entity},extraInfo) 
		add_map_tag (force, surface, position, {type="item",name="exoskeleton-equipment"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=extraInfo})	
		
		
	elseif mission_name and mission_name=='M_ultimate_techs' then
		entity.minable=false
		local position = entity.position
		local force = extraInfo.force
		local cam_text = get_localized_name(entity.name)
		local falling_wreck = surface.create_entity({name='falling-entity-crash-site-spaceship-wreck-medium-2', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		CreateCameraForForce(force,falling_wreck,surface,cam_text,nil,nil,0.15)
		Entity_Speak(entity,'[img=technology/' .. extraInfo.choosen_tech..']')
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name..']', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		register_entity_destruction(entity,extraInfo)
		extraInfo.entity = entity
		extraInfo.progress=0
		add_map_tag (force, surface, position, {type="virtual",name="signal-info"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="droid_laser_event",tab_event=extraInfo})
		
		
	elseif mission_name and mission_name=='M_production' then
		entity.minable = false
		local force = extraInfo.force
		local cam_text = get_localized_name(entity.name)
		local position = entity.position
		local falling_wreck = surface.create_entity({name='falling-entity-crash-site-assembling-machine-1-repaired', position={x=position.x-math.random(20,50),y=position.y-40}, target=position,speed=0.4})
		CreateCameraForForce(force,falling_wreck,surface,cam_text,nil,nil,0.15)
		local required_items,speach,full_list=GetRandonRepairItems(force,4,nil,nil)
		local repair_items_list = {{'labels.repair_items_list'}}
		concat_lists(repair_items_list, full_list)		
		Entity_Speak(entity,{'labels.insert_to_repair',speach})
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name.. ']', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		extraInfo.required_items=required_items extraInfo.call_attacks=false
		register_entity_destruction(entity,extraInfo)
		add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo,false,repair_items_list,required_items) 
		extraInfo.state=1	 extraInfo.reward=reward
		add_map_tag (force, surface, position, {type="item",name="assembling-machine-1"}, nil, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="repair_event",tab_event=extraInfo})


	elseif mission_name and mission_name=='M_unique_boss_msi-smoke-boss-spawner' then
		local act1 = {action='spawn_effect',effect='pollute',pollute_value=17, chance = 1}
		local act2 = {action='worm_attack_near_player',chance = 0.03, distance=100, how_many=3}
		local activities = {act1,act2}
		extraInfo.special_entity_activity=activities
		register_kill_mission_force(extraInfo.force, entity, mission_name, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="special_entity_activity",tab_event=extraInfo})
		CallWormAttack(surface,entity.position,30,4,20)
		extraInfo.force.worker_robots_speed_modifier = extraInfo.force.worker_robots_speed_modifier - 1
		surface.always_day = true
		surface.daytime = 0.5

	elseif mission_name and mission_name=='M_unique_boss_msi-worm-boss-fire-shooter' then
		local act1 = {action='projectile_distant_shoot_at_base',projectile='maf-cluster-fire-projectile',chance = 0.3 + (global.settings.difficulty_level/10), progress=0, reduce_fire_rate=0.01}
		local act2 = {action='breeder',chance = 0.02 + global.settings.difficulty_level/100}
		local act3 = {action='worm_attack_near_player',chance = 0.03, distance=100, how_many=1+global.settings.difficulty_level}
		local activities = {act1,act2,act3}
		if global.settings.difficulty_level>1 then 
			table.insert (activities, {action='projectile_shoot_near_player',distance=100, projectile='maf-cluster-fire-projectile',chance = global.settings.difficulty_level/20})
			end

		extraInfo.special_entity_activity=activities
		register_kill_mission_force(extraInfo.force, entity, mission_name, extraInfo)
		table.insert(global.monitored_entity,{entity=entity,event="special_entity_activity",tab_event=extraInfo})
		CallWormAttack(surface,entity.position,30,4,20)
		
	elseif mission_name and mission_name=='M_unique_msi_dorment_protomolecule' then
		entity.minable=false
		entity.destructible=false
		local position = entity.position
		local force = extraInfo.force
		local cam_text = get_localized_name(entity.name)
		CreateCameraForForce(force,entity,surface,cam_text,nil,nil,0.15)
		local camera = {entity=entity,surface=surface,surface_name=surface.name,position=position,icon='[img=entity/'..entity.name..']', text=cam_text}
		local reward = {{type = 'team_XP', XP = Get_XP_ratio(2000)}}
		local mission_id = add_mission_log(nil,force,mission_name,reward,nil, {camera},{entity},extraInfo) --(force,mission_name,reward, pictures, cameras,entities, print_goal)
		extraInfo.progress=0 extraInfo.entity = entity
		global.force_control[force.name].companions.synthetic.missions[mission_name] = extraInfo
		
	elseif mission_name and mission_name=='M_unique_msi_protomolecule_spawner_boss' then
		create_protomolecule_base(entity, 120, 200)	
		local force = extraInfo.force
		register_kill_mission_force(extraInfo.force, entity, mission_name, extraInfo)

	elseif (not mission_name) and entity.name=='msi_protomolecule_spawner_boss' then
		create_protomolecule_base(entity, 100, 150)	
		local cam_text = get_localized_name(entity.name)
		CreateCameraForConnectedPlayers(entity,entity.surface,cam_text)
		game.print({'labels.protomolecule-new-base', get_gps_tag(entity.position,entity.surface)} ,colors.yellow)
		game.play_sound{path='tc_sound_siren'}
		if game.active_mods['mferrari-mod-sounds'] then data.force.play_sound{path='mferrari_tense_music_3m',override_sound_type='ambient'} end

	end	

end

--local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
--rocket_launch_request = {surface_name=surface.name, position=position, items_required={name=item_req,count=count}, count_force_launched=false}
function create_rocket_request_mission(data, rocket_launch_request) -- data = {force=,mission_name=,reward=}
local force = data.force
local mission_name=data.mission_name
local reward=data.reward
local mission_id = add_mission_log(nil,force,mission_name,reward,nil, nil,nil,data)
data.rocket_launch_request = rocket_launch_request
global.force_control[force.name].rocket_launch_missions[mission_id] = data
end



function create_rocket_delivery_requests(force)
local base_event = {force=force, mission_category='space_rockets', mission_name='M_space_rockets'}
local req_list = table.deepcopy(global.MSI_cargo_list)

local mi=settings.global["msi_cargo_request_min"].value
local ma=settings.global["msi_cargo_request_max"].value
if ma<mi then mi=ma end

local recipes = table.deepcopy(global.msi_double_recipes)

for x=1,5 do 
	local i = math.random (#req_list)
	local item = req_list[i]
	table.remove (req_list,i)
	local qt= math.random(mi,ma)
	local event = table.deepcopy(base_event)
	local reward
	if x<5 then reward = { {type = 'unlock_recipe', recipes = {recipes[x]}}, {type = 'team_XP', XP = Get_XP_ratio(500)}}
		else reward = { {type = 'unlock_recipe', recipes = {recipes[5],recipes[6],recipes[7]}}, {type = 'team_XP', XP = Get_XP_ratio(500)}} end
	event.reward=reward
	local rocket_launch_request = {items_required={name=item,count=qt}, count_force_launched=true}
	create_rocket_request_mission(event, rocket_launch_request)
	force.recipes[item].enabled=true
	end
end



function on_Place_Chosen(tab)
local surface  = tab.surface
local position = tab.position
local extraInfo= tab.extraInfo

if extraInfo.mission_name=='M_unique_rocket_silo' then
	local force = extraInfo.force
	global.force_control[force.name].rocket_silo_sites = {{surface=surface, surface_name=surface.name, position=position}}
	local cam_text = {'Mining-Space-Industries-II.menu_mission_name_M_unique_rocket_silo'}
	local camera = {surface_name=surface.name, surface=surface,position=position,icon='[img=item/rocket-silo]', text=cam_text}
	extraInfo.choosen_tech=nil
	add_mission_log(nil,force,extraInfo.mission_name,nil,nil, {camera},nil,extraInfo,true)
	
	
	elseif extraInfo.mission_name=='M_space_rockets' then
		local choosen_tech = extraInfo.choosen_tech
		local force = extraInfo.force
		--global.force_control[force.name].rocket_silo_sites = global.force_control[force.name].rocket_silo_sites or {}
		table.insert (global.force_control[force.name].rocket_silo_sites,{surface=surface,surface_name=surface.name, position=position})
		local cam_text = {'Mining-Space-Industries-II.menu_mission_name_M_space_rockets'}
		local camera = {surface=surface,surface_name=surface.name, position=position,icon='[img=item/rocket-silo]', text=cam_text}
		local reward = {{type = 'unlock_tech', techs = {extraInfo.choosen_tech}}, {type = 'team_XP', XP = Get_XP_ratio(1000)}}
		local mission_id = add_mission_log(nil,force,extraInfo.mission_name,reward,nil, {camera},nil,extraInfo)
		local item_req = global.mission_techs_space_rockets_items[choosen_tech]
		local count = game.item_prototypes[item_req].stack_size
		extraInfo.rocket_launch_request = {surface_name=surface.name, position=position, items_required={name=item_req,count=count}}
		global.force_control[force.name].rocket_launch_missions[mission_id] = extraInfo
	end

end




function Create_Mission_Entity(placing_data)

	local function try_again(try,trying_chunk,placing_data)
		try=try+1
		if try > 30 then try=0 end
		placing_data.try=try
		placing_data.trying_chunk=trying_chunk
		table.insert(global.wait_for_event,{event='placing_entity_on_map', data_table=placing_data})			
	end

if not placing_data.try then placing_data.try=0 end
if not placing_data.from_position  then placing_data.from_position={x=0,y=0} end
local try  = placing_data.try
local trying_chunk = placing_data.trying_chunk
local surface  = placing_data.surface
local entity_name= placing_data.entity_name
local force=placing_data.force
local ungenerated_chunk=placing_data.ungenerated_chunk
local chunk_distance=placing_data.chunk_distance
local extraInfo=placing_data.extraInfo
local from_position=placing_data.from_position 
local avoid_near=placing_data.avoid_near 
local avoid_near_tile=placing_data.avoid_near_tile 



if surface and surface.valid then
if try==0 then 
	local last_gen
	if ungenerated_chunk then 
		local min_chunk_dist,max_chunk_dist
		if game.active_mods['space-exploration'] then 
			min_chunk_dist=chunk_distance/2
			max_chunk_dist=chunk_distance 
			end 
		last_gen, chunk = FindMapEdges(surface, from_position, min_chunk_dist, max_chunk_dist)
		chunk = chunk or last_gen
		else chunk = FindRandomDistantChunk(surface, from_position, chunk_distance) end
	try=1
	trying_chunk = chunk
	end

if not (trying_chunk and surface.is_chunk_generated(trying_chunk)) then 
	if trying_chunk then 
		surface.request_to_generate_chunks({x=32*trying_chunk.x+15,y=32*trying_chunk.y+15}, 2)
		surface.force_generate_chunk_requests()
		end
	try_again(try,trying_chunk,placing_data)
	return
	end

-- at this point the chunk is generated
local position = get_random_pos_near( {x=32*trying_chunk.x+15,y=32*trying_chunk.y+15},14) 

if entity_name=='a_place_with_land' then 
	position = surface.find_non_colliding_position('nuclear-reactor', position, 0, 1)
	else
	position = surface.find_non_colliding_position(entity_name, position, 0, 1)
	end

if avoid_near and position then 
	local obst=surface.find_entities_filtered{name=avoid_near,position=position, radius=15, limit=1}
	if #obst>0 then position=nil end
	end
if avoid_near_tile and position then 
	local obst=surface.find_tiles_filtered{name=avoid_near_tile,position=position, radius=15, limit=1}
	if #obst>0 then position=nil end
	end


if not position then   -- this chunk is not good. Start over
	try_again(30,nil,placing_data)
	return
	end

if entity_name=='a_place_with_land' then
	on_Place_Chosen({surface=surface,position=position,extraInfo=extraInfo})
	else
	local Ent = surface.create_entity{name =entity_name, position=position, force= force, spawn_decorations=true}
	on_Entity_Mission_Created({entity=Ent,extraInfo=extraInfo})
	end	
end
end







function check_for_available_missions(always)
local cat    =  get_mission_categories()
local limit  = 2

--cycle all forces
for F=1, #global.player_forces do
	local force_name = global.player_forces[F].force
	local home_name  = global.player_forces[F].surface
	if game.forces[force_name] and #game.forces[force_name].connected_players>0 then
		
		local force = game.forces[force_name] 
		local initial_pack = 'automation-science-pack'
		if force.recipes['basic-tech-card'] then initial_pack = 'basic-tech-card' end
		if force.recipes[initial_pack].enabled or always then
			-- check the companion droid
			local companion_droid = global.force_control[force_name].companions.droid.entity
			local companion_synthetic = global.force_control[force_name].companions.synthetic.entity
			if not (companion_droid and companion_droid.valid) then spawn_companion_for_force(force, home_name, 'droid') end 
			if force.technologies['engine'].researched and 
				(not (companion_synthetic and companion_synthetic.valid)) then
				local synthetic_corpse = global.force_control[force_name].companions.synthetic.corpse
				if not (synthetic_corpse and synthetic_corpse.valid) then 
					if not global.force_control[force.name].companions.synthetic.disabled then 
						spawn_companion_for_force(force, home_name, 'synthetic') 
						end
					end
				end
	   
			local spawned_missions = global.force_control[force_name].spawned_missions  -- 
			local available = {}
			for c=1,#cat do 
				global.force_control[force_name].spawned_missions[cat[c]] = global.force_control[force_name].spawned_missions[cat[c]] or {} 
				local count = #global.force_control[force_name].spawned_missions[cat[c]]
				if count < limit then available[cat[c]]=count end
				end
			local choosen_cat, choosen_tech
			for k,v in Sort_a_Table(available, function(t,a,b) return t[b] > t[a] end) do
				choosen_tech = get_mission_tech_available(force, global.mission_techs[k], global.force_control[force_name].spawned_missions[k] ) 
				if choosen_tech then 
					choosen_cat=k
					break
					end
				end
			
			if choosen_cat then
				CreateNewMissionEvent(force,home_name,choosen_cat,choosen_tech) 
				end
			end
		end
	end
end






function check_mission_rocket_launched(force,silo,rocket,mission_id, mission_info)
local surface  = silo.surface or rocket.surface
local position 
if silo.valid then position = silo.position else position = rocket.position end
local rocket_launch_request = mission_info.rocket_launch_request

local condition = true

if rocket_launch_request.surface_name then 
	local surface_name = rocket_launch_request.surface_name
	if not game.surfaces[surface_name] then condition = false 
		else
		if game.surfaces[surface_name]~=surface then condition = false 
			else 
				if rocket_launch_request.position then 
					if distance(rocket_launch_request.position,position)>32 then condition = false end
					end
			end
		end
	end

if rocket_launch_request.items_required then 
	local item = rocket_launch_request.items_required.name
	local count= rocket_launch_request.items_required.count
	local force_launched = force.get_item_launched(item)

	if rocket_launch_request.count_force_launched then 
		if force_launched<count then condition = false end
		elseif rocket.get_item_count(item)<count then condition = false 
		end
	end

if condition then
	if silo.valid then mission_info.silo=silo end 
	advance_mission_control(mission_info.mission_name,mission_info)
	if global.force_control[force.name].rocket_launch_missions[mission_id] then
		global.force_control[force.name].rocket_launch_missions[mission_id].accomplished = true
		end
	end
end
