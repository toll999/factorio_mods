

function Entity_Speak(entity,text,seconds)
global.entity_speech=global.entity_speech or {}

if global.entity_speech[entity] then 
	global.entity_speech[entity].bubble.destroy()
	global.entity_speech[entity] = nil
	end

  local bubble = entity.surface.create_entity({
    name="compi-speech-bubble",
    text=text,
    position={0,0},
    source=entity })
  
	global.entity_speech[entity] = {}
	global.entity_speech[entity].bubble=bubble
	if seconds and seconds>0 then global.entity_speech[entity].tick=game.tick+seconds*60 end
end


script.on_nth_tick(64, function (event)
if global.entity_speech then
for k, entity_speech in pairs (global.entity_speech) do
	local bubble = entity_speech.bubble
	local tick   = entity_speech.tick
	if tick and game.tick >= tick then 
		bubble.destroy()
		entity_speech=nil
		end
	end
end
end)