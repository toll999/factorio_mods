path = '__Mining-Space-Industries-II__/'
util = require("util")
colors = require("colors")
sounds = require("__base__/prototypes/entity/sounds.lua")
MSI_cargo_list = require(path.."rocket_delivery_list.lua")


function getLoot()
local Loot=	{ 
	{ item = "msi_portable_technology_data", probability = 0.2, count_min = 1, count_max = 1 },	
	{ item = "productivity-module-2",  count_min = 1,  count_max = 3,  probability = 0.50 }	,
	{ item = "productivity-module-3",  count_min = 1,  count_max = 2,  probability = 0.25 }	,
	{ item = "effectivity-module-2",  count_min = 1,  count_max = 3,  probability = 0.50 }	,
	{ item = "effectivity-module-3",  count_min = 1,  count_max = 2,  probability = 0.25 }	,
	{ item = "speed-module-2",  count_min = 1,  count_max = 3,  probability = 0.50 }	,
	{ item = "speed-module-3",  count_min = 1,  count_max = 2,  probability = 0.25 }	,
	}
if data.raw.capsule['rpg_level_up_potion'] then
	table.insert ( Loot , {item = "rpg_level_up_potion",  count_min = 1,  count_max = 2,  probability = 0.20})
	table.insert ( Loot , {item = "rpg_amnesia_potion",  count_min = 1,  count_max = 1,  probability = 0.15})
	table.insert ( Loot , {item = "rpg_small_xp_potion",  count_min = 1,  count_max = 3,  probability = 0.50})
	table.insert ( Loot , {item = "rpg_big_xp_potion",  count_min = 1,  count_max = 2,  probability = 0.20})
	end
if data.raw.capsule['rpg_speed_potion'] then
	table.insert ( Loot , {item = "rpg_speed_potion",  count_min = 1,  count_max = 2,  probability = 0.20})
	table.insert ( Loot , {item = "rpg_crafting_potion",  count_min = 1,  count_max = 2,  probability = 0.20})
	end
return Loot	
end


require "unit_functions"
require("utils")

require "prototypes.entities"
require "prototypes.droids"
require "prototypes.technology"
require "prototypes.projectiles"
require "prototypes.projectiles2"
require "prototypes.sprite"
require "prototypes.sounds"
require "prototypes.bosses"
require "prototypes.bosses_armoured"
require "prototypes.bosses_worms"
require "prototypes.fake_humans"
require "prototypes.item"
require "prototypes.recipes"
require "prototypes.protomolecule"
require "prototypes.rocket_delivery"
require "prototypes.explosion"



--[[require "prototypes.brutals"
require "prototypes.bosses"
require "prototypes.turrets"
require "prototypes.bosses_armoured"

]]


-- informatron images
informatron_make_image("img_msi_welcome", path .. "graphics/sprite/msi_welcome.png", 328, 100) 



data:extend(
{
  {
    type = "custom-input",
    name = "msi-special-key",
    key_sequence = "CONTROL + E",
  },
 })