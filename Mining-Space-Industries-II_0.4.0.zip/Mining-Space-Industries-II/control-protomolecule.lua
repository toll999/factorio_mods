local proto_color = {r=0.5,g=0.7,b=1}


function create_protomolecule_base(entity, radius, defenses) --100 , 120
global.protomolecule_spawned_bases = global.protomolecule_spawned_bases + 1
table.insert(global.monitored_entity,{entity=entity,event="protomolecule_activity",tab_event={progress=0}})

entity.surface.pollute(entity.position,1000)

local position = entity.position
local surface=entity.surface
surface.request_to_generate_chunks(position, 3)
surface.force_generate_chunk_requests()

clear_and_fill_area(surface, position, radius, nil, 'cyan-refined-concrete')

surface.create_entity{name = 'msi_hidden_pole', position=position, force=entity.force}
surface.create_entity{name = 'hidden-electric-energy-interface', position=position, force=entity.force}

local area = GetAreaAroundPos(position, radius-10)
local extras = {'msi_protomolecule_spawner'}
if game.entity_prototypes['sw-electric-stick-turret-2'] then table.insert(extras,'sw-electric-stick-turret-2') end
if game.entity_prototypes['sw-electric-turret-2'] then table.insert(extras,'sw-electric-turret-2') end
create_special_defense_things_on_area(surface,area,entity.force,defenses + global.settings.difficulty_level*20,extras)
		
local boss = "msi_protomolecule_infected_boss_electric_" .. (5+global.settings.difficulty_level)
local p = surface.find_non_colliding_position(boss, position, 0, 1)
local boss_e = surface.create_entity{name = boss, position=p, force=entity.force}

local boss = "msi_protomolecule_infected_boss_laser_".. (5+global.settings.difficulty_level)
local p = surface.find_non_colliding_position(boss, position, 0, 1)
local boss_e = surface.create_entity{name = boss, position=p, force=entity.force}
		
local boss = "msi_protomolecule_infected_boss_machine_gunner_" .. (5+global.settings.difficulty_level)
local p = surface.find_non_colliding_position(boss, position, 0, 1)
local boss_e = surface.create_entity{name = boss, position=p, force=entity.force}

if game.active_mods['space-exploration'] then 
	local ship = surface.create_entity{name = 'big-ship-wreck-3', position=position, force=game.forces.player}
	for d=1,global.settings.difficulty_level do 
		remote.call("space-exploration", "begin_solar_flare", {zone_name = global.se_universe.by_name[surface.name].name, targeting="basic"}) 
		end
	end
 
end



function protomolecule_spawns_nearby(protomolecule_spawner,full)
local surface = protomolecule_spawner.surface
local position = protomolecule_spawner.position
local prev = surface.find_entities_filtered{name='msi_protomolecule_spawner',position=position, radius=180}
local qt = (25 + (global.settings.difficulty_level-1)*10) - #prev
if qt>2 then 
	if not full then qt=math.random(qt) end
	for x=1,qt do 
		local p = get_random_pos_near(position,150)
		local area = GetAreaAroundPos(p, 15)
		RemoveAliensInArea(surface, area)
		FillWaterWith(surface,area,{surface.get_tile(protomolecule_spawner.position.x, protomolecule_spawner.position.y).name})
		p = surface.find_non_colliding_position('msi_protomolecule_spawner', p, 0, 1)
		local spawner = surface.create_entity{name='msi_protomolecule_spawner', position=p, force=game.forces.protomolecule,spawn_decorations=true}
		table.insert(global.monitored_entity,{entity=spawner,event="protomolecule_activity",tab_event={progress=0}})
		create_special_defense_things_on_area(surface,area,game.forces.protomolecule, math.random(2) + global.settings.difficulty_level)
		local shoot = surface.create_entity{name ='cb-cluster-cold-projectile-big', target_position=spawner.position, position=position, source_position =position, force= game.forces.protomolecule, speed=5}
		end
	end
end


function protomolecule_activity(entity,tab_event) 
local surface=entity.surface

if tab_event.progress>-1 then 

	if entity.name=='msi_protomolecule_spawner_boss' then 
		
		if game.tick%3600==0 then  -- enemy nearby -- pollute -- Minuto
			if entity.surface.find_nearest_enemy{position=entity.position, max_distance=700, force=entity.force} then 
				entity.surface.pollute(entity.position,6000)
				for x=1,3 do entity.surface.pollute(get_random_pos_near(entity.position,80),2500) end
				end
			end
		
		tab_event.progress = tab_event.progress+1
		if tab_event.progress > 60*(22 - global.settings.difficulty_level*2) then 
			local position=entity.position
			tab_event.progress=0
			
			
			-- fill all artys
			local artys = surface.find_entities_filtered{name="msi_protomolecule_artillery", force='protomolecule'}
			for _,arty in pairs(artys) do 
				arty.insert({name='artillery-shell', count=15}) 
				end


			local opt = math.random(2)
			if opt==1 then 
				local silo = surface.find_entities_filtered{name={'rocket-silo','rsc-silo-stage1','rsc-silo-stage2','rsc-silo-stage3','rsc-silo-stage4','rsc-silo-stage5','rsc-silo-stage6'},
								force=entity.force, limit=1, position=position, radius=50}
				if #silo==0 then 
					local p = surface.find_non_colliding_position('rsc-silo-stage1', position, 0, 1)
					if p then 
						local silo=surface.create_entity{name='rsc-silo-stage1', position=p, force=entity.force, raise_built=true} 
						table.insert(global.monitored_entity,{entity=silo,event="protomolecule_activity",tab_event={progress=0}})
						end
					end
				elseif opt==2 then 
				local spider = surface.find_entities_filtered{name='spidertron',force=entity.force, position=position, radius=200}
				if #spider<2+global.settings.difficulty_level then 				
					local p = surface.find_non_colliding_position('spidertron', position, 0, 1)
					if p then 
						local spider=surface.create_entity{name='spidertron', position=p, force=entity.force} 
						spider.color = proto_color
						spider.vehicle_automatic_targeting_parameters = {auto_target_without_gunner = true}
						spider.insert{name='rocket',count=400}
						table.insert(global.monitored_entity,{entity=spider,event="protomolecule_activity",tab_event={progress=0,spawn_pos=position}})
						end				
					end
				end
			end
		
		elseif string.sub(entity.name,1,8)=='rsc-silo' and math.random(3)==1 then entity.products_finished = entity.products_finished +1 
		
		elseif entity.name=="rocket-silo" then
			entity.energy = 100000000
			if not entity.launch_rocket() then
				if math.random(3)==1 then entity.rocket_parts=entity.rocket_parts+1 end
				end	
		
		
		elseif entity.name=="spidertron" then
			local spawn_pos = tab_event.spawn_pos
			local position=entity.position
			tab_event.progress=tab_event.progress + 1 
			if tab_event.progress>30 then 
				tab_event.progress=0
				if entity.get_item_count('rocket')<400 then entity.insert{name='rocket',count=200} end
				entity.autopilot_destination = get_random_pos_near(spawn_pos,80)
				end
		
		
		elseif entity.type=="unit-spawner" then
			entity.surface.pollute(entity.position,7) 
			if tab_event.extra_activity then 
				tab_event.progress = tab_event.progress+0.6
				if tab_event.progress>=100 then
					tab_event.progress = 0
					if tab_event.extra_activity == 'spawns_nearby' then 
						protomolecule_spawns_nearby(entity)
						end
					end
			end
		end
	
	end
end



function on_protomolecule_rocket_launched(base_surface,rocket, skip_home, on_nauvis)

local function create_rocket_cam()
	if rocket and rocket.valid then 
		local cam_text = get_localized_name(rocket.name)
		CreateCameraForConnectedPlayers(rocket,rocket.surface,cam_text)
		game.print({'labels.protomolecule-rocket-launch', get_gps_tag(rocket.position,rocket.surface)} ,colors.yellow)
		end
	end


local surface_name=base_surface.name 
local surface = base_surface

local base_limit = 1
if game.active_mods['space-exploration'] then base_limit = 3 end
base_limit = base_limit + global.settings.difficulty_level


if global.protomolecule_spawned_bases < base_limit  then 
	if game.active_mods['space-exploration'] and (not on_nauvis) then 
	local forces={}
	for F=1, #global.player_forces do
		local force_name = global.player_forces[F].force
		table.insert (forces,game.forces[force_name])
		end
	surface_name = get_se_zone_for_mission(forces,{type='enemy',value=1, max=10},skip_home) or surface_name
	surface=game.surfaces[surface_name]
	if not (surface and surface.valid) then 
		local pl
		for p,player in pairs (game.connected_players) do
			if player and player.valid then pl=player break end
			end
		if pl then 
			local pos = pl.position
			local sur = pl.surface
			remote.call("space-exploration", "teleport_to_zone", {zone_name = surface_name, player=pl})   -- create surface on space exploration 
			pl.teleport(pos, sur)
			surface = game.surfaces[surface_name]
			end	
		end
	end

	create_rocket_cam()
	local force=game.forces.player
	local placing_data={surface=surface,
			entity_name='msi_protomolecule_spawner_boss',
			force=game.forces.protomolecule,
			from_position={x=0,y=0}, --force.get_spawn_position(surface),
			ungenerated_chunk=true,
			chunk_distance=Get_Chunk_Distance_For_Mission(surface,force),
			extraInfo={}}
	table.insert(global.wait_for_event,{event='placing_entity_on_map',tick=game.tick+60*6, data_table=placing_data})		
	game.forces.protomolecule.evolution_factor = math.min(1,game.forces.protomolecule.evolution_factor + 0.02)
	
	elseif game.forces.protomolecule.artillery_range_modifier<1 + (global.settings.difficulty_level-1/2) then 
		create_rocket_cam()
		protomolecule_add_damage_bonuses(global.settings.difficulty_level/10)
		game.forces.protomolecule.artillery_range_modifier= game.forces.protomolecule.artillery_range_modifier+0.1
		game.print({'labels.protomolecule-stronger'}, colors.yellow)
	
	else
		-- add nuclear attack ? other ideas to 
	end														

end


function protomolecule_add_damage_bonuses(v)
local p = game.forces.protomolecule

for name,proto in pairs (game.ammo_category_prototypes) do
	p.set_ammo_damage_modifier(name, p.get_ammo_damage_modifier(name) + v)
	p.set_gun_speed_modifier(name, p.get_gun_speed_modifier(name) + v)
    end

p.set_turret_attack_modifier('gun-turret', p.get_turret_attack_modifier('gun-turret') + v)
p.set_turret_attack_modifier('laser-turret', p.get_turret_attack_modifier('laser-turret') +v )
p.set_turret_attack_modifier('artillery-turret', p.get_turret_attack_modifier('artillery-turret') + v)

if game.entity_prototypes['sw-electric-stick-turret-2'] then  p.set_turret_attack_modifier('sw-electric-stick-turret-2', p.get_turret_attack_modifier('sw-electric-stick-turret-2') + v) end
if game.entity_prototypes['sw-electric-turret-2'] then  p.set_turret_attack_modifier('sw-electric-stick-turret-2', p.get_turret_attack_modifier('sw-electric-turret-2') + v) end
end