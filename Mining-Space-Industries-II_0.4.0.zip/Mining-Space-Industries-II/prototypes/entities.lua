

local broken_lab = table.deepcopy(data.raw['simple-entity']['crash-site-lab-broken'])
broken_lab.type = "container"
broken_lab.max_health = 1000
broken_lab.inventory_size = 200
broken_lab.name="msi_broken_lab"
broken_lab.localised_name = {"entity-name.crash-site-lab-broken"}
broken_lab.localised_description = {"entity-description.crash-site-lab-broken"}
broken_lab.picture = broken_lab.animations
broken_lab.order = "d[remnants]-d[ship-wreck]-a[big]-c"
broken_lab.resistances ={{type = "fire", percent = 90},{type = "physical", percent = 40},{type = "acid", percent = 40}}


local generator = table.deepcopy(data.raw['electric-energy-interface']['crash-site-generator'])
generator.name="crashed-generator"
generator.localised_name = {"entity-name.crash-site-generator"}
generator.localised_description = {"entity-description.crash-site-generator"}
generator.energy_production = "4MW"
generator.order ='g'
generator.dying_explosion = "small-atomic-explosion"
generator.energy_source =
    {
      type = "electric",
      buffer_capacity = "50MW",
      usage_priority = "tertiary",
      input_flow_limit = "0kW",
      output_flow_limit = "10MW"
    }


local mission_car = table.deepcopy(data.raw.car.car)
mission_car.name="msi_mission_car"
mission_car.consumption = "9kW"
mission_car.breaking_power = "5kW"
mission_car.terrain_friction_modifier = 0.01
--mission_car.weight = 10000
mission_car.max_health = 250
mission_car.order = "d[remnants]-d[ship-wreck]-a[big]-c"
mission_car.burner.effectivity = 0.5
mission_car.has_belt_immunity = true
mission_car.dying_explosion = "small-atomic-explosion"


local terminal = table.deepcopy(data.raw['container']['steel-chest'])
terminal.name = 'msi_mission_terminal'
terminal.icon = path.."graphics/icon/terminal_icon.png"
terminal.icon_size = 64
terminal.icon_mipmaps = 4
terminal.icons = nil
terminal.order ='zz'
terminal.max_health = 1000
terminal.collision_box = data.raw['roboport']['roboport'].collision_box
terminal.selection_box = data.raw['roboport']['roboport'].selection_box
terminal.working_sound = data.raw['roboport']['roboport'].working_sound
terminal.dying_explosion = "small-atomic-explosion"
terminal.corpse = data.raw['roboport']['roboport'].corpse
terminal.picture.layers = 
        {{
          filename = path .. "graphics/entity/msi_terminal.png",
          width = 111,
          height = 135,
		      scale = 1,
          hr_version = {
            filename = path .. "graphics/entity/hr_msi_terminal.png",
            width = 222,
            height = 270,
            scale = 0.5,
          }
		  },
        }
terminal.fast_replaceable_group = nil
terminal.next_upgrade = nil




local broken_machine = table.deepcopy(data.raw['simple-entity']['crash-site-assembling-machine-1-broken'])
broken_machine.type = "container"
broken_machine.inventory_size = 200
broken_machine.max_health = 1000
broken_machine.name="msi_broken_machine"
broken_machine.localised_name = {"entity-name.crash-site-assembling-machine-1-broken"}
broken_machine.picture = broken_machine.animations
broken_machine.order = "d[remnants]-d[ship-wreck]-a[big]-c"
broken_machine.resistances ={{type = "fire", percent = 90},{type = "physical", percent = 40},{type = "acid", percent = 40}}



local repaired_lab = table.deepcopy(data.raw.lab['crash-site-lab-repaired'])
repaired_lab.integration_patch = nil
repaired_lab.name="wpe_repaired_lab"
repaired_lab.localised_name = {"entity-name.crash-site-lab-repaired"}
repaired_lab.localised_description = {"entity-description.crash-site-lab-repaired"}
repaired_lab.order = "d[remnants]-d[ship-wreck]-a[big]-c"




local function add_craft_machine(level)
local repaired_machine = table.deepcopy(data.raw["assembling-machine"]['crash-site-assembling-machine-1-repaired'])
repaired_machine.name="msi_repaired_machine-"..level
repaired_machine.max_health = 1000
repaired_machine.localised_name = {"entity-name.crash-site-assembling-machine-1-repaired"}
repaired_machine.localised_description = {"entity-description.crash-site-assembling-machine-1-repaired"}
repaired_machine.order = "d[remnants]-d[ship-wreck]-a[big]-c"
repaired_machine.fixed_recipe = "msi_portable_technology_data"
repaired_machine.energy_usage = tostring(3000*level) .. "kW"
repaired_machine.dying_explosion = "big-artillery-explosion"
repaired_machine.resistances ={{type = "fire", percent = 90},{type = "physical", percent = 40},{type = "acid", percent = 40}}
data:extend({repaired_machine})
end
for level=1,10 do add_craft_machine(level) end









-- Charge Acc / generator
local p_cs = '__factorio-crash-site__'
local charge_anim = {
      layers =
      {
        {
          filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator.png",
          width = 142,
          height= 128,
          frame_count = 5,
          line_length = 5,
          repeat_count = 16,
        --  shift = util.by_pixel(-10, -24),
          animation_speed = crash_site_generator_animation_speed,
          hr_version = {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator.png",
            width = 286,
            height= 252,
            frame_count = 5,
            line_length = 5,
            repeat_count = 16,
            animation_speed = crash_site_generator_animation_speed,
           -- shift = util.by_pixel(-11, -23),
            scale = 0.5
          }
        },
        {
          filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator-beams.png",
          width = 48,
          height= 116,
          frame_count = 16,
          line_length = 4,
          repeat_count = 5,
        --  shift = util.by_pixel(24, -30),
          animation_speed = crash_site_generator_animation_speed,
          hr_version = {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator-beams.png",
            width = 224,
            height= 232,
            frame_count = 16,
            line_length = 4,
            repeat_count = 5,
            animation_speed = crash_site_generator_animation_speed,
         --   shift = util.by_pixel(-8, -30),
            scale = 0.5
          }
        },
        {
          filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator-shadow.png",
          width = 236,
          height= 78,
          frame_count = 1,
          line_length = 1,
          repeat_count = 80,
          shift = util.by_pixel(26, 4),
          draw_as_shadow = true,
          animation_speed = crash_site_generator_animation_speed,
          hr_version = {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator-shadow.png",
            width = 474,
            height= 152,
            frame_count = 1,
            line_length = 1,
            repeat_count = 80,
            draw_as_shadow = true,
            shift = util.by_pixel(25, 5),
            animation_speed = crash_site_generator_animation_speed,
            scale = 0.5
          }
        },
      }
    }
	
	
	
function generator_picture(tint, repeat_count)
  return
  {
    layers =
    {
      {
          filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator.png",
          width = 142,
          height= 128,
          frame_count = 1,
          line_length = 1,
        repeat_count = repeat_count,
    --     shift = util.by_pixel(-10, -24),
        tint = tint,
        animation_speed =crash_site_generator_animation_speed,
        hr_version =
        {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator.png",
            width = 286,
            height= 252,
            frame_count = 1,
            line_length = 1,
          repeat_count = repeat_count,
    --      shift = util.by_pixel(24, -30),
          tint = tint,
          animation_speed =crash_site_generator_animation_speed,
          scale = 0.5
        }
      },
      {
          filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator-shadow.png",
          width = 236,
          height= 78,
          frame_count = 1,
          line_length = 1,
        repeat_count = repeat_count,
        shift = util.by_pixel(26, 4),
        draw_as_shadow = true,
        hr_version =
        {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator-shadow.png",
            width = 474,
            height= 152,
            frame_count = 1,
            line_length = 1,
          repeat_count = repeat_count,
          shift = util.by_pixel(25, 5),
          draw_as_shadow = true,
          scale = 0.5
        }
      }
    }
  }
end


function add_charge_gen(level)
data:extend({
 {
    type = "accumulator",
    name = "msi_charge_generator-"..level,
	localised_name={'entity-name.msi_charge_generator'},
	localised_description={'entity-description.msi_charge_generator'},
    icon = data.raw['electric-energy-interface']['crash-site-generator'].icon,
    icon_size = data.raw['electric-energy-interface']['crash-site-generator'].icon_size,
	icon_mipmaps =data.raw['electric-energy-interface']['crash-site-generator'].icon_mipmaps,
    flags = {"placeable-neutral", "player-creation", "hidden", "not-rotatable"},
  --  minable = {mining_time = 0.1, result = "accumulator"},
    max_health = 450 + level*50,
	resistances ={{type = "fire", percent = 90},{type = "physical", percent = 30},{type = "acid", percent = 30}},
    corpse = data.raw['electric-energy-interface']['crash-site-generator'].corpse,
    collision_box = data.raw['electric-energy-interface']['crash-site-generator'].collision_box,
    selection_box = data.raw['electric-energy-interface']['crash-site-generator'].selection_box,
    allow_copy_paste = false,
    energy_source =
    {
      type = "electric",
      buffer_capacity = tostring(1000*level) .. "MJ",
      usage_priority = "tertiary",
      input_flow_limit = tostring(2000*level) .. "kW",
      output_flow_limit = "2kW"
    },
    picture = generator_picture(),
    light = {intensity = 1, size = 8, color = {r = 1.0, g = 1.0, b = 1.0}, shift = {64/64, -140/64}},
    continuous_animation = true,
    charge_animation = charge_anim,
    charge_cooldown = 30,
    charge_light = {intensity = 4, size = 20, color = {r = 1.0, g = 1.0, b = 1.0}},
    discharge_animation = charge_anim,
    discharge_cooldown = 60,
    discharge_light = {intensity = 2, size = 10, color = {r = 1.0, g = 1.0, b = 1.0}},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 1
      },
      idle_sound =
      {
        filename = "__base__/sound/accumulator-idle.ogg",
        volume = 0.4
      },
      max_sounds_per_type = 5
    },
	dying_explosion = "small-atomic-explosion",
    circuit_wire_connection_point = circuit_connector_definitions["accumulator"].points,
    circuit_connector_sprites = circuit_connector_definitions["accumulator"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance,
    default_output_signal = {type = "virtual", name = "signal-G"},
	order = "d[remnants]-d[ship-wreck]-a[big]-c",
	
  }
  
})
end
for level=1,10 do add_charge_gen(level) end




local spider = table.deepcopy(data.raw["spider-vehicle"].spidertron)
spider.name="msi_spidertron"
spider.minable = {mining_time = 1, result = "msi_spidertron"}
spider.max_health=spider.max_health +  1000
spider.guns = {"msi_spidertron-machine-gun", "msi_spidertron-cannon","msi_spidertron_flamethrower", "spidertron-rocket-launcher-4" } -- "tank-flamethrower"
spider.automatic_weapon_cycling = false
spider.icons= {{icon = path .. "graphics/icon/msi_spidertron.png", icon_size = 64, icon_mipmaps = 4}}


local hidden_pole= table.deepcopy(data.raw['electric-pole']['medium-electric-pole'])
hidden_pole.name='msi_hidden_pole'
hidden_pole.flags = {"hidden"}
hidden_pole.selectable_in_game = false
hidden_pole.collision_box = nil
hidden_pole.selection_box = nil
hidden_pole.maximum_wire_distance = 64
hidden_pole.supply_area_distance = 64
hidden_pole.fast_replaceable_group = nil
hidden_pole.next_upgrade = nil
--[[
hidden_pole.connection_points=nil

hidden_pole.pictures = {
        layers={
            {
                filename = "__core__/graphics/empty.png",
                priority = "low",
                width = 1,
                height = 1,
                direction_count = 1,
                line_length = 1,
                shift = {0, 0}
            }}}
]]


data:extend({hidden_pole,
 generator,broken_lab,mission_car,terminal,broken_machine,spider,


  {
    type = "gun",
    name = "msi_spidertron-machine-gun",
    localised_name = {"item-name.tank-machine-gun"},
    icon = path .. "graphics/icon/msi_spidertron_submachine-gun.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"hidden"},
    subgroup = "gun",
    order = "a[basic-clips]-b[tank-machine-gun]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "bullet",
      cooldown = 4,
      movement_slow_down_factor = 0.7,
      range = 35,
	  
	    projectile_center = {-0.15625, -0.07812},
      	projectile_creation_distance = 1,
		
      --projectile_creation_distance = -0.5,
      --projectile_center = {0, 0.3},
      --projectile_orientation_offset = -0.0625,
	  sound=data.raw.gun['tank-machine-gun'].attack_parameters.sound,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 0},
        creation_distance = -0.6875,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
    },
    stack_size = 1
  },
  {
    type = "gun",
    name = "msi_spidertron-cannon",
    localised_name = {"item-name.tank-cannon"},
    icon = path .. "graphics/icon/msi_spidertron_tank-cannon.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "gun",
    flags = {"hidden"},
    order = "z[spider]-c[cannon]",
    attack_parameters =
    {

      type = "projectile",
      ammo_category = "cannon-shell",
      cooldown = 90,
      movement_slow_down_factor = 0,
      	projectile_creation_distance = 1.6,
      	projectile_center = {-0.15625, -0.07812},
		
      --projectile_creation_distance = -0.5,
      --projectile_orientation_offset = -0.03125,
     -- projectile_center = {0, 0.3},
      range = 35,
	  sound=data.raw.gun['tank-cannon'].attack_parameters.sound,

    },
    stack_size = 1
  },

 {
    type = "gun",
    name = "msi_spidertron_flamethrower",
    icon = path .. "graphics/icon/msi_spidertron_flamethrower.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "gun",
	localised_name = {"item-name.flamethrower"},
	flags = {"hidden"},
    order = "z[spider]-e[flamethrower]",
    attack_parameters =
    {
      type = "stream",
      ammo_category = "flamethrower",
      cooldown = 1,
      gun_barrel_length = 0.8,
      gun_center_shift = { 0, -1 },
      range = 35,
      min_range = 6,
	  damage_modifier = 1.5,
      cyclic_sound =
      {
        begin_sound =
        {
          {
            filename = "__base__/sound/fight/flamethrower-start.ogg",
            volume = 0.7
          }
        },
        middle_sound =
        {
          {
            filename = "__base__/sound/fight/flamethrower-mid.ogg",
            volume = 0.7
          }
        },
        end_sound =
        {
          {
            filename = "__base__/sound/fight/flamethrower-end.ogg",
            volume = 0.7
          }
        }
      }
    },
    stack_size = 1
  },


  {
    type = "container",
    name = "msi-broken-generator",
    enable_inventory_bar = false,
    icon = p_cs .. "/graphics/icons/crash-site-generator.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-neutral"},
    subgroup = "wrecks",
    order = "d[remnants]-d[ship-wreck]-a[big]-c",
    map_color = {r = 0, g = 0.365, b = 0.58, a = 1},
    max_health = 1000,
    corpse = "medium-remnants",
	resistances ={{type = "fire", percent = 90},{type = "physical", percent = 30},{type = "acid", percent = 30}},
    collision_box = {{-1.5, -0.9}, {0.9, 0.9}},
    selection_box = {{-1.5, -0.9}, {0.9, 0.9}},
    inventory_size = 200,
	  dying_explosion = "small-atomic-explosion",
    integration_patch_render_layer = "decals",
    -- also 'pictures' for 4-way sprite is available, or 'animation' resp. 'animations'
    integration_patch = {
      filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator-ground.png",
      priority="high",
      width = 192,
      height = 180,
      shift = util.by_pixel(-28, -38),
      frame_count = 1,
      line_length = 1,
      hr_version =
      {
        filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator-ground.png",
        priority="high",
        width = 384,
        height = 360,
        shift = util.by_pixel(-28, -38),
        frame_count = 1,
        line_length = 1,
        scale = 0.5
      }
    },
    picture =	
        {
          filename = p_cs .. "/graphics/entity/crash-site-generator/crash-site-generator.png",
          width = 142,
          height= 128,
          frame_count = 1,
          line_length = 1,
--          repeat_count = 1,
          shift = util.by_pixel(-10, -24),
          hr_version = {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator.png",
            width = 286,
            height= 252,
            frame_count = 1,
            line_length = 1,
--            repeat_count = 1,
            shift = util.by_pixel(-11, -23),
            scale = 0.5
          }
		 }
  },



})

