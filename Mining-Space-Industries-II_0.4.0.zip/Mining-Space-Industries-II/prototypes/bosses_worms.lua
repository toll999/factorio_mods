local resistances = require(path.."prototypes/resistances")
local enemy_autoplace = require ("__base__/prototypes/entity/enemy-autoplace-utils.lua")
local boss_scale = 3.5

local Loot = getLoot()




local boss_hp_multiplier =  settings.startup["msi-enemy-hp-multiplier"].value
local boss_dmg_multiplier = settings.startup["msi-enemy-damage-multiplier"].value
local red=colors.red

data:extend(
{
 
  {
    type = "turret",
    name = "msi-worm-boss-fire-shooter",
    icon = "__base__/graphics/icons/behemoth-worm.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 500000 * boss_hp_multiplier,
    order="b-b-f",
    subgroup="enemies",
    resistances = resistances.boss_fireworm,
    healing_per_tick = 0.02,
    collision_box = {{-4, -4}, {4, 4}},
    selection_box = {{-4, -4}, {4, 4}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "msi-worm-boss-fire-shooter-corpse",
    dying_explosion = "big-artillery-explosion",
    dying_sound = sounds.worm_dying(2.0),
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(boss_scale, red),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(boss_scale, red, "forward"),
    preparing_sound = sounds.worm_standup(2),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(boss_scale, red),
    prepared_sound = sounds.worm_breath(2),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(boss_scale, red),
    prepared_alternative_sound = sounds.worm_roar_alternative(2),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(boss_scale, red),
    starting_attack_sound = sounds.worm_roars(2),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(boss_scale, red),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(boss_scale, red, "backward"),
    folding_sound = sounds.worm_fold(2),
    integration = worm_integration(boss_scale),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,
    prepare_range = range_worm_behemoth + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
	call_for_help_radius = 300,
    loot = Loot,
	build_base_evolution_requirement = 1,
--    autoplace = enemy_autoplace.enemy_worm_autoplace(10),
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = 100 * boss_dmg_multiplier,
      cooldown = 120,
      range = 80,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(boss_scale, boss_scale * scale_worm_stream),
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream
      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = "maf-cluster-fire-projectile",
            duration = 100,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
  },
 


   {
    type = "corpse",
    name = "msi-worm-boss-fire-shooter-corpse",
    icon = "__base__/graphics/icons/behemoth-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-d[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(boss_scale, red),
    ground_patch =
    {
      sheet = worm_integration(boss_scale)
    }
  },
  
  
  
  
 }
)
 
  
 