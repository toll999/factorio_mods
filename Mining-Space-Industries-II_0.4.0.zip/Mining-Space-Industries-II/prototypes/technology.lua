local lab_effects={type = "unlock-recipe",recipe = "lab"}
local first_pack="automation-science-pack"
local lab_icon = "__base__/graphics/technology/research-speed.png"
if data.raw.lab['burner-lab'] then 
	lab_effects={type = "unlock-recipe",recipe = "burner-lab"} 
--	lab_icon = data.raw.lab['burner-lab'].icon
	end
if data.raw.tool['basic-tech-card'] then first_pack="basic-tech-card" end

local space_pack = 'space-science-pack'
--if mods['space-exploration'] then space_pack = 'se-rocket-science-pack' end

local TECHPATH = path .. "graphics/technology/"

data:extend({

  {
    type = "technology",
    name = "laboratory",
    icon_size = 256,
    icon = lab_icon,
    effects =
    {
	lab_effects
    },
    prerequisites = {},
    unit =
    {
      count = 10,
      ingredients =
      {
        {first_pack, 1},
      },
      time = 10
    },
	ignore_tech_cost_multiplier= true,
    order = "a"
  },
  
  
 
    {
    type = "technology",
    name = "msi_protomolecule_scan",
    icon = TECHPATH .. "msi_protomolecule_scan_tech.png",
	  icon_size = 256, icon_mipmaps = 4,
    prerequisites = {space_pack,"atomic-bomb","msi_rocket_delivery_requests", "msi_tech_lock_cargo_delivery"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"automation-science-pack", 10},
        {"logistic-science-pack", 10},
        {"chemical-science-pack", 10},
		{"military-science-pack", 40},
		{"utility-science-pack",10},
        {"production-science-pack",10},
        {space_pack,20},
     },
      time = 60
    },
    order = "sss",
	--enabled="true",
  }, 
   

    {
    type = "technology",
    name = "msi_protomolecule_awaken",
    icon = TECHPATH .. "msi_protomolecule_awaken_tech.png",
	  icon_size = 256, icon_mipmaps = 4,
    prerequisites = {'msi_protomolecule_scan'},
    unit =
    {
      count = 400,
      ingredients =
      {
        {"automation-science-pack", 10},
        {"logistic-science-pack", 10},
        {"chemical-science-pack", 10},
		{"military-science-pack", 50},
		{"utility-science-pack",10},
        {"production-science-pack",10},
        {space_pack,20},
     },
      time = 80
    },
	ignore_tech_cost_multiplier= true,
    order = "ssza",
	enabled = false,
  }, 
   
   

    {
    type = "technology",
    name = "msi_protomolecule_antidote_bomb",
    icon = TECHPATH .. "msi_protomolecule_antidote_bomb_tech.png",
    icon_size = 256, icon_mipmaps = 4,
    prerequisites = {'msi_protomolecule_awaken'},
	  effects={{type = "unlock-recipe",recipe = "msi_protomolecule_antidote_bomb"}},
    unit =
    {
      count = 6000,
      ingredients =
      {
        {"automation-science-pack", 10},
        {"logistic-science-pack", 10},
        {"chemical-science-pack", 10},
		{"military-science-pack", 50},
		{"utility-science-pack",10},
        {"production-science-pack",10},
        {space_pack,10},
     },
      time = 80
    },
    order = "sszf",
	enabled = false,
  }, 
   
   
    {
    type = "technology",
    name = "msi_sniper_rifle",
    icon = TECHPATH .."msi_sniper_rifle_tech.png",
    icon_size = 256, icon_mipmaps = 4,
    prerequisites = {'msi_protomolecule_awaken'},
	effects={{type = "unlock-recipe",recipe = "msi_sniper_rifle"}},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"automation-science-pack", 10},
        {"logistic-science-pack", 10},
        {"chemical-science-pack", 10},
		{"military-science-pack", 20},
		{"utility-science-pack",10},
        {"production-science-pack",10},
        {space_pack,20},
     },
      time = 100
    },
    order = "sszb",
	enabled = true,
  },    



    {
    type = "technology",
    name = "msi_sniper_fire_ammo",
    icon = TECHPATH .. "msi_sniper_fire_ammo_tech.png",
    icon_size = 256, icon_mipmaps = 4,
    prerequisites = {'msi_sniper_rifle'},
	effects={{type = "unlock-recipe",recipe = "msi_sniper_fire_ammo"}},
    unit =
    {
      count = 400,
      ingredients =
      {
        {"automation-science-pack", 10},
        {"logistic-science-pack", 10},
        {"chemical-science-pack", 10},
		{"military-science-pack", 20},
		{"utility-science-pack",10},
        {"production-science-pack",10},
        {space_pack,20},
     },
      time = 100
    },
    order = "sszc",
	enabled="true",
  },  


  {
    type = "technology",
    name = "msi_spidertron",
    icon = TECHPATH .. "msi_spidertron_tech.png",
    icon_size = 256, icon_mipmaps = 4,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "msi_spidertron"
      },
    },
    prerequisites = {"spidertron"},
    unit =
    {
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"military-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
		{space_pack, 1}
      },
      time = 30,
      count = 2500
    },
    order = "d-e-g"
  },   
   
   
    {
		type = "technology",
		name = "msi_tech_lock_satellites",
		icon = TECHPATH .. "msi_tech_lock_satellites_tech.png",
		icon_size = 256, icon_mipmaps = 4,
		localised_name = {'labels.locked-tech'},
		localised_description = {'labels.locked-tech-desc'},
		prerequisites = {"rocket-silo"},
		unit = data.raw.technology["rocket-silo"].unit,
		order = data.raw.technology["rocket-silo"].order .. 'u',
		enabled = false,
		visible_when_disabled = true,
	},

   
    {
		type = "technology",
		name = "msi_tech_lock_cargo_delivery",
		icon = TECHPATH .. "msi_tech_lock_cargo_delivery_tech.png",
		icon_size = 256, icon_mipmaps = 4,
		localised_name = {'labels.locked-tech'},
		localised_description = {'labels.locked-tech-desc'},
		prerequisites = {"msi_rocket_delivery_requests"},
		unit = data.raw.technology["rocket-silo"].unit,
		order = data.raw.technology["rocket-silo"].order .. 'w',
		enabled = false,
		visible_when_disabled = true,
	},
 
    {
		type = "technology",
		name = "msi_rocket_delivery_requests",
    icon = TECHPATH .. "msi_rocket_delivery_requests_tech.png",
    icon_size = 256, icon_mipmaps = 4,
		unit = data.raw.technology["rocket-silo"].unit,
		order = data.raw.technology["rocket-silo"].order .. 'z',
		enabled = true,
		prerequisites = {"msi_tech_lock_satellites"},
		effects = {{type = "unlock-recipe",recipe = "msi_container"}},
	},
  
})

if mods['space-exploration'] then
	--table.insert (data.raw.technology.msi_protomolecule_scan.prerequisites,"se-spaceship")
	--table.insert (data.raw.technology.msi_protomolecule_scan.prerequisites,"se-biological-science-pack-1")
	--add_new_science_pack('msi_protomolecule_scan', "se-biological-science-pack-1", 1)
	
	--table.insert (data.raw.technology.msi_protomolecule_scan.prerequisites,"se-biological-science-pack-3")
	--add_new_science_pack('msi_protomolecule_scan', "se-biological-science-pack-3", 1)
	
	table.insert (data.raw.technology['se-biological-science-pack-2'].prerequisites,"msi_rocket_delivery_requests")
	table.insert (data.raw.technology['se-material-science-pack-2'].prerequisites,"msi_rocket_delivery_requests")
	table.insert (data.raw.technology['se-astronomic-science-pack-2'].prerequisites,"msi_rocket_delivery_requests")
	table.insert (data.raw.technology['se-energy-science-pack-2'].prerequisites,"msi_rocket_delivery_requests")
	
	table.insert (data.raw.technology['se-biological-science-pack-2'].prerequisites,"msi_tech_lock_cargo_delivery")
	table.insert (data.raw.technology['se-material-science-pack-2'].prerequisites,"msi_tech_lock_cargo_delivery")
	table.insert (data.raw.technology['se-astronomic-science-pack-2'].prerequisites,"msi_tech_lock_cargo_delivery")
	table.insert (data.raw.technology['se-energy-science-pack-2'].prerequisites,"msi_tech_lock_cargo_delivery")

	table.insert (data.raw.technology['se-biological-science-pack-3'].prerequisites,"msi_protomolecule_scan")
	table.insert (data.raw.technology['se-material-science-pack-3'].prerequisites,"msi_protomolecule_scan")
	table.insert (data.raw.technology['se-astronomic-science-pack-3'].prerequisites,"msi_protomolecule_scan")
	table.insert (data.raw.technology['se-energy-science-pack-3'].prerequisites,"msi_protomolecule_scan")
	
	table.insert (data.raw.technology['se-biological-science-pack-3'].prerequisites,"msi_protomolecule_awaken")
	table.insert (data.raw.technology['se-material-science-pack-3'].prerequisites,"msi_protomolecule_awaken")
	table.insert (data.raw.technology['se-astronomic-science-pack-3'].prerequisites,"msi_protomolecule_awaken")
	table.insert (data.raw.technology['se-energy-science-pack-3'].prerequisites,"msi_protomolecule_awaken")

	add_technology_prerequisite("msi_rocket_delivery_requests", "se-processing-holmium")
	add_technology_prerequisite("msi_rocket_delivery_requests", "se-processing-beryllium")
	add_technology_prerequisite("msi_rocket_delivery_requests", "se-processing-iridium")
	add_technology_prerequisite("msi_rocket_delivery_requests", "se-processing-vitamelange")	
	end

local techPacks={"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack",
	"production-science-pack","utility-science-pack",space_pack}

local function get_base_tech(L, base_icon) 
return {type="technology",upgrade=L>1,order="a"..L, level=L, icons={
	base_icon,
	{icon="__base__/graphics/icons/signal/signal_".. L ..".png",icon_size=64,priority="medium",shift={80,80}},
}}
end

for T=1, 6 do 
	local tp = T+1
	local packs = {}
	for p=1,tp do table.insert(packs,{techPacks[p],1}) end
	local prerequisites = {}
	local tech = get_base_tech(T,{icon=TECHPATH .. "msi_companion_droid_tech.png",icon_size=256, icon_mipmaps = 4})
	if T>1  then table.insert (prerequisites,"msi_companion_droid_tech-" ..T-1)   end
	if tp>1 then table.insert (prerequisites,techPacks[tp]) end
	tech.name="msi_companion_droid_tech-" ..T
	tech.unit={count=200+ (T-1)*100,time=19+T, ingredients = packs}	
	tech.prerequisites = prerequisites
	data:extend{tech}
	end

for T=1, 6 do 
	local tp = T
	local packs = {}
	for p=1,tp do table.insert(packs,{techPacks[p],1}) end
	local prerequisites = {}
	if T==1 then prerequisites = {'engine'} end
	local tech = get_base_tech(T,{icon=TECHPATH .. "msi_companion_synthetic_tech.png",icon_size=256, icon_mipmaps = 4})
	if T>1  then table.insert (prerequisites,"msi_companion_synthetic_tech-" ..T-1)   end
	if tp>1 then table.insert (prerequisites,packs[tp][1]) end
	
	tech.name="msi_companion_synthetic_tech-" ..T
	tech.unit={count=200+ (T-1)*100,time=19+T, ingredients = packs}	
	tech.prerequisites = prerequisites
	data:extend{tech}
	end