local adv_craft_cat = "advanced-crafting"
if mods['IndustrialRevolution'] then adv_craft_cat = "crafting-3" end



data:extend({
  {
    type = "item",
    name = "msi_container",
    icon = "__Mining-Space-Industries-II__/graphics/icon/container.png",
	icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-material",
    order = "m-s-i",
    stack_size = 1,
  },

 {
    type = "recipe",
    name = "msi_container",
    energy_required = 30,
    category = adv_craft_cat,
    enabled = "false",
    ingredients = 
    {
      {"steel-plate", 50},
	  {"plastic-bar", 50}
    },
    result = "msi_container"
  },



})

local unlock = {"msi_container"}

for name, weight in pairs (MSI_cargo_list) do

	if data.raw.item[name] then 
		local iname = "msi_" ..name.."_container"
		table.insert (unlock ,iname)
		local scale= 0.3
		
		local icons = {
					 {
						icon = "__Mining-Space-Industries-II__/graphics/icon/container.png",
						icon_size = 64, icon_mipmaps = 4,
					 }}
		
		local item_icons = {{
						icon = data.raw.item[name].icon,
						icon_size = data.raw.item[name].icon_size, 
						}}
		
		if data.raw.item[name].icons then item_icons = table.deepcopy(data.raw.item[name].icons) end
		
		for i,ico in pairs (item_icons) do 
			if not ico.icon_size then ico.icon_size=64 end
			if ico.scale then ico.scale=ico.scale*scale else ico.scale=scale end
			ico.shift = {math.floor(ico.icon_size/8),math.floor(ico.icon_size/8)}
			table.insert (icons,ico)
			end
		
		data:extend({
		  {
			type = "item",
			name = iname,
			localised_name = {"", {"item-name."..name}, " ", {"item-name.msi_container"}},
			icons=icons,
			subgroup = "raw-material",
			order= "m-s-p",
			stack_size= 1,
		  },

		 {
			type = "recipe",
			name = iname,
			energy_required = 100,
			category =adv_craft_cat,
			enabled = "false",
			request_paste_multiplier = 1,
			overload_multiplier =1,
			allow_inserter_overload = false,
			ingredients = 
			{
			  {name,MSI_cargo_list[name]*1000},
			  {"msi_container",4}
			},
			result = iname
		  },

		})
		end
	end


--[[ DOUBLED RECIPES

 R1 - Chip Red
 R2 - Chip Blu
 R3 - Densidade
 R4 - Rocket Fuel
 R5 - Modulos (os 3)
]]

local ori_recipes = {'advanced-circuit','processing-unit','low-density-structure','rocket-fuel',
					 'speed-module','productivity-module','effectivity-module'}

if mods['IndustrialRevolution'] then 
	ori_recipes = {'advanced-circuit','processing-unit','low-density-structure','rocket-fuel',
				   'rocket-control-unit','plastiglass','advanced-battery'}
	end



function double_recipe_result(recipe_name)
local m = 2
if mods['Krastorio2'] and (recipe_name=='advanced-circuit' or recipe_name=='processing-unit' ) then m=4 end
if mods['IndustrialRevolution'] and (recipe_name=='plastiglass' ) then m=4 end

local recipe = table.deepcopy(data.raw.recipe[recipe_name])
recipe.name= 'msi_double_' ..recipe_name
if recipe.normal then 
	recipe.normal.enabled=false
	if recipe.normal.result_count then recipe.normal.result_count = recipe.normal.result_count*m else recipe.normal.result_count=m end
	if recipe.normal.results then recipe.normal.results=nil recipe.normal.result=recipe_name end
	recipe.expensive.enabled=false
	if recipe.expensive.results then recipe.expensive.results=nil recipe.expensive.result=recipe_name end
	if recipe.expensive.result_count then recipe.expensive.result_count = recipe.expensive.result_count*m else recipe.expensive.result_count = m end
	else
	recipe.enabled=false
	if recipe.results then recipe.results=nil recipe.result=recipe_name end
	if recipe.result_count then recipe.result_count = recipe.result_count*m else recipe.result_count = m end
	end
recipe.show_amount_in_title =true	
recipe.localised_name = {"","MSI ",{"item-name."..recipe_name}}
return recipe
end


for x=1,#ori_recipes do	
	data:extend({double_recipe_result(ori_recipes[x])})
	end
	
