


local beam_base = table.deepcopy(data.raw.beam["laser-beam"])
beam_base.damage_interval = 10000
beam_base.action = nil

local geen_beam = table.deepcopy(beam_base)
hack_tint(geen_beam, {g = 1})
geen_beam.name = 'green-laser-beam'

local blue_beam = table.deepcopy(beam_base)
hack_tint(blue_beam, {g = 1, b = 1})
blue_beam.name =  'blue-laser-beam'


-- Mission completed - Achievement
data:extend({
geen_beam,blue_beam,

    {
      type = "projectile",
      name = "msi_raising_achievement_golem",
      acceleration = 0,
      rotatable = false,
      animation = {
		filename = "__base__/graphics/achievement/golem.png",
        frame_count = 1, line_length = 1,priority = "high",
		width = 128,
		height = 128,
		shift = {0, 0},
      },
      action = {
        action_delivery = {
          target_effects = target_effects,
          type = "instant"
        },
        type = "direct"
      },
      flags = { "not-on-map" },
      light = { intensity = 5, size = 5, color={r=1,g=1,b=1}},
    }
})



-- falling shipwrecks
function create_projectile_from_entity(entityname,animation, create_entity)


local target_effects = {
            {
              action = {
                action_delivery = {
                  target_effects = {
                    {
                      damage = {
                        amount = 30,
                        type = "impact"
                      },
                      type = "damage"
                    },
                  },
                  type = "instant"
                },
                radius = 4,
                type = "area"
              },
              type = "nested-result"
            },
            {
              type = "create-entity",
              entity_name = "big-artillery-explosion",
            },
            {
              type = "create-entity",
              entity_name = "big-explosion",
            },
          }

if create_entity then table.insert(target_effects,
            {
              type = "create-entity",
              check_buildability = false,
              entity_name = entityname,
            })
			else table.insert(target_effects,
			            {
              type = "create-entity",
              entity_name = "fire-flame",
            })
			end



data:extend({

    {
      type = "projectile",
      name = "falling-entity-" .. entityname,
      acceleration = 0,
      rotatable = false,
      animation = animation,
      action = {
        action_delivery = {
          target_effects = target_effects,
          type = "instant"
        },
        type = "direct"
      },
      flags = { "not-on-map" },
      light = { intensity = 1, size = 5, color={r=1,g=0.7,b=0.3}},
      smoke = {
        {
          deviation = {
            0.15,
            0.15
          },
          frequency = 1,
          name = "soft-fire-smoke", -- lasts longer
          position = {0,0},
          slow_down_factor = 1,
          starting_frame = 3,
          starting_frame_deviation = 5,
          starting_frame_speed = 0,
          starting_frame_speed_deviation = 5
        }
      },
    },
})
end

local anim1= {
		filename = "__base__/graphics/entity/ship-wreck/big-ship-wreck-1.png",
        frame_count = 1, line_length = 1,priority = "high",
		width = 256,
		height = 212,
		shift = {0.7, 0},
      }
local anim2= {
		filename = "__base__/graphics/entity/ship-wreck/big-ship-wreck-2.png",
        frame_count = 1, line_length = 1,priority = "high",
		shift = {-0.5, 0.6},
		width = 164,
		height = 129,
      }
local anim3= {
		filename = "__base__/graphics/entity/ship-wreck/big-ship-wreck-3.png",
        frame_count = 1, line_length = 1,priority = "high",
		shift = {-0.5, 0.6},
      width = 165,
      height = 131
      }

create_projectile_from_entity("big-ship-wreck-1",anim1,false)
create_projectile_from_entity("big-ship-wreck-2",anim2,false)
create_projectile_from_entity("big-ship-wreck-3",anim3,false)

local p_cs = '__factorio-crash-site__'
local anim = {
            filename = p_cs .. "/graphics/entity/crash-site-generator/hr-crash-site-generator.png",
            width = 286,
            height= 252,
            frame_count = 1,
            line_length = 1,
            shift = util.by_pixel(-11, -23),
            scale = 0.5
         }
create_projectile_from_entity("msi-broken-generator",anim,false)


local anim = {
            filename = p_cs .. "/graphics/entity/crash-site-lab/hr-crash-site-lab-broken.png",
            width = 472,
            height = 280,
            frame_count = 1,
            line_length = 1,
            shift = util.by_pixel(-24, 6),
            scale = 0.5			
         }
create_projectile_from_entity("msi_broken_lab",anim,false)


local anim = table.deepcopy( data.raw["container"]["msi_mission_terminal"].picture.layers[1])
create_projectile_from_entity("msi_mission_terminal",anim,false)


local anim = table.deepcopy(data.raw.container["crash-site-spaceship-wreck-medium-2"].picture.layers[1])
create_projectile_from_entity("crash-site-spaceship-wreck-medium-2",anim,false)


local anim = {
            filename = p_cs .. "/graphics/entity/crash-site-assembling-machine/hr-crash-site-assembling-machine-1-repaired.png",
            priority="high",
            width = 282,
            height = 182,
            frame_count = 1,
            line_length = 1,
            shift = util.by_pixel(-12, 3),
            scale = 0.5		
         }
create_projectile_from_entity("crash-site-assembling-machine-1-repaired",anim,false)




local function make_projectile_from_item(item)
  local animation

  if item.icon and type(item.icon) == "string" then
      animation = {
          filename = item.icon,
          frame_count = 1,
          width = 64,
          height = 64,
		  scale=1/4,
          priority = "high"
      }
  elseif item.icons and item.icons[1] then
      animation = {layers = {}}
      for _, icon in pairs(item.icons) do
          local layer = table.deepcopy(icon)
          layer.filename = layer.icon
          layer.icon = nil
          layer.frame_count = 1
		  layer.scale=1/4
          layer.width = layer.width or 64
          layer.height = layer.height or 64
          layer.priority = layer.priority or "high"
          if layer.shift and layer.shift[1] and layer.shift[2] then
              layer.shift[1] = layer.shift[1]/64
              layer.shift[2] = layer.shift[2]/64
          end
          animation.layers[_] = layer
      end
  end

  if animation then
      data:extend({{
          type="projectile",
          name="item_projectile_"..item.name,
          acceleration = 0.01,
          light = {intensity = 0.2, size = 10},
          animation = animation,
  --        speed = 0.05,

     action = {
        action_delivery = {
          target_effects = {
            {
              type = "create-entity",
              entity_name = "big-explosion",
            },
            {
              type = "create-entity",
              entity_name = "small-scorchmark",
            },

          },
          type = "instant"
        },
        type = "direct"
      },
      flags = { "not-on-map" },
      }})
  end

end


make_projectile_from_item(data.raw.item['iron-plate'])