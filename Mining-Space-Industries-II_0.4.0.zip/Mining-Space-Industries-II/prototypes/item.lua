local sound_sniper={
  {
    filename = "__base__/sound/fight/gun-turret-gunshot-01.ogg",
    volume = 1
  },
  {
    filename = "__base__/sound/fight/gun-turret-gunshot-02.ogg",
    volume = 1
  },
  {
    filename = "__base__/sound/fight/gun-turret-gunshot-03.ogg",
    volume = 1
  },
  {
    filename = "__base__/sound/fight/gun-turret-gunshot-04.ogg",
    volume = 1
  }
}



data:extend({

  {
    type = "item",
    name = "msi_protomolecule_antidote_bomb",
    icon = path.."graphics/icon/protomolecule_bomb.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "ammo",
    order = "p[protomolecule]-h",
    stack_size= 1,
  },


  {
    type = "item-with-entity-data",
    name = "msi_spidertron",
	icons= data.raw["spider-vehicle"].msi_spidertron.icons,
    subgroup = "transport",
    order = "b[personal-transport]-c[spidertron]-a[spider]",
    place_result="msi_spidertron",
    stack_size = 1,
  },



  {
    type = "capsule",
    name = "msi_portable_technology_data",
    icon = path.."graphics/icon/tech_data_module.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-resource",
    capsule_action =
    {
      type = "use-on-self",
	  attack_parameters = {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 30,
        range = 0,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                {
                  type = "damage",
                  damage = {type = "physical", amount = -1}
                },
              }
            }
          }
        }
      }
    },
    order = "msi",
    stack_size = 10
  },



  {
    type = "capsule",
    name = "msi_portable_technology_recovery",
    icon = path.."graphics/icon/tech_recovery_data_module.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-resource",
    capsule_action =
    {
      type = "use-on-self",
	  attack_parameters = {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 30,
        range = 0,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                {
                  type = "damage",
                  damage = {type = "physical", amount = -1}
                },
              }
            }
          }
        }
      }
    },
    order = "msi",
    stack_size = 10
  },


   {
    type = "gun",
    name = "msi_sniper_rifle",
    icon = path .. "graphics/icon/sniper_rifle.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "gun",
	order = "a[basic-clips]-s[sniper]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "bullet",
      cooldown = 100,
      damage_modifier = 10,
      movement_slow_down_factor = 0.5,
      shell_particle =
        {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.3,
        center = {0, 0.01},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 1.125,
      range = 70,
      sound = sound_sniper,
    },
    stack_size = 5
  },




  {
    type = "ammo",
    name = "msi_sniper_fire_ammo",
    icon = path .. "graphics/icon/sniper_rifle_magazine.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "ammo",
    order = "a[basic-clips]-s[sniper]",
    stack_size = 200,
    magazine_size = 10,
    ammo_type =
    {
      category = "bullet",
      action =
      {
	  
--[[	  
      {
          type = "direct",
          action_delivery =
          {
            type = "beam",
            beam = 'sniper-beam', -- defined in fake humans file
            max_length = 80,
            duration = 10, --30
            source_offset = {0, -1.31439 },
			target_offset = {0, -4}
          }
        },	]]  
	  
        {
          type = "direct",
          action_delivery =
          {
	  
            {
              type = "instant",
              source_effects =
              {
                {
                  type = "create-entity",
                  entity_name = "explosion-gunshot"
                },
              },
              target_effects =
              {
                {
                  type = "create-entity",
                  entity_name = "explosion-gunshot"
                },
                {
                  type = "create-entity",
                  entity_name = "fire-flame"
                },				
                {
		    	type = "damage",
                damage = {amount = 10 , type = "fire"}
		        },
                {
                type = "damage",
                damage = {amount = 10 , type = "physical"}
                },
                {
                type = "damage",
                damage = {amount = 10 , type = "explosion"}
               }
              }
            }
          }
        }
      }
    },
  },


	
})

