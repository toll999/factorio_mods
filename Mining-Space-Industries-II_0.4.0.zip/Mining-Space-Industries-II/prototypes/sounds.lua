data:extend({
  
	{
		type = "sound",
		name = "tc_sound_siren",
		filename = "__base__/sound/programmable-speaker/siren.ogg",
		volume = 1
	},   
   
	{
		type = "sound",
		name = "tc_sound_alarm_1",
		filename = "__base__/sound/programmable-speaker/alarm-1.ogg",
		volume = 1
	},   
   
	{
		type = "sound",
		name = "tc_sound_alarm_2",
		filename = "__base__/sound/programmable-speaker/alarm-2.ogg",
		volume = 1
	},   

})
