

local sprite_fields = {
    "upper_part",
    "lower_part",
    "upper_part_shadow",
    "lower_part_shadow",
    "upper_part_water_reflection",
    "lower_part_water_reflection",
    "joint",
    "joint_shadow",
}


-- invisible spider legs
for n = 1, 8 do
	local spider_leg = table.deepcopy(data.raw["spider-leg"]["spidertron-leg-"..n])
	spider_leg.name = 'spidertron-invisible-leg-'..n
	for _, field in pairs(sprite_fields) do
        spider_leg.graphics_set[field] = nil
		end
	spider_leg.localised_name = {"entity-name.spidertron-leg"}
	spider_leg.working_sound = nil
	spider_leg.collision_box = nil
	spider_leg.collision_mask = {}
	spider_leg.selection_box = {{-0, -0}, {0, 0}}
	spider_leg.target_position_randomisation_distance = 0
	spider_leg.walking_sound_volume_modifier = 0
	data:extend({spider_leg})	
	end



local function add_companion_droid_unit(k)
local spider_droid = table.deepcopy(data.raw["spider-vehicle"].spidertron)
spider_droid.name="msi_companion_droid_"..k  --"msi_spidertron_droid"
spider_droid.icons= {{icon= path .. "graphics/icon/msi_companion_droid.png", icon_size=64, icon_mipmaps = 4}} 
spider_droid.max_health=500 + k * 300
spider_droid.localised_name = {"",{"entity-name.msi_companion_droid"},' '..k}
spider_droid.localised_description = {"entity-description.msi_companion_droid"}
spider_droid.guns = {}
spider_droid.automatic_weapon_cycling = false
spider_droid.inventory_size = 10 + k*10
spider_droid.chunk_exploration_radius = 1
spider_droid.height = 1
spider_droid.equipment_grid = "msi_worker_droid_equipment_grid-"..k
spider_droid.corpse ="big-remnants"
spider_droid.minable=nil
spider_droid.hide_resistances = false
--spider_droid.light = {type='basic',intensity=2,size=18,color={r=0.6, g=1}}
spider_droid.minimap_representation =
    {
      filename = path .."graphics/icon/msi_companion_droid.png",
      flags = {"icon"},
      size = {64, 64},
      scale = 1
    }
spider_droid.resistances = {
	  {type = "fire", percent = 30+k*5},
	  {type = "cold", percent = 90+k},
      {type = "physical", percent = 30+k*5},
      {type = "impact", decrease = 10, percent = 20+k*5},
      {type = "explosion", percent = 30+k*5},
      {type = "acid", percent = 30+k*2},
      {type = "poison", percent = 100},
      {type = "laser", percent = -50+k*5},
	  {type = "electric", percent = -50+k*5},
	  }
for L=1,8 do 
	spider_droid.spider_engine.legs[L].leg='spidertron-invisible-leg-'..L
	spider_droid.spider_engine.legs[L].leg_hit_the_ground_trigger=nil
	end
spider_droid.graphics_set.base_animation = nil
spider_droid.graphics_set.shadow_base_animation = nil
hack_tint(spider_droid, colors.white, false)
data:extend({spider_droid,
  {
    type = "equipment-grid",
    name = "msi_worker_droid_equipment_grid-"..k,
    width = 1+k,
    height = 1+k,
    equipment_categories = {"armor"}
  }
})
end












local function make_robot_roars(volume)
  return
  {
    {
      filename = path.."sound/attack.ogg",
      volume = volume
    },
  }
end

local function make_robot_dying_sounds(volume)
  return
  {
    {
      filename = path.."sound/dyingrobot.ogg",
      volume = volume
    },
  }
end

local function make_robot_calls(volume)
  return nil
  --[[
  {
    {
      filename = path.."/sound/blip1.ogg",
      volume = volume,
    },
    {
      filename = path.."/sound/blip2.ogg",
      volume = volume,
    },
    {
      filename = path.."/sound/blip3.ogg",
      volume = volume,
    },
  }
  ]]
end


local compilatron_animations =
{
  walk =
  {
    width = 40,
    height = 52,
    frame_count = 2,
    axially_symmetrical = false,
    direction_count = 32,
    shift = util.by_pixel(0.0, -14.0),
    stripes =
    {
      {
        filename = "__base__/graphics/entity/compilatron/compilatron-walk-1.png",
        width_in_frames = 2,
        height_in_frames = 16
      },
      {
        filename = "__base__/graphics/entity/compilatron/compilatron-walk-2.png",
        width_in_frames = 2,
        height_in_frames = 16
      }
    },

    hr_version =
    {
      width = 78,
      height = 104,
      frame_count = 2,
      axially_symmetrical = false,
      direction_count = 32,
      shift = util.by_pixel(0.0, -14),
      scale = 0.5,
      stripes =
      {
        {
          filename = "__base__/graphics/entity/compilatron/hr-compilatron-walk-1.png",
          width_in_frames = 2,
          height_in_frames = 16
        },
        {
          filename = "__base__/graphics/entity/compilatron/hr-compilatron-walk-2.png",
          width_in_frames = 2,
          height_in_frames = 16
        }
      },
    }
  },
  walk_shadow =
  {
    width = 72,
    height = 30,
    frame_count = 2,
    direction_count = 32,
    shift = util.by_pixel(19, 0.0),
    draw_as_shadow = true,
    stripes = util.multiplystripes(2,
    {
      {
        filename = "__base__/graphics/entity/compilatron/compilatron-walk-shadow.png",
        width_in_frames = 1,
        height_in_frames = 32
      }
    }),
    hr_version =
    {
      width = 142,
      height = 56,
      frame_count = 2,
      axially_symmetrical = false,
      direction_count = 32,
      shift = util.by_pixel(15.5, -0.5),
      draw_as_shadow = true,
      scale = 0.5,
      stripes = util.multiplystripes(2,
      {
        {
          filename = "__base__/graphics/entity/compilatron/hr-compilatron-walk-shadow.png",
          width_in_frames = 1,
          height_in_frames = 32
        }
      })
    }
  }
}






local function tint_compilatron_animations(tint1,scale)
return
{
  layers =
  {
  { --layer
    width = 40,
    height = 52,
    frame_count = 2,
    axially_symmetrical = false,
    direction_count = 32,
    shift = util.by_pixel(0.0, -14.0),
	tint = tint1,
	scale = scale,
    stripes =
    {
      {
        filename = "__base__/graphics/entity/compilatron/compilatron-walk-1.png",
        width_in_frames = 2,
        height_in_frames = 16
      },
      {
        filename = "__base__/graphics/entity/compilatron/compilatron-walk-2.png",
        width_in_frames = 2,
        height_in_frames = 16
      }
    },

    hr_version =
    {
      width = 78,
      height = 104,
      frame_count = 2,
      axially_symmetrical = false,
      direction_count = 32,
      shift = util.by_pixel(0.0, -14),
      scale = 0.5 * scale,
	  tint = tint1,
      stripes =
      {
        {
          filename = "__base__/graphics/entity/compilatron/hr-compilatron-walk-1.png",
          width_in_frames = 2,
          height_in_frames = 16
        },
        {
          filename = "__base__/graphics/entity/compilatron/hr-compilatron-walk-2.png",
          width_in_frames = 2,
          height_in_frames = 16
        }
      },
    }
  },

  { -- shadow
    width = 72,
    height = 30,
    frame_count = 2,
    direction_count = 32,
    shift = util.by_pixel(19, 0.0),
    draw_as_shadow = true,
	scale = scale,
    stripes = util.multiplystripes(2,
    {
      {
        filename = "__base__/graphics/entity/compilatron/compilatron-walk-shadow.png",
        width_in_frames = 1,
        height_in_frames = 32
      }
    }),
    hr_version =
    {
      width = 142,
      height = 56,
      frame_count = 2,
      axially_symmetrical = false,
      direction_count = 32,
      shift = util.by_pixel(15.5, -0.5),
      draw_as_shadow = true,
      scale = 0.5 * scale,
      stripes = util.multiplystripes(2,
      {
        {
          filename = "__base__/graphics/entity/compilatron/hr-compilatron-walk-shadow.png",
          width_in_frames = 1,
          height_in_frames = 32
        }
      })
    }
  }
  }
}
end


local tint_white = nil --{r=1, g=0.4, b=0.4, a=1} 
local tint_blue = {r=0, g=0.9, b=1, a=1} 
local big_scale = 1.3




local function beam_attack(k)
 return   {
      type = "beam",
      cooldown = 20-k, --40
      range = 15+k,
      source_direction_count = 64,
      source_offset = {0, -3.423489 / 4},
      damage_modifier = 3+k*1.5, --3+k*2.5,
	  animation = tint_compilatron_animations(tint_white,big_scale),
      ammo_type =
      {
        category = "laser",
        energy_consumption = "1000kJ",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "beam",
            beam = "laser-beam",
            max_length = 15+k,
            duration = 20-k, --30
            source_offset = {0, -1.31439 }
          }
        }
      }
    }
end


--[[
local function add_companion_droid_unit(k)
data:extend({
  {
    type = "unit",
    name = "msi_companion_droid_"..k,
    icon = table.deepcopy(data.raw.unit.compilatron.icon),
	icon_size = table.deepcopy(data.raw.unit.compilatron.icon_size),
	icon_mipmaps = table.deepcopy(data.raw.unit.compilatron.icon_mipmaps),
    flags = {"placeable-player", "placeable-off-grid", "player-creation", "not-deconstructable"},
	localised_name = {"",{"entity-name.msi_companion_droid"},' Level '..k},
	localised_description = {"entity-description.msi_companion_droid"},
    map_color = {r = 1, g = 1, b = 1, a = 1},
    max_health = 600 + k * 400,
	resistances = {
	  {type = "fire", percent = 40+k*5},
	  {type = "cold", percent = 90+k},
      {type = "physical", percent = 30+k*5},
      {type = "impact", decrease = 10, percent = 20+k*5},
      {type = "explosion", percent = 30+k*5},
      {type = "acid", percent = 30+k*2},
      {type = "poison", percent = 100},
      {type = "laser", percent = -50+k*5},
	  {type = "electric", percent = -50+k*5},
	  },
    order = "m",
    subgroup="enemies",
    has_belt_immunity = true,
    selectable_in_game = true,
    can_open_gates = true,
    healing_per_tick = 0,
    collision_box = {{-0.1*big_scale, -0.1*big_scale}, {0.1*big_scale, 0.1*big_scale}},
    selection_box = {{-0.7*big_scale, -1.1*big_scale}, {0.7*big_scale, 0.5*big_scale}},
    attack_parameters = beam_attack(k),
    vision_distance = 40+k,
    movement_speed = 0.1 + k/30, --0.1 + k/15,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 1000,
    distraction_cooldown = 200,
    min_pursue_time = 3 * 60,
    max_pursue_distance = 20,
	working_sound = make_robot_calls(1),
    corpse = "big-remnants",
    dying_explosion =  "lab-explosion",
	damaged_trigger_effect = table.deepcopy(data.raw.car.tank.damaged_trigger_effect),
	dying_sound = make_robot_dying_sounds(1), 
    run_animation = tint_compilatron_animations(tint_white,big_scale),
	hide_resistances = false,
	light = {type='basic',intensity=2,size=18,color={r=0.6, g=1}},
	ai_settings = {destroy_when_commands_fail = false}
  }})
end
]]
for k=1,7 do add_companion_droid_unit(k) end
	


local tint6 = {r=1, g=1, b=0.5, a=1} -- yellow - escort

data:extend({

  {
    type = "unit",
    name = "msi-science-escort-droid",
    icon = table.deepcopy(data.raw.unit.compilatron.icon),
	icon_size = table.deepcopy(data.raw.unit.compilatron.icon_size),
	icon_mipmaps = table.deepcopy(data.raw.unit.compilatron.icon_mipmaps),
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable"},
    map_color = tint6,
    max_health = 500,
    order = "b-b-a",
    subgroup="enemies",
    has_belt_immunity = true,
    selectable_in_game = true,
    can_open_gates = true,
    healing_per_tick = 0,
	resistances = {
	  {type = "fire", percent = 20},
	  {type = "cold", percent = 80},
      {type = "physical", percent = 15},
      {type = "acid", percent = 10},
      {type = "poison", percent = 100},
	  },	
    collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
    selection_box = {{-0.8, -1.3}, {0.8, 0.5}},
    attack_parameters =
    {
      type = "projectile",
      damage_modifier = 1,
      range = 0.5,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = make_unit_melee_ammo_type(7),
      animation = tint_compilatron_animations(tint6,1),
	  sound = make_robot_roars(0.5),  
    },
    vision_distance = 20,
    movement_speed = 0.07,
    distance_per_frame = 0.09,
    pollution_to_join_attack = 1000,
    distraction_cooldown = 300,
    min_pursue_time = 3 * 60,
    max_pursue_distance = 20,
	working_sound = make_robot_calls(0.25),
    corpse = "small-remnants",
    dying_explosion = "medium-explosion",
	dying_sound = make_robot_dying_sounds(0.5), 
    run_animation =tint_compilatron_animations(tint6,1),
	hide_resistances = false,
	damaged_trigger_effect = table.deepcopy(data.raw.car.tank.damaged_trigger_effect),
	light = {type='basic',intensity=1,size=18,color={r=1, g=1}},
	ai_settings = {destroy_when_commands_fail = false}
  },
  
})