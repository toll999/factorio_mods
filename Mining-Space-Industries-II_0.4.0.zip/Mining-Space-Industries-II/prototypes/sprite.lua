data:extend({
  
   {
      type = "sprite",
      name = "img_camera",
      filename = "__Mining-Space-Industries-II__/graphics/sprite/camera.png",
      priority = "extra-high",
      width = 64,
      height = 64,
   },

})
