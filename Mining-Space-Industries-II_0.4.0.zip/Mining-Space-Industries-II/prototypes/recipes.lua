

--other mods
local tank = "tank"
if mods['Krastorio2'] then tank = "kr-advanced-tank" 
 elseif mods['SchallTankPlatoon'] then 
   if data.raw.recipe["Schall-tank-SH-mk2" ] then tank = "Schall-tank-SH-mk2" 
   elseif data.raw.recipe["Schall-tank-M" ] then tank = "Schall-tank-M" 
   elseif data.raw.recipe["Schall-tank-L" ] then tank = "Schall-tank-L" 
   end
 end


local at_bomb="atomic-bomb"
local adv_craft_cat = "advanced-crafting"
if mods['IndustrialRevolution'] then 
	adv_craft_cat = "crafting-3" 
	at_bomb = "atomic-artillery-shell"
	end


data:extend({


  {
    type = "recipe",
    name = "msi_spidertron",
    normal =
    {
      enabled = false,
      energy_required = 10,
      ingredients =
      {
        {"exoskeleton-equipment", 1},
        {"spidertron", 1},
		{"flamethrower-turret", 1},
		{tank, 1},
		{"submachine-gun", 1},
        {"rocket-control-unit", 5},
        {"low-density-structure", 50},
      },
      result = "msi_spidertron"
    },
  },


	{
		type = "recipe",
		name = "msi_portable_technology_data",
		icon = path.."graphics/icon/tech_data_module.png",
		icon_size = 64,
		order = "msi",
		enabled = false,   
		hidden = true,
		energy_required = 100,
		ingredients = {},
		subgroup = "defensive-structure",
		results=
		{
		  {type="item", name="msi_portable_technology_data", amount=1,probability=0},
		},   
	},	


  {
    type = "recipe",
    name = "msi_sniper_rifle",
	enabled = false,
	nergy_required = 70,
    ingredients = {
        {"night-vision-equipment", 1},
        {"submachine-gun", 1},
        {"iron-gear-wheel", 20},		
        {"steel-plate", 15},
		{"plastic-bar", 10},
      },
    result = "msi_sniper_rifle"
    },

	
    {
    type = "recipe",
    name = "msi_sniper_fire_ammo",
    enabled = false,
    energy_required = 50,
    ingredients =
    {
      {"piercing-rounds-magazine", 20},
      {"explosives", 1},
	  {"flamethrower-ammo", 1}
    },
    result = "msi_sniper_fire_ammo",
    result_count = 20
  },


	 {
		type = "recipe",
		name = "msi_protomolecule_antidote_bomb",
		energy_required = 120,
		category = adv_craft_cat,
		enabled = "false",
		ingredients = 
		{
		  {at_bomb,200},
		  {"explosives",500},
		  {"rocket-control-unit",100},
		  {"poison-capsule",1000},
		  {"slowdown-capsule",1000},
		  {"destroyer-capsule",200},
		},
		result = "msi_protomolecule_antidote_bomb"
	  },
})

