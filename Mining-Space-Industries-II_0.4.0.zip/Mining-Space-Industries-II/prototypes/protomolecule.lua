local resistances = require(path.."prototypes/resistances")
local proto_color = {r=0.5,g=0.7,b=1}

local proto_icons = {
	{icon = "__base__/graphics/icons/biter-spawner.png",icon_size = 64, icon_mipmaps = 4, tint=proto_color},
	{icon = "__base__/graphics/icons/nuclear-reactor.png",icon_size = 64, icon_mipmaps = 4, tint=proto_color, scale=0.8}}


local function create_decal(decal)
decal.decal_overdraw_priority=nil
decal.tile_layer=nil
hack_tint(decal, proto_color, false)
data:extend({decal})
end

-- decals
local decal = table.deepcopy(data.raw["optimized-decorative"]["enemy-decal"])
decal.name='msi_protomolecule_decal_1'
create_decal(decal)

local decal = table.deepcopy(data.raw["optimized-decorative"]["worms-decal"])
decal.name='msi_protomolecule_decal_2'
create_decal(decal)

local decal = table.deepcopy(data.raw["optimized-decorative"]["enemy-decal-transparent"])
decal.name='msi_protomolecule_decal_3'
create_decal(decal)


-- Contaminated reactor spawner

local base_reactor = table.deepcopy(data.raw["reactor"]["nuclear-reactor"]) 


local function get_protomolecule_soldiers()
	local function ratio(L,S)
		local div = 20 -- sum of names + levels
		return (L+S)/div
		end
local base_name='msi_protomolecule_infected'
local surnames={'melee','pistol_gunner','machine_gunner','sniper','laser','electric','rocket','grenade','cluster_grenade','erocket'}
local res = {}
for L=1,10 do  --level
	for S=1, #surnames do 
		local name = base_name..'_'..surnames[S]..'_'..L
		local perc = {}
		local rat = ratio(L,S)
		if rat>=0.4 then table.insert(perc,{ rat/10 , 0}) end
		local pe = 0.2
		if surnames[S]=='erocket' then pe = 0.03 end
		table.insert(perc,{rat, 0.2}) 
		if rat<0.4 then table.insert(perc,{0.75, 0.0}) end
		table.insert(res,{name, perc}) -- evo , power
		end
	end
return res
end

--[[
{"small-cold-biter", {{0.0, 0.3}, {0.6, 0.0}}}
{"medium-cold-biter", {{0.2, 0.0}, {0.6, 0.3}, {0.7, 0.1}}}
{"small-cold-spitter", {{0.25, 0.0}, {0.5, 0.3}, {0.7, 0.0}}}
{"medium-cold-spitter", {{0.4, 0.0}, {0.7, 0.3}, {0.9, 0.1}}}
{"big-cold-biter", {{0.5, 0.0}, {1.0, 0.4}}}
{"big-cold-spitter", {{0.5, 0.0}, {1.0, 0.4}}}
{"behemoth-cold-biter", {{0.9, 0.0}, {1.0, 0.3}}}
{"behemoth-cold-spitter", {{0.9, 0.0}, {1.0, 0.3}}}
]]


local proto_spawner = table.deepcopy(data.raw["unit-spawner"]["biter-spawner"])
proto_spawner.name="msi_protomolecule_spawner"
proto_spawner.max_health=5000
proto_spawner.icons=proto_icons
proto_spawner.map_color = proto_color
proto_spawner.enemy_map_color = proto_color
proto_spawner.corpse = base_reactor.corpse
proto_spawner.dying_explosion = "small-atomic-cold-explosion"
proto_spawner.damaged_trigger_effect = base_reactor.damaged_trigger_effect
proto_spawner.healing_per_tick = 0.1
proto_spawner.collision_box = base_reactor.collision_box
proto_spawner.selection_box = base_reactor.selection_box
proto_spawner.autoplace = nil
proto_spawner.integration=spawner_idle_animation(0, nil)
proto_spawner.animations = {layers = {base_reactor.picture.layers[1]}}
proto_spawner.max_count_of_owned_units = 4
proto_spawner.max_friends_around_to_spawn = 2
proto_spawner.spawning_cooldown = {60*30, 60*15}  -- default With zero evolution the spawn rate is 20 seconds, with max evolution it is 2.5 seconds
proto_spawner.spawn_decoration = {
      {
        decorative = "msi_protomolecule_decal_1",
        spawn_min = 3,
        spawn_max = 5,
        spawn_min_radius = 2,
        spawn_max_radius = 7,
      },
      {
        decorative = "msi_protomolecule_decal_2",
        spawn_min = 0,
        spawn_max = 3,
        spawn_min_radius = 2,
        spawn_max_radius = 6,
      },
      {
        decorative = "msi_protomolecule_decal_3",
        spawn_min = 4,
        spawn_max = 20,
        spawn_min_radius = 2,
        spawn_max_radius = 14,
        radius_curve = 0.9
      },
    }	
proto_spawner.resistances =
    {
      {
        type = "physical",
        decrease = 5,
        percent = 25
      },
      {
        type = "acid",
        decrease = 5,
        percent = 15
      },	  
      {
        type = "explosion",
        decrease = 5,
        percent = 15
      },
      {
        type = "cold",
        percent = 100
      },
	  {
        type = "laser",
        percent = 40
      },
	  {
        type = "electric",
        percent = 40
      },
	  {
        type = "poison",
        percent = 100
      },	  
      {
        type = "fire",
        decrease = -3,
        percent = -20
      },
      {
        type = "impact",
		decrease = 20,
        percent = 20
      },	  
	  
    }
proto_spawner.result_units = get_protomolecule_soldiers()
hack_scale(proto_spawner, 1.1)
data:extend({proto_spawner})	

hack_tint(data.raw["unit-spawner"]["msi_protomolecule_spawner"], proto_color, false)
local sp_picture = spawner_idle_animation(0, nil)


local proto_dorment = table.deepcopy(data.raw["unit-spawner"]["msi_protomolecule_spawner"])
proto_dorment.name="msi_dorment_protomolecule" --"msi_protomolecule_dorment"
proto_dorment.type="simple-entity-with-force"
proto_dorment.picture = {layers = {sp_picture, table.deepcopy(base_reactor.picture.layers[1]) }}
hack_scale(proto_dorment, 0.8)
hack_tint(proto_dorment, proto_color, false)

local synthetic_corpse = table.deepcopy(data.raw["simple-entity-with-force"]["msi_companion_synthetic_corpse"])
local proto_waking = table.deepcopy(data.raw["unit-spawner"]["msi_protomolecule_spawner"])
proto_waking.name="msi_protomolecule_waking"
proto_waking.type="simple-entity-with-force"
proto_waking.pictures = {layers = {sp_picture,
							table.deepcopy(base_reactor.picture.layers[1]),
									}}
hack_tint(proto_waking, proto_color, false)
hack_scale(proto_waking, 0.9)

local sp_picture2 = table.deepcopy(proto_waking.pictures.layers[1])
hack_scale(sp_picture2, 0.4)

table.insert (proto_waking.pictures.layers,sp_picture2)
table.insert (proto_waking.pictures.layers,synthetic_corpse.pictures.layers[1])

data:extend({proto_dorment,proto_waking})

local boss_scale = 5.2
local proto_boss_spawner = table.deepcopy(data.raw["unit-spawner"]["msi_protomolecule_spawner"])
hack_scale(proto_boss_spawner,boss_scale)
proto_boss_spawner.name="msi_protomolecule_spawner_boss"
proto_boss_spawner.max_health = 2000000
proto_boss_spawner.resistances = resistances.protomolecule_boss
proto_boss_spawner.collision_box = {{-2.5*boss_scale, -2.5*boss_scale}, {2.5*boss_scale, 2.5*boss_scale}}
proto_boss_spawner.selection_box = proto_boss_spawner.collision_box
proto_boss_spawner.map_generator_bounding_box = proto_boss_spawner.collision_box
proto_boss_spawner.max_count_of_owned_units = 600
proto_boss_spawner.max_friends_around_to_spawn = 400
proto_boss_spawner.call_for_help_radius = 300
proto_boss_spawner.spawning_radius = 20
proto_boss_spawner.spawning_cooldown = {60*10, 60*3}  -- default With zero evolution the spawn rate is 6 seconds, with max evolution it is 2.5 seconds
data:extend({proto_boss_spawner})



local proto_turret = {
	{icon = "__base__/graphics/icons/biter-spawner.png",icon_size = 64, icon_mipmaps = 4, tint=proto_color},
	{icon = "__base__/graphics/icons/artillery-turret.png",icon_size = 64, icon_mipmaps = 4, tint=proto_color, scale=0.8}}

local proto_artillery = table.deepcopy(data.raw["artillery-turret"]["artillery-turret"])
proto_artillery.base_picture = 
    {
      layers =
      {
	  {
        filename = "__base__/graphics/entity/spawner/spawner-idle.png",
        width = 248,
        height = 180,
        frame_count = 1,
        direction_count = 1,
		scale = 0.6,
        shift = util.by_pixel(0, -1),
        hr_version =
        {
          filename = "__base__/graphics/entity/spawner/hr-spawner-idle.png",
          width = 490,
          height = 354,
          frame_count = 1,
          direction_count = 1,
          shift = util.by_pixel(0, -1),
          scale = 0.3
        }
      },
	 -- proto_artillery.base_picture.layers[1],
	 -- proto_artillery.base_picture.layers[2],
	  }
	}  
proto_artillery.icons=proto_turret
proto_artillery.name="msi_protomolecule_artillery"
proto_artillery.map_color = proto_color
proto_artillery.enemy_map_color = proto_color
proto_artillery.resistances =
    {
      {
        type = "physical",
        decrease = 20,
        percent = 40
      },
      {
        type = "acid",
        decrease = 10,
        percent = 20
      },	  
      {
        type = "explosion",
        decrease = 20,
        percent = 50
      },
      {
        type = "cold",
        percent = 100
      },
      {
        type = "impact",
		decrease = 20,
        percent = 70
      },	  
	  {
        type = "laser",
        decrease = 10,
		percent = 40
      },
	  {
        type = "electric",
		decrease = 10,
        percent = 40
      },
	  {
        type = "poison",
        percent = 100
      },	  
      {
        type = "fire",
        decrease = 10,
        percent = 30
      }
    }
proto_artillery.spawn_decoration =proto_spawner.spawn_decoration
hack_tint(proto_artillery, proto_color, false)
data:extend({proto_artillery})





--proto_boss_spawner.resistances = resistances.protomolecule_boss



