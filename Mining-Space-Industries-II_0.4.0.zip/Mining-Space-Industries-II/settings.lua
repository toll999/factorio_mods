data:extend({

{
	type = "int-setting",
	name = "msi-difficulty-level",
	setting_type = "runtime-global",
	default_value = 1,
	minimum_value = 1,
	maximum_value = 5,
	order = "d"
},

{
	type = "double-setting",
	name = "msi-mission-distance-mp",
	setting_type = "runtime-global",
	default_value = 1,
	minimum_value = 0.5,
	maximum_value = 5,
	order = "d"
},

{
	type = "bool-setting",
	name = "msi-allow-missions-other-planets",
	setting_type = "runtime-global",
	default_value = true,
	order = "e"
},


{
	type = "double-setting",
	name = "msi-enemy-hp-multiplier",
	setting_type = "startup",
	default_value = 1,
	minimum_value = 0.2,
	maximum_value = 10,
	order = "m1"
},


{
	type = "double-setting",
	name = "msi-enemy-damage-multiplier",
	setting_type = "startup",
	default_value = 1,
	minimum_value = 0.5,
	maximum_value = 10,
	order = "m2"
},


 {
	type = "int-setting",
	name = "msi_cargo_request_min",
	setting_type = "runtime-global",
	default_value = 3,
	minimum_value = 1,
	maximum_value = 99,
	order = "ra"
}, 

{
	type = "int-setting",
	name = "msi_cargo_request_max",
	setting_type = "runtime-global",
	default_value = 6,
	minimum_value = 1,
	maximum_value = 99,
	order = "rb"
}, 


  
  -- PER PLAYER
  
   {
    type = "bool-setting",
    name = "msi-disable-camera-popup",
    setting_type = "runtime-per-user",
    default_value = false,
	order = "c"
  },  
   

})