require "prototypes.rocket_delivery"


-- AAI INDSTRY MOD
if data.raw.recipe["burner-lab"] then
data.raw.recipe["burner-lab"].enabled=false
data.raw.lab['crash-site-lab-repaired'].energy_source = {
  type = "burner",
  fuel_category = "chemical",
  effectivity = 0.9,
  fuel_inventory_size = 1,
  emissions_per_minute = 4,
  smoke =
  {
    {
      name = "smoke",
      deviation = {0.1, 0.1},
      position = {0.0, -0.9},
      frequency = 4
    }
  }
}
end

if data.raw.tool["basic-tech-card"] then 
data.raw.lab['crash-site-lab-repaired'].inputs = { "basic-tech-card" }
end

if mods['space-exploration'] then 
	-- se v.0.6???
	remove_science_pack("rocket-silo", "se-rocket-science-pack")
	end


--[[if mods['Krastorio2'] then 
data.raw.car.msi_mission_car.burner.fuel_category = "chemical" --vanilla (because Krastorio2 changed to its fuel)
data.raw.car.msi_mission_car.consumption = "9kW"
data.raw.car.msi_mission_car.breaking_power = "5kW"
data.raw.car.msi_mission_car.terrain_friction_modifier = 0.01
data.raw.car.msi_mission_car.burner.effectivity = 0.5
end]]