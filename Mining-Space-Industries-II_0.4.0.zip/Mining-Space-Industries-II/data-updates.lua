require "utils"
local space_pack = 'space-science-pack'
--if mods['space-exploration'] then space_pack = 'se-rocket-science-pack' end

-- entities used on missions
for k=1,3 do 
	data.raw.container["big-ship-wreck-"..k].inventory_size = 200
	data.raw.container["big-ship-wreck-"..k].max_health = 1000
	data.raw.container["big-ship-wreck-"..k].resistances = {{type = "fire", percent = 90}}
	data.raw.container["big-ship-wreck-"..k].dying_explosion = "small-atomic-explosion"
	end
data.raw.container["crash-site-spaceship-wreck-medium-2"].max_health = 1000
data.raw.container["crash-site-spaceship-wreck-medium-2"].resistances ={{type = "fire", percent = 90},{type = "physical", percent = 40},{type = "acid", percent = 40}}

local ship = data.raw.container["crash-site-spaceship"]
ship.max_health=1000
ship.inventory_size = 30
ship.circuit_wire_connection_point = data.raw.container["steel-chest"].circuit_wire_connection_point
ship.circuit_connector_sprites = data.raw.container["steel-chest"].circuit_connector_sprites
ship.circuit_wire_max_distance = data.raw.container["steel-chest"].circuit_wire_max_distance + 10

if data.raw.technology['electric-lab'] then 
	add_technology_prerequisite("electric-lab", "laboratory") 
	else
	data.raw.recipe.lab.enabled=false
	end

if mods['space-exploration'] then 
	table.insert(data.raw.recipe.msi_sniper_fire_ammo.ingredients,{"se-vulcanite-ion-exchange-beads", 2})
	table.insert(data.raw.recipe.msi_sniper_rifle.ingredients,{"se-beryllium-plate", 10})
	add_technology_prerequisite("oil-processing", "engine") --- as vanilla
	
	table.insert(data.raw.recipe.msi_protomolecule_antidote_bomb.ingredients,{"se-vitalic-reagent", 100})
	table.insert(data.raw.recipe.msi_protomolecule_antidote_bomb.ingredients,{"se-bloater-ammo", 100})
	add_technology_prerequisite("msi_protomolecule_antidote_bomb", "se-biogun")
	add_technology_prerequisite("msi_protomolecule_antidote_bomb", "se-vitalic-reagent")

    -- pushes delivery-cannon to tier 3
	remove_science_pack("se-delivery-cannon-weapon",  "se-material-science-pack-1")
	remove_science_pack("se-delivery-cannon-weapon",  "se-astronomic-science-pack-1")
	remove_science_pack("se-delivery-cannon-weapon",  "se-energy-science-pack-1")
	add_technology_prerequisite("se-delivery-cannon-weapon", "se-material-science-pack-3")
	add_technology_prerequisite("se-delivery-cannon-weapon", "se-astronomic-science-pack-3")
	add_technology_prerequisite("se-delivery-cannon-weapon", "se-energy-science-pack-3")
	add_new_science_pack("se-delivery-cannon-weapon", "se-material-science-pack-3", 1)
	add_new_science_pack("se-delivery-cannon-weapon", "se-astronomic-science-pack-3", 1)
	add_new_science_pack("se-delivery-cannon-weapon", "se-energy-science-pack-3", 1)
	
	-- se v.0.6???
	remove_science_pack("rocket-silo", "se-rocket-science-pack")
	
	else
	add_technology_prerequisite("spidertron", "space-science-pack")
	add_new_science_pack("spidertron", "space-science-pack", 1)
	end

add_technology_prerequisite("rocket-silo", "military-3") -- forcing people to be prepared for bosses
add_technology_prerequisite("atomic-bomb", space_pack)
add_new_science_pack("atomic-bomb", space_pack, 1)

remove_technology_prerequisite('landfill', 'logistic-science-pack')
remove_science_pack('landfill', 'logistic-science-pack')

if data.raw.item["glass"] then table.insert (data.raw.recipe["msi_sniper_rifle"].ingredients, {"glass", 2}) end


local tech_dep = {'mining-productivity-4','worker-robot-speed-6','spidertron','jetpack-4','atomic-bomb',
	'physical-projectile-damage-7','energy-weapons-damage-7','stronger-explosives-7','se-space-platform-scaffold'}
for t=1,#tech_dep do
	local tech=tech_dep[t]
	if data.raw.technology[tech] then add_technology_prerequisite(tech, 'msi_tech_lock_satellites') end 
	end



--other mods 
if data.raw.technology['mining-drone-productivity-1'] then 
	local mining_drone_tech = table.deepcopy(data.raw.technology['mining-drone-productivity-1'])
	mining_drone_tech.name='mining_drones_tech'
	mining_drone_tech.localized_name = {'technology-name.mining_drones_tech'}
	mining_drone_tech.effects = {{type = "unlock-recipe",recipe = "mining-depot"},{type = "unlock-recipe",recipe = "mining-drone"}}
	data:extend({mining_drone_tech})
	add_technology_prerequisite("mining-drone-productivity-1", "mining_drones_tech")
	add_technology_prerequisite("mining-drone-mining-speed-1", "mining_drones_tech")
	data.raw.recipe['mining-drone'].enabled=false
	data.raw.recipe['mining-depot'].enabled=false
	end


data.raw.technology['msi_spidertron'].order = data.raw.technology['spidertron'].order ..'z'



-- INITIAL LAB MISSION
if mods['IndustrialRevolution'] then data.raw.technology["laboratory"] = nil 
else
 --[[
 if data.raw.recipe['basic-tech-card'] then data.raw.recipe['basic-tech-card'].enabled=false 
	elseif data.raw.recipe['automation-science-pack'] then data.raw.recipe['automation-science-pack'].enabled=false
	end

 if data.raw.recipe['burner-lab'] then data.raw.recipe['burner-lab'].enabled=false 
	elseif data.raw.recipe['lab'] then data.raw.recipe['lab'].enabled=false
	end
]]	
end