informatron_make_image("programmable_vehicles_inventory_transfer_1", "__aai-programmable-vehicles__/graphics/informatron/inventory-transfer-1.png", 900, 450)
