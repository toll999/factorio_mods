for _, tech in pairs(data.raw.technology) do
  if tech.effects then
    local saved = nil
    for _, effect in pairs(tech.effects) do
      if effect.type == "gun-speed" and effect.ammo_category == "rocket" then
        local c = table.deepcopy(effect)
        c.ammo_category = "mortar-bomb"
        table.insert(tech.effects, c)
      end
      if effect.type == "ammo-damage" and effect.ammo_category == "landmine" then
        if not saved then
          local c = table.deepcopy(effect)
          c.ammo_category = "mortar-bomb"
          table.insert(tech.effects, c)
          saved = c
        else
          saved.modifier = math.max(saved.modifier, effect.modifier)
        end
      end
    end
  end
end
