data:extend({
  {
      type = "custom-input",
      name = "enter-vehicle",
      enabled_while_spectating = true,
      order = "a",
      --key_sequence = "SHIFT + ENTER",
      key_sequence = "",
      linked_game_control = "toggle-driving"
  },
})
